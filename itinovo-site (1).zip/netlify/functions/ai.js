/**
 * Itinovo – Unified AI backend (Netlify Function)
 * ------------------------------------------------
 * Runs on Google's Gemini API FREE tier — no credit card, no billing,
 * no subscription. This was switched from a paid API on purpose: the
 * project's whole point is to stay free to use, not to rack up API bills.
 *
 * Handles three modes from one endpoint:
 *   mode: "chat"  -> the floating AI assistant (free-form Q&A for agents)
 *   mode: "scan"  -> reads a photo/screenshot of a booking and returns
 *                    structured flight segments
 *   mode: "visa"  -> answers a visa/passport/transit requirements question,
 *                    grounded with Google Search so it stays current, and
 *                    a mandatory disclaimer appended.
 *
 * SETUP (one-time, takes 2 minutes, genuinely free):
 *   1. Go to https://aistudio.google.com/apikey and sign in with any
 *      Google account. Click "Create API key". No credit card is asked
 *      for on the free tier.
 *   2. In Netlify: Site settings → Environment variables → add
 *        GEMINI_API_KEY = the key you just copied
 *   3. Deploy. The frontend calls this at /.netlify/functions/ai
 *
 * IMPORTANT — HOW THE "FREE" PART WORKS:
 * Google's free tier is not pay-as-you-go — it is a hard daily/per-minute
 * quota shared by this ONE API key across every visitor of the site. As
 * long as you never add a billing account to this Google Cloud project,
 * you cannot be charged: once the daily quota is used up, Gemini simply
 * replies with a 429 error until the quota resets, and this function
 * turns that into a friendly "please try again later" message instead of
 * a crash. There is no scenario where this configuration generates a
 * bill. If the site outgrows the free quota, the fix is to enable billing
 * on the SAME Google account (pay-as-you-go) — a deliberate choice you'd
 * make later, not something that can happen by accident.
 */

const MODEL = "gemini-2.5-flash"; // free-tier, multimodal (text + images)
const API_BASE = "https://generativelanguage.googleapis.com/v1beta/models";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

exports.handler = async function (event) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS_HEADERS, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return respond(405, { error: "Use POST" });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return respond(500, {
      error: "not_configured",
      message: "The site owner hasn't added a free Gemini API key yet. Get one free at https://aistudio.google.com/apikey and add it in Netlify as GEMINI_API_KEY.",
    });
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return respond(400, { error: "Invalid JSON body" });
  }

  const mode = payload.mode;
  try {
    if (mode === "chat") return respond(200, await handleChat(payload, apiKey));
    if (mode === "scan") return respond(200, await handleScan(payload, apiKey));
    if (mode === "visa") return respond(200, await handleVisa(payload, apiKey));
    return respond(400, { error: "mode must be one of: chat, scan, visa" });
  } catch (err) {
    console.error("AI function error:", err);
    if (err.quotaExceeded) {
      return respond(429, {
        error: "quota_exceeded",
        message: payload.lang === "ar"
          ? "وصلنا للحد المجاني اليومي المشترك لكل زوار الموقع. جرب بعد شوي أو بكرة."
          : "We've hit today's shared free quota for the whole site. Please try again in a little while.",
      });
    }
    return respond(502, { error: "The AI service failed to respond. Please try again." });
  }
};

function respond(statusCode, obj) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json", ...CORS_HEADERS },
    body: JSON.stringify(obj),
  };
}

async function callGemini(apiKey, body, { tools } = {}) {
  const url = `${API_BASE}/${MODEL}:generateContent?key=${apiKey}`;
  const fullBody = tools ? { ...body, tools } : body;
  const r = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(fullBody),
  });
  if (!r.ok) {
    const text = await r.text().catch(() => "");
    if (r.status === 429) {
      const e = new Error(`Gemini quota exceeded: ${text.slice(0, 300)}`);
      e.quotaExceeded = true;
      throw e;
    }
    throw new Error(`Gemini API ${r.status}: ${text.slice(0, 500)}`);
  }
  return r.json();
}

function firstText(data) {
  const parts = data?.candidates?.[0]?.content?.parts || [];
  return parts.map((p) => p.text || "").join("").trim();
}

/* ── mode: chat ───────────────────────────────────────────────
   payload: { history: [{role:"user"|"assistant", content:"..."}], lang: "ar"|"en" }
*/
async function handleChat(payload, apiKey) {
  const isAr = payload.lang === "ar";
  const history = Array.isArray(payload.history) ? payload.history.slice(-20) : [];

  const systemInstruction = isAr
    ? `أنت المساعد الذكي المدمج في "Itinovo" — أداة تحويل رحلات GDS/PNR لوكلاء السفر.
ساعد الوكيل في: قراءة/شرح أكواد GDS، أسئلة عن شركات الطيران والمطارات، حساب فروقات التوقيت، صياغة رسائل للعملاء، ونصائح عامة عن إدارة الحجوزات.
كن مختصراً ومباشراً ومحترفاً. إذا سُئلت عن تأشيرة أو متطلبات دخول دولة، وجّه الوكيل لاستخدام أداة "فحص الفيزا" المخصصة بدل الإجابة التخمينية.`
    : `You are the AI assistant embedded in "Itinovo" — a GDS/PNR flight itinerary converter for travel agents.
Help the agent with: reading/explaining GDS codes, airline & airport questions, time-zone/duration math, drafting client messages, and general booking-workflow tips.
Be concise, direct, and professional. If asked about visas or entry requirements, point them to the dedicated "Visa Check" tool instead of guessing.`;

  const contents = history.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: String(m.content || "").slice(0, 4000) }],
  }));

  const data = await callGemini(apiKey, {
    contents,
    systemInstruction: { parts: [{ text: systemInstruction }] },
    generationConfig: { maxOutputTokens: 700 },
  });

  return { reply: firstText(data) || (isAr ? "ما قدرت أطلع رد، حاول مرة ثانية." : "I couldn't generate a reply — please try again.") };
}

/* ── mode: scan ───────────────────────────────────────────────
   payload: { image: "<base64>", mediaType: "image/png"|"image/jpeg"|"image/webp", lang }
   returns: { segments: [{airline, flightNum, from, to, depDate, depTime, arrDate, arrTime, cabin}], raw }
*/
async function handleScan(payload, apiKey) {
  const isAr = payload.lang === "ar";
  if (!payload.image || !payload.mediaType) {
    throw new Error("scan mode requires { image, mediaType }");
  }

  const systemInstruction = `You extract flight segments from a photo of a booking confirmation, airline email, or e-ticket (any airline's own design/layout — not necessarily a GDS format).
Return ONLY a JSON array (no prose, no markdown fences) of objects, one per flight segment, each with exactly these fields:
  airline   – 2-letter IATA airline code if visible, else best-guess full name
  flightNum – digits only, e.g. "417"
  from      – 3-letter IATA airport code
  to        – 3-letter IATA airport code
  depDate   – "DDMMM" format, e.g. "03NOV" (no year)
  depTime   – 24h "HHMM", e.g. "0255"
  arrDate   – "DDMMM" format (same as depDate if arriving same day)
  arrTime   – 24h "HHMM"
  cabin     – one of "Economy","Premium Economy","Business","First" (best guess if not stated)
If a field truly cannot be determined, use an empty string for it — never invent flight numbers or codes.
If the image contains no flight/booking information at all, return an empty array [].`;

  const data = await callGemini(apiKey, {
    contents: [
      {
        role: "user",
        parts: [
          { inline_data: { mime_type: payload.mediaType, data: payload.image } },
          { text: isAr ? "استخرج كل رحلات الطيران من هذه الصورة كـ JSON فقط." : "Extract all flight segments from this image as JSON only." },
        ],
      },
    ],
    systemInstruction: { parts: [{ text: systemInstruction }] },
    generationConfig: { maxOutputTokens: 1200 },
  });

  const raw = firstText(data);
  let segments = [];
  try {
    const jsonStr = raw.replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
    segments = JSON.parse(jsonStr);
    if (!Array.isArray(segments)) segments = [];
  } catch {
    segments = [];
  }
  return { segments, raw };
}

/* ── mode: visa ───────────────────────────────────────────────
   payload: { nationality, from, to, transit, lang }

   NOTE: this deliberately does NOT use Gemini's "google_search" grounding
   tool. That tool can incur its own per-prompt charge even when the base
   API key has no billing enabled for regular chat/vision calls — which
   would break the "100% free, no bills, ever" guarantee for this project.
   So this answers from the model's own knowledge only, with an even
   stronger disclaimer since it isn't guaranteed to reflect the latest
   rule changes. If you later want live-search-grounded answers, that's a
   deliberate upgrade you can opt into (see the note in the code comment
   for handleVisa below) — not something silently enabled here.
*/
async function handleVisa(payload, apiKey) {
  const isAr = payload.lang === "ar";
  const { nationality, from, to, transit } = payload;
  if (!nationality || !to) {
    throw new Error("visa mode requires at least { nationality, to }");
  }

  const question = isAr
    ? `أنا مسافر أحمل جنسية "${nationality}"، رحلتي من "${from || "غير محدد"}" إلى "${to}"${transit ? ` مع ترانزيت في "${transit}"` : ""}. ما هي متطلبات التأشيرة، ومدة الإقامة المسموحة، وأي متطلبات صحية أو جمركية مهمة؟`
    : `I'm a traveler holding "${nationality}" nationality, flying from "${from || "unspecified"}" to "${to}"${transit ? ` with a transit stop in "${transit}"` : ""}. What are the visa requirements, allowed stay duration, and any important health/customs requirements?`;

  const systemInstruction = isAr
    ? `أنت مساعد متخصص بمتطلبات السفر والتأشيرات ضمن أداة "Itinovo". أجب من معرفتك العامة بإيجاز ووضوح بنقاط. اختم إجابتك دائماً بجملة تحذير واضحة وبارزة تنص إن إجابتك مبنية على معلومات قد لا تكون محدّثة (بدون بحث حي)، وأنه يجب التأكد من السفارة أو الموقع الرسمي للطيران أو حكومة الوجهة قبل السفر لأن أنظمة الفيزا تتغير بدون سابق إنذار.`
    : `You are a travel-requirements specialist inside "Itinovo". Answer from your general knowledge, concisely and in bullet points. Always end your answer with a clear, prominent disclaimer that this answer is NOT based on a live search and may be outdated, and that the traveler must verify with the embassy, an official airline site, or the destination government before travel since visa rules change without notice.`;

  const data = await callGemini(apiKey, {
    contents: [{ role: "user", parts: [{ text: question }] }],
    systemInstruction: { parts: [{ text: systemInstruction }] },
    generationConfig: { maxOutputTokens: 900 },
  });

  return { reply: firstText(data) || (isAr ? "ما قدرت أطلع إجابة، حاول مرة ثانية." : "I couldn't find an answer — please try again.") };
}
