/* ============================================================
   PNR Converter – Core Engine  v5.0
   Fixes: Scan AI, Fare Summary (no fee column), Logos, Copy Email,
   Full AR/EN, Linktree, WhatsApp, RTL numbers
   ============================================================ */
"use strict";

const MONTHS = {
  JAN:"Jan",FEB:"Feb",MAR:"Mar",APR:"Apr",MAY:"May",JUN:"Jun",
  JUL:"Jul",AUG:"Aug",SEP:"Sep",OCT:"Oct",NOV:"Nov",DEC:"Dec"
};
const MONTH_NUM = {
  JAN:0,FEB:1,MAR:2,APR:3,MAY:4,JUN:5,
  JUL:6,AUG:7,SEP:8,OCT:9,NOV:10,DEC:11
};

const CABIN_MAP = {
  F:"First",A:"First",P:"First",
  C:"Business",J:"Business",D:"Business",I:"Business",
  W:"Premium Economy",S:"Premium Economy",
  Y:"Economy",B:"Economy",M:"Economy",H:"Economy",
  K:"Economy",L:"Economy",N:"Economy",Q:"Economy",
  T:"Economy",V:"Economy",X:"Economy",G:"Economy",
  E:"Economy",U:"Economy",Z:"Business",R:"Economy",O:"Economy"
};

const CABIN_MAP_AR = {
  F:"درجة أولى",A:"درجة أولى",P:"درجة أولى",
  C:"درجة أعمال",J:"درجة أعمال",D:"درجة أعمال",I:"درجة أعمال",
  W:"درجة سياحية مميزة",S:"درجة سياحية مميزة",
  Y:"درجة اقتصادية",B:"درجة اقتصادية",M:"درجة اقتصادية",H:"درجة اقتصادية",
  K:"درجة اقتصادية",L:"درجة اقتصادية",N:"درجة اقتصادية",Q:"درجة اقتصادية",
  T:"درجة اقتصادية",V:"درجة اقتصادية",X:"درجة اقتصادية",G:"درجة اقتصادية",
  E:"درجة اقتصادية",U:"درجة اقتصادية",Z:"درجة أعمال",R:"درجة اقتصادية"
};

// Arabic airport city names for full Arabic output
const AIRPORTS_AR = {
  "KWI":"الكويت","DXB":"دبي","AUH":"أبوظبي","DOH":"الدوحة","BAH":"البحرين",
  "MCT":"مسقط","RUH":"الرياض","JED":"جدة","DMM":"الدمام","SHJ":"الشارقة",
  "CAI":"القاهرة","AMM":"عمّان","BEY":"بيروت","TLV":"تل أبيب",
  "IST":"إسطنبول","SAW":"إسطنبول (صبيحة)","ESB":"أنقرة",
  "LHR":"لندن (هيثرو)","LGW":"لندن (غاتويك)","LCY":"لندن (سيتي)",
  "CDG":"باريس (ديغول)","ORY":"باريس (أورلي)",
  "AMS":"أمستردام","FRA":"فرانكفورت","MUC":"ميونيخ","ZRH":"زيورخ",
  "VIE":"فيينا","BRU":"بروكسل","MAD":"مدريد","BCN":"برشلونة",
  "FCO":"روما","MXP":"ميلانو (مالبينسا)","ATH":"أثينا",
  "JFK":"نيويورك (كينيدي)","LAX":"لوس أنجلوس","ORD":"شيكاغو",
  "ATL":"أتلانتا","DFW":"دالاس","SFO":"سان فرانسيسكو",
  "MIA":"ميامي","BOS":"بوسطن","YYZ":"تورنتو","YVR":"فانكوفر",
  "DEL":"نيودلهي","BOM":"مومباي","MAA":"شيناي","CCU":"كولكاتا",
  "COK":"كوتشي","HYD":"حيدراباد","BLR":"بنغالور","AMD":"أحمداباد",
  "KHI":"كراتشي","LHE":"لاهور","ISB":"إسلام آباد",
  "CMB":"كولومبو","DAC":"دكا","KTM":"كاتماندو",
  "SIN":"سنغافورة","KUL":"كوالالمبور","BKK":"بانكوك",
  "HAN":"هانوي","SGN":"هوشي منه","CGK":"جاكرتا",
  "MNL":"مانيلا","HKG":"هونغ كونغ","ICN":"سيول",
  "NRT":"طوكيو (ناريتا)","HND":"طوكيو (هانيدا)","KIX":"أوساكا",
  "SYD":"سيدني","MEL":"ملبورن","AKL":"أوكلاند",
  "JNB":"جوهانسبرغ","NBO":"نيروبي","ADD":"أديس أبابا",
  "LOS":"لاغوس","CAI":"القاهرة","CMN":"الدار البيضاء",
  "GRU":"ساو باولو","EZE":"بوينس آيرس","BOG":"بوغوتا",
  "MEX":"مكسيكو سيتي","SVO":"موسكو","DME":"موسكو (دوموديدوفو)"
};

const AIRPORT_COORDS = {
  "JFK":[40.6413,-73.7781],"LAX":[33.9425,-118.408],"ORD":[41.9742,-87.9073],
  "ATL":[33.6367,-84.4281],"DFW":[32.8998,-97.0403],"DEN":[39.8561,-104.6737],
  "SFO":[37.6213,-122.379],"SEA":[47.4502,-122.3088],"MIA":[25.7959,-80.287],
  "BOS":[42.3656,-71.0096],"LHR":[51.477,-0.4613],"CDG":[49.0097,2.5479],
  "AMS":[52.3086,4.7639],"FRA":[50.0379,8.5622],"MUC":[48.3538,11.775],
  "ZRH":[47.4647,8.5492],"VIE":[48.1103,16.5697],"BRU":[50.9014,4.4844],
  "MAD":[40.4719,-3.5626],"BCN":[41.2971,2.0785],"FCO":[41.8003,12.2389],
  "IST":[41.2753,28.7519],"SAW":[40.8984,29.3092],"ESB":[40.1282,32.9951],
  "DXB":[25.2532,55.3657],"AUH":[24.4330,54.6511],"SHJ":[25.3285,55.5175],
  "DOH":[25.2731,51.6081],"BAH":[26.2708,50.6336],"KWI":[29.2267,47.9689],
  "MCT":[23.5933,58.2844],"RUH":[24.9576,46.6988],"JED":[21.6805,39.1565],
  "DMM":[26.4712,49.7979],"CAI":[30.1219,31.4056],"TLV":[32.0114,34.8867],
  "AMM":[31.7226,35.9932],"BEY":[33.8209,35.4884],"KHI":[24.9065,67.1608],
  "LHE":[31.5216,74.4036],"ISB":[33.6167,73.0997],"DEL":[28.5562,77.1000],
  "BOM":[19.0896,72.8656],"MAA":[12.9941,80.1709],"CCU":[22.6547,88.4467],
  "COK":[10.1520,76.4019],"HYD":[17.2403,78.4294],"BLR":[13.1986,77.7066],
  "CMB":[7.1808,79.8841],"DAC":[23.8433,90.3978],"KTM":[27.6966,85.3591],
  "SIN":[1.3644,103.9915],"KUL":[2.7456,101.7099],"BKK":[13.6900,100.7501],
  "HAN":[21.2187,105.804],"SGN":[10.8188,106.6520],"CGK":[-6.1275,106.6537],
  "MNL":[14.5086,121.0197],"HKG":[22.3080,113.9185],"ICN":[37.4602,126.4407],
  "NRT":[35.7647,140.3864],"HND":[35.5494,139.7798],"KIX":[34.4274,135.2440],
  "SYD":[-33.9399,151.1753],"MEL":[-37.6690,144.8410],"AKL":[-37.0082,174.7850],
  "WLG":[-41.3272,174.8050],"SVO":[55.9726,37.4146],"DME":[55.4088,37.9063],
  "JNB":[-26.1392,28.2460],"NBO":[-1.3192,36.9275],"ADD":[8.9779,38.7993],
  "LOS":[6.5774,3.3212],"CMN":[33.3675,-7.5898],"ACC":[5.6052,-0.1669],
  "GRU":[-23.4356,-46.4731],"EZE":[-34.8222,-58.5358],"BOG":[4.7016,-74.1469],
  "LIM":[-12.0219,-77.1143],"PTY":[9.0714,-79.3835],"MEX":[19.4363,-99.0721],
  "YYZ":[43.6777,-79.6248],"YVR":[49.1967,-123.1815],"CUN":[21.0365,-86.8771],
  "SCL":[-33.3930,-70.7858],"GIG":[-22.8099,-43.2506],"GVA":[46.2381,6.1089],
  "CPH":[55.6180,12.6560],"ARN":[59.6519,17.9186],"HEL":[60.3172,24.9633],
  "OSL":[60.1976,11.1004],"PRG":[50.1008,14.2600],"WAW":[52.1657,20.9671],
  "BUD":[47.4298,19.2611],"ATH":[37.9364,23.9444],"SOF":[42.6967,23.4114],
  "PTY":[9.0714,-79.3835],"BCN":[41.2971,2.0785],"LGW":[51.1537,-0.1821],
  "LCY":[51.5048,0.0495],"MXP":[45.6306,8.7281],"ORY":[48.7233,2.3794]
};

// Known airline codes set for scan detection
const AIRLINE_CODES = new Set([
  "KU","EK","EY","QR","WY","TK","G9","FZ","SV","GF","XY","RB","PG",
  "BA","LH","AF","KL","TG","SQ","CX","MH","AI","9W","IX","6E","IT",
  "AA","UA","DL","WN","AS","B6","F9","NK","SW","MS","ET","KQ","SA",
  "LX","OS","SK","AY","IB","TP","SN","AZ","RO","OK","OU","JP","A3",
  "OA","W6","U2","FR","VY","HV","TO","V7","PC","XC","ZH","MU","CA",
  "CZ","HU","FM","3U","SC","KE","OZ","BR","VN","BG","UL","NH","JL",
  "CI","AE","PR","GA","TG","FD","QZ","TR","VJ","BX","OD","BI","MF",
  "MI","5J","Z2","PQ","PA","WB","QC","EC","AT","CM","AM","LA","JJ",
  "G3","AR","AV","4M","LP","UX","LS","ZB","5O","ME","IR","W5","EP",
  "XW","DD","NZ","QF","JQ","TT","VA","PX","FK","HC","AC","WS","TS",
  "J9","GE","XG","LY","RJ","PK","PS","HY","KC","AK","D7","XJ","HA"
]);

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2-lat1)*Math.PI/180;
  const dLon = (lon2-lon1)*Math.PI/180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return Math.round(2*R*Math.asin(Math.sqrt(a)));
}
function getDistance(a, b) {
  if (!AIRPORT_COORDS[a] || !AIRPORT_COORDS[b]) return null;
  return haversine(...AIRPORT_COORDS[a], ...AIRPORT_COORDS[b]);
}

function parseTime(str) {
  if (!str) return null;
  str = str.trim();
  const ampm = str.match(/(\d{1,2}):?(\d{2})\s*(AM|PM|ص|م)/i);
  if (ampm) {
    let h = parseInt(ampm[1]), m = parseInt(ampm[2]);
    const ap = ampm[3];
    if ((ap==="PM"||ap==="م") && h<12) h+=12;
    if ((ap==="AM"||ap==="ص") && h===12) h=0;
    return h*60+m;
  }
  const t24 = str.replace(":","").match(/^(\d{1,4})$/);
  if (t24) { const r = t24[1].padStart(4,"0"); return parseInt(r.slice(0,2))*60+parseInt(r.slice(2,4)); }
  return null;
}

function minsToStr(mins, use12hr) {
  if (mins===null||mins===undefined) return "--:--";
  mins = ((mins%1440)+1440)%1440;
  const h=Math.floor(mins/60), m=mins%60;
  if (use12hr) {
    const ap=h<12?"AM":"PM", h12=h===0?12:(h>12?h-12:h);
    return `${h12}:${String(m).padStart(2,"0")} ${ap}`;
  }
  return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;
}

function parseDateStr(ds) {
  if (!ds) return null;
  const m = ds.toUpperCase().match(/^(\d{1,2})([A-Z]{3})(\d{2,4})?$/);
  return m ? {day:parseInt(m[1]),month:m[2],year:m[3]||null} : null;
}

const MONTHS_AR = {
  JAN:"يناير",FEB:"فبراير",MAR:"مارس",APR:"أبريل",MAY:"مايو",JUN:"يونيو",
  JUL:"يوليو",AUG:"أغسطس",SEP:"سبتمبر",OCT:"أكتوبر",NOV:"نوفمبر",DEC:"ديسمبر"
};

function formatDate(ds, isAr) {
  const d = parseDateStr(ds);
  if (!d) return ds;
  if (isAr) {
    const mAr = MONTHS_AR[d.month] || d.month;
    return `${d.day} ${mAr}${d.year?" "+d.year:""}`;
  }
  return `${d.day} ${MONTHS[d.month]||d.month}${d.year?" "+d.year:""}`;
}

// Accurate calendar day difference between two {day,month,year} parts
// (replaces the old "31 days per month" approximation, which gave wrong
// results whenever a trip crossed a month shorter than 31 days, e.g. 28FEB->01MAR).
function daysBetweenDates(d1, d2) {
  if (!d1 || !d2) return 0;
  const y1 = d1.year ? parseInt(d1.year.length===2?"20"+d1.year:d1.year) : 2024;
  let y2 = d2.year ? parseInt(d2.year.length===2?"20"+d2.year:d2.year) : y1;
  const m1 = MONTH_NUM[d1.month]||0, m2 = MONTH_NUM[d2.month]||0;
  const date1 = Date.UTC(y1, m1, d1.day);
  let date2 = Date.UTC(y2, m2, d2.day);
  // If no explicit years were given and the arrival looks earlier than
  // departure (e.g. DEC -> JAN), assume it rolled into the next year.
  if (!d1.year && !d2.year && date2 < date1) {
    date2 = Date.UTC(y2+1, m2, d2.day);
  }
  return Math.round((date2-date1)/86400000);
}

function calcDuration(dep, arr, dayDiff=0) {
  let diff = arr-dep+dayDiff*1440;
  if (diff<0) diff+=1440;
  return {mins:diff, label:`${Math.floor(diff/60)}h ${diff%60}m`};
}

function calcDurationAr(dep, arr, dayDiff=0) {
  let diff = arr-dep+dayDiff*1440;
  if (diff<0) diff+=1440;
  const h=Math.floor(diff/60), m=diff%60;
  return {mins:diff, label:`${h} س ${m} د`};
}

function calcTransit(arr, dep, dd=0) {
  let diff = dep-arr+dd*1440;
  if (diff<0) diff+=1440;
  if (diff>24*60) return null;
  const h=Math.floor(diff/60), m=diff%60;
  return {mins:diff, label:`${h}h ${m}m`, labelAr:`${h} س ${m} د`};
}

// ── Real connection detector ─────────────────────────────────
// A segment is only a genuine "connection/transit" of the previous one when:
//   1) the previous flight's arrival airport is the SAME as this flight's departure airport, AND
//   2) the real gap between arrival and next departure (using full dates, not just clock time)
//      is a realistic layover — not weeks apart (which means it's a separate/return flight).
function isConnectingSegment(prevSeg, seg) {
  if (!prevSeg || !seg) return false;
  if (prevSeg.to !== seg.from) return false;
  const d1 = parseDateStr(prevSeg.arrDate);
  const d2 = parseDateStr(seg.depDate);
  let dayGap = 0;
  if (d1 && d2) dayGap = daysBetweenDates(d1, d2);
  if (dayGap < 0 || dayGap > 1) return false; // more than an overnight layover = not a connection
  if (prevSeg.arrMins === null || seg.depMins === null) return dayGap <= 1;
  const totalMins = dayGap * 1440 + (seg.depMins - prevSeg.arrMins);
  return totalMins >= 0 && totalMins <= 30 * 60; // cap a "connection" at 30 hours
}

function getTransitInfo(prevSeg, seg) {
  if (!isConnectingSegment(prevSeg, seg)) return null;
  const d1 = parseDateStr(prevSeg.arrDate);
  const d2 = parseDateStr(seg.depDate);
  const dayGap = (d1 && d2) ? Math.max(0, daysBetweenDates(d1, d2)) : 0;
  return calcTransit(prevSeg.arrMins, seg.depMins, dayGap);
}

// Group consecutive connected segments into "legs" (each leg = one physical
// journey the passenger flies through, possibly with real connections).
function groupIntoLegs(segments) {
  const legs = [];
  segments.forEach((seg, i) => {
    if (i > 0 && isConnectingSegment(segments[i - 1], seg)) {
      legs[legs.length - 1].push(seg);
    } else {
      legs.push([seg]);
    }
  });
  return legs;
}

function normalizeLine(line) {
  return line.replace(/#/g,"").replace(/\*/g,"").replace(/\s+/g," ").trim();
}

// ── PNR Parser ────────────────────────────────────────────────
function parsePNRLine(rawLine) {
  if (!rawLine||!rawLine.trim()) return null;
  const line = normalizeLine(rawLine);
  if (/^[-=*#>\/]{2,}/.test(line)) return null;
  if (/^(note|remark|osi|ssr|---)/i.test(line)) return null;

  const mk = (al,fn,cc,dd,fr,to,dt,at,off,ad,raw) => ({
    airline:al.toUpperCase(), flightNum:fn, cabinCode:cc.toUpperCase(),
    depDate:dd.toUpperCase(), from:fr.toUpperCase(), to:to.toUpperCase(),
    depTime:dt, arrTime:at, arrDate:(ad||dd).toUpperCase(),
    nextDayOffset:(off!==null&&off!==undefined&&off!=="")?parseInt(off):null, raw
  });

  // Pattern A: Galileo – with pax count e.g. "NZ 456 H 26OCT 5 WLGAKL HK1 1945 2050"
  let p = line.match(/^([A-Z0-9]{2})\s+(\d{1,4})\s+([A-Z])\s+(\d{1,2}[A-Z]{3}\d{0,4})\s+\d\s+([A-Z]{3})\s?([A-Z]{3})\s+[A-Z]{2}\d+\s+(\d{3,4})\s+(\d{3,4})\s*([+\-]\d+)?(?:\s+(\d{1,2}[A-Z]{3}\d{0,4}))?/i);
  if (p) return mk(p[1],p[2],p[3],p[4],p[5],p[6],p[7].padStart(4,"0"),p[8].padStart(4,"0"),p[9]||null,p[10]||null,rawLine);

  // Pattern B: Amadeus/Sabre with leading number and dot e.g. "1 . EY 658 L 20SEP KWIAUH HS1 2225 0105"
  p = line.match(/^\s*\d+\s*\.?\s+([A-Z0-9]{2})\s+(\d{1,4})\s+([A-Z])\s+(\d{1,2}[A-Z]{3}\d{0,4})\s+(?:\d\s+)?([A-Z]{3})\s?([A-Z]{3})\s+[A-Z]{2}\d+\s+(\d{3,4})\s+(\d{3,4})\s*([+\-]\d+)?(?:\s+(\d{1,2}[A-Z]{3}\d{0,4}))?/i);
  if (p) return mk(p[1],p[2],p[3],p[4],p[5],p[6],p[7].padStart(4,"0"),p[8].padStart(4,"0"),p[9]||null,p[10]||null,rawLine);

  // Pattern C: Kuwait Airways / Simple – no status code
  p = line.match(/^\s*\d+\s*\.?\s+([A-Z0-9]{2})\s+(\d{1,4})\s+([A-Z])\s+(\d{1,2}[A-Z]{3}\d{0,4})\s+([A-Z]{3})\s?([A-Z]{3})\s+(\d{3,4})\s+(\d{3,4})\s*([+\-]\d+)?/i);
  if (p) return mk(p[1],p[2],p[3],p[4],p[5],p[6],p[7].padStart(4,"0"),p[8].padStart(4,"0"),p[9]||null,null,rawLine);

  // Pattern D: No leading number, no status
  p = line.match(/^([A-Z0-9]{2})\s+(\d{1,4})\s+([A-Z])\s+(\d{1,2}[A-Z]{3}\d{0,4})\s+([A-Z]{3})\s?([A-Z]{3})\s+(\d{3,4})\s+(\d{3,4})\s*([+\-]\d+)?/i);
  if (p) return mk(p[1],p[2],p[3],p[4],p[5],p[6],p[7].padStart(4,"0"),p[8].padStart(4,"0"),p[9]||null,null,rawLine);

  // Pattern E: Worldspan – with day diff inline
  p = line.match(/^([A-Z0-9]{2})\s+(\d{1,4})\s+([A-Z])\s+(\d{1,2}[A-Z]{3}\d{0,4})\s+([A-Z]{3})\s([A-Z]{3})\s+[A-Z]{2}\d+\s+(\d{3,4})([+\-]\d+)?\s+(\d{3,4})([+\-]\d+)?/i);
  if (p) {
    const off = (p[8]||p[10]||"").replace("+","");
    return mk(p[1],p[2],p[3],p[4],p[5],p[6],p[7].padStart(4,"0"),p[9].padStart(4,"0"),off?parseInt(off):null,null,rawLine);
  }

  // Pattern F: Ultra-flexible fallback (last resort)
  p = line.match(/([A-Z0-9]{2})\s+(\d{1,4})\s+([A-Z])\s+(\d{1,2}[A-Z]{3}\d{0,4}).*?([A-Z]{3})\s*([A-Z]{3}).*?(\d{4})\s+(\d{4})/i);
  if (p) {
    const al=p[1].toUpperCase();
    if (AIRLINE_CODES.has(al)||al.match(/^[A-Z]{2}$/))
      return mk(al,p[2],p[3],p[4],p[5],p[6],p[7],p[8],null,null,rawLine);
  }

  return null;
}

function parsePNR(text) {
  const segments = [], seen = new Set();
  for (const line of text.split("\n")) {
    const seg = parsePNRLine(line);
    if (seg) {
      const key = `${seg.airline}${seg.flightNum}${seg.depDate}${seg.from}${seg.to}`;
      if (!seen.has(key)) { seen.add(key); segments.push(seg); }
    }
  }
  return segments;
}

function enrichSegment(seg) {
  const ai = (typeof AIRLINES!=="undefined"&&AIRLINES[seg.airline])||{name:seg.airline,color:"#0891b2"};
  seg.airlineName  = ai.name;
  seg.airlineColor = ai.color;

  const fA = (typeof AIRPORTS!=="undefined"&&AIRPORTS[seg.from])||{city:seg.from,name:seg.from+" Airport"};
  const tA = (typeof AIRPORTS!=="undefined"&&AIRPORTS[seg.to]  )||{city:seg.to,  name:seg.to+" Airport"};
  seg.fromCity=fA.city; seg.fromName=fA.name;
  seg.toCity  =tA.city; seg.toName  =tA.name;

  // Arabic city names
  seg.fromCityAr = AIRPORTS_AR[seg.from] || seg.fromCity;
  seg.toCityAr   = AIRPORTS_AR[seg.to]   || seg.toCity;

  const isAr = currentLang === "ar";
  seg.cabin    = CABIN_MAP[seg.cabinCode]    || "Economy";
  seg.cabinAr  = CABIN_MAP_AR[seg.cabinCode] || "درجة اقتصادية";

  seg.depMins = parseTime(seg.depTime);
  seg.arrMins = parseTime(seg.arrTime);

  if (seg.nextDayOffset!==null&&seg.nextDayOffset!==undefined) {
    seg.dayDiff = Math.abs(seg.nextDayOffset);
  } else {
    const dD=parseDateStr(seg.depDate), aD=parseDateStr(seg.arrDate);
    if (dD&&aD&&seg.depDate!==seg.arrDate) {
      seg.dayDiff = Math.max(0, daysBetweenDates(dD,aD));
    } else {
      seg.dayDiff = (seg.arrMins!==null&&seg.depMins!==null&&seg.arrMins<seg.depMins)?1:0;
    }
  }

  const dur = calcDuration(seg.depMins,seg.arrMins,seg.dayDiff);
  const durAr = calcDurationAr(seg.depMins,seg.arrMins,seg.dayDiff);
  seg.duration   = dur.label;
  seg.durationAr = durAr.label;
  seg.durationMins = dur.mins;
  const d = getDistance(seg.from,seg.to);
  seg.distKm=d; seg.distMiles=d?Math.round(d*0.621371):null;
  return seg;
}

// ── Airline Logo HTML ─────────────────────────────────────────
// Source: pnrconverter.com (same CDN used by professional PNR tools)
// Fallback: colored SVG badge (always visible, no broken icon)
function _makeBadgeSVG(code, color, size) {
  const c   = color || "#0891b2";
  const lbl = (code||"??").slice(0,2).toUpperCase();
  const s   = size || 36;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${s}" height="${s}" viewBox="0 0 ${s} ${s}"><circle cx="${s/2}" cy="${s/2}" r="${s/2}" fill="${c}"/><text x="50%" y="50%" dominant-baseline="central" text-anchor="middle" fill="#fff" font-size="${s<=28?9:11}" font-family="Arial,sans-serif" font-weight="800">${lbl}</text></svg>`;
}

function airlineLogoHTML(seg, showLogo) {
  if (!showLogo) return "";
  const code  = (seg.airline || "").toLowerCase(); // lowercase for URL
  const codeU = code.toUpperCase();
  const color = seg.airlineColor || "#0891b2";
  const name  = seg.airlineName  || codeU;

  // pnrconverter.com – the same source used by professional PNR tools
  const src = `https://www.pnrconverter.com/images/airlines/png/150/${code}.png`;

  // SVG badge fallback – shown instantly if image fails
  const fallbackSVG = _makeBadgeSVG(codeU, color, 48);
  const fallbackURI = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(fallbackSVG);

  return `<span class="airline-logo-wrap" title="${name}">` +
    `<img src="${src}" alt="${codeU}" width="48" height="48"` +
    ` style="object-fit:contain;background:#fff;padding:3px;border-radius:8px;border:1px solid #e2e8f0;display:block;"` +
    ` onerror="this.onerror=null;this.src='${fallbackURI}';this.style.cssText='border-radius:50%;object-fit:cover;border:none;background:transparent;padding:0;width:48px;height:48px;display:block;';"` +
    `/>` +
    `</span>`;
}

// ── Email logo ────────────────────────────────────────────────
function airlineLogoEmail(seg, showLogo) {
  if (!showLogo) return "";
  const code  = (seg.airline || "").toLowerCase();
  const codeU = (seg.airline || "").toUpperCase().slice(0,2);
  const color = seg.airlineColor || "#0891b2";
  const src   = `https://www.pnrconverter.com/images/airlines/png/150/${code}.png`;

  // Build fallback as a data-URI SVG so onerror never injects raw HTML
  const fallbackSVG = _makeBadgeSVG(codeU, color, 48);
  const fallbackURI = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(fallbackSVG);

  // onerror only sets src to data-URI – no HTML injection, no broken tags
  return `<img src="${src}" alt="${codeU}" width="48" height="48"` +
    ` style="border-radius:6px;object-fit:contain;border:1px solid #ddd;background:#fff;padding:3px;vertical-align:middle;"` +
    ` onerror="this.onerror=null;this.src=&#39;${fallbackURI}&#39;;this.style.borderRadius=&#39;50%&#39;;this.style.padding=&#39;0&#39;;this.style.border=&#39;none&#39;;"` +
    `>`;
}

function fmtTime(m,u) { return minsToStr(m,u); }
function dayDiffBadge(d) { return d?`<sup style="color:#f97316;font-size:10px;font-weight:700;margin-left:2px;">+${d}</sup>`:""; }

// ── Render TABLE ──────────────────────────────────────────────
function renderTable(segs, opts) {
  const isAr = currentLang==="ar";
  const lbl = {
    date:   isAr?"التاريخ":"Date",
    airline:isAr?"شركة الطيران":"Airline",
    flight: isAr?"رقم الرحلة":"Flight",
    dep:    isAr?"المغادرة":"Departs",
    from:   isAr?"من":"From",
    arr:    isAr?"الوصول":"Arrives",
    to:     isAr?"إلى":"To",
    dur:    isAr?"المدة":"Duration",
    cls:    isAr?"الدرجة":"Class",
    dist:   isAr?"المسافة":"Distance",
    bag:    isAr?"الأمتعة":"Baggage"
  };

  let cols=[lbl.date];
  if (opts.showLogo||opts.showAirline) cols.push(lbl.airline);
  if (opts.showFlightNum) cols.push(lbl.flight);
  cols.push(lbl.dep,lbl.from,lbl.arr,lbl.to);
  if (opts.showDuration) cols.push(lbl.dur);
  if (opts.showCabin)    cols.push(lbl.cls);
  if (opts.showDistance) cols.push(lbl.dist);
  if (opts.showBaggage)  cols.push(lbl.bag);

  let html=`<div style="overflow-x:auto;"><table class="itin-table" ${isAr?'dir="rtl"':''}><thead><tr>`;
  cols.forEach(c=>html+=`<th>${c}</th>`);
  html+=`</tr></thead><tbody>`;

  segs.forEach((seg,i)=>{
    if (i>0&&opts.showTransit) {
      const t=getTransitInfo(segs[i-1],seg);
      if (t) {
        const tl=isAr?t.labelAr:t.label;
        const tranLbl = isAr?`ترانزيت في ${segs[i-1].to}: ${tl}`:`Transit at ${segs[i-1].to}: ${tl}`;
        html+=`<tr class="transit-row"><td colspan="${cols.length}"><span>⏱️ ${tranLbl}</span></td></tr>`;
      } else {
        const sepLbl = isAr?`رحلة منفصلة`:`Separate Flight`;
        html+=`<tr class="flight-sep-row"><td colspan="${cols.length}"><span>✈️ ${sepLbl}</span></td></tr>`;
      }
    }
    const bagVal = opts.baggageMode==="multi"?(seg.baggageOverride||""):opts.baggageValue;
    const depStr=fmtTime(seg.depMins,opts.use12hr), arrStr=fmtTime(seg.arrMins,opts.use12hr);
    const cityFrom = isAr ? seg.fromCityAr : seg.fromCity;
    const cityTo   = isAr ? seg.toCityAr   : seg.toCity;
    const cabinStr = isAr ? seg.cabinAr : seg.cabin;
    const durStr   = isAr ? seg.durationAr : seg.duration;

    html+=`<tr>`;
    html+=`<td style="white-space:nowrap;font-weight:600;">${formatDate(seg.depDate, isAr)}</td>`;
    if (opts.showLogo||opts.showAirline) {
      html+=`<td style="white-space:nowrap;">
        <div style="display:flex;align-items:center;gap:10px;${isAr?"flex-direction:row-reverse;":""}">
          ${airlineLogoHTML(seg,opts.showLogo)}
          ${opts.showAirline?`<span style="font-size:13px;font-weight:600;color:#0a1628;">${seg.airlineName}</span>`:""}
        </div>
      </td>`;
    }
    if (opts.showFlightNum) html+=`<td style="font-family:monospace;font-weight:600;">${seg.airline} ${seg.flightNum}</td>`;
    html+=`<td style="font-weight:700;font-size:15px;">${depStr}</td>`;
    html+=`<td><strong>${seg.from}</strong><br><small style="color:#64748b;">${cityFrom}</small></td>`;
    html+=`<td style="font-weight:700;font-size:15px;">${arrStr}${dayDiffBadge(seg.dayDiff)}</td>`;
    html+=`<td><strong>${seg.to}</strong><br><small style="color:#64748b;">${cityTo}</small></td>`;
    if (opts.showDuration) html+=`<td style="color:#0891b2;font-weight:500;">${durStr}</td>`;
    if (opts.showCabin)    html+=`<td>${cabinStr}</td>`;
    if (opts.showDistance) {
      const dv=opts.distUnit==="km"?(seg.distKm?seg.distKm+(isAr?" كم":" KM"):"–"):(seg.distMiles?seg.distMiles+(isAr?" ميل":" mi"):"–");
      html+=`<td style="color:#64748b;">${dv}</td>`;
    }
    if (opts.showBaggage) html+=`<td style="color:#0891b2;font-weight:600;">${bagVal?`🧳 ${bagVal}`:"–"}</td>`;
    html+=`</tr>`;
  });

  html+=`</tbody></table></div>`;
  return html;
}

// ── Render CARDS ──────────────────────────────────────────────
function renderLines(segs, opts) {
  const isAr = currentLang==="ar";
  let html=`<div class="itin-lines" ${isAr?'dir="rtl"':''}>`;

  segs.forEach((seg,i)=>{
    if (i>0&&opts.showTransit) {
      const t=getTransitInfo(segs[i-1],seg);
      if (t) {
        const msg=isAr?`ترانزيت في ${segs[i-1].to} – ${seg.fromCityAr||segs[i-1].toCity}: ${t.labelAr}`
                      :`Transit at ${segs[i-1].to} – ${segs[i-1].toCity}: ${t.label} layover`;
        html+=`<div class="transit-divider">⏱️ <strong>${msg}</strong></div>`;
      } else {
        const msg=isAr?`رحلة منفصلة`:`Separate Flight`;
        html+=`<div class="flight-sep-divider">✈️ <strong>${msg}</strong></div>`;
      }
    }
    const bagVal=opts.baggageMode==="multi"?(seg.baggageOverride||""):opts.baggageValue;
    const depStr=fmtTime(seg.depMins,opts.use12hr), arrStr=fmtTime(seg.arrMins,opts.use12hr);
    const distStr=opts.showDistance?(opts.distUnit==="km"?(seg.distKm?` · ${seg.distKm} ${isAr?"كم":"KM"}`:""):(seg.distMiles?` · ${seg.distMiles} ${isAr?"ميل":"mi"}`:"")):"";
    const cityFrom = isAr ? seg.fromCityAr : seg.fromCity;
    const cityTo   = isAr ? seg.toCityAr   : seg.toCity;
    const cabinStr = isAr ? seg.cabinAr : seg.cabin;
    const durStr   = isAr ? seg.durationAr : seg.duration;
    const flightLbl = isAr ? "رحلة" : "Flight";

    html+=`<div class="itin-segment">
      <div class="itin-seg-header">
        <div class="seg-airline">
          ${airlineLogoHTML(seg,opts.showLogo)}
          ${opts.showAirline?`<span>${seg.airlineName}</span>`:""}
          ${opts.showFlightNum?`<span style="font-size:13px;opacity:.85;">${flightLbl} ${seg.airline}${seg.flightNum}</span>`:""}
        </div>
        <div class="seg-meta">
          <span>📅 ${formatDate(seg.depDate, isAr)}</span>
          ${opts.showDuration?`<span>⏱️ ${durStr}</span>`:""}
          ${opts.showCabin?`<span>${cabinStr}${distStr}</span>`:""}
          ${opts.showBaggage&&bagVal?`<span>🧳 ${bagVal}</span>`:""}
        </div>
      </div>
      <div class="itin-seg-body">
        <div class="seg-airport">
          <div class="time">${depStr}</div>
          <div class="code">${seg.from}</div>
          <div class="city">${cityFrom}</div>
        </div>
        <div class="seg-arrow">
          <div class="duration-line"><div class="dur-bar"></div></div>
          <small style="font-size:11px;color:#94a3b8;">${opts.showDuration?durStr:""}</small>
        </div>
        <div class="seg-airport right" style="text-align:${isAr?"left":"right"};">
          <div class="time">${arrStr}${dayDiffBadge(seg.dayDiff)}</div>
          <div class="code">${seg.to}</div>
          <div class="city">${cityTo}</div>
        </div>
      </div>
    </div>`;
  });

  html+=`</div>`;
  return html;
}

// ── Render EMAIL ──────────────────────────────────────────────
function renderEmail(segs, opts, passenger, signOff) {
  const isAr = currentLang==="ar";
  const dest  = segs.length>0?((typeof AIRPORTS!=="undefined"&&AIRPORTS[segs[segs.length-1].to]?.city)||segs[segs.length-1].to):(isAr?"وجهتك":"Your Destination");
  const destAr = segs.length>0?(AIRPORTS_AR[segs[segs.length-1].to]||dest):dest;
  const pName = passenger||(isAr?"المسافر الكريم":"Valued Passenger");
  const greeting = isAr?`عزيزي ${pName}،<br><br>يسعدنا مشاركتك تفاصيل رحلتك:`
                       :`Dear ${pName},<br><br>Please find your flight itinerary below:`;
  const subj = isAr?`رحلاتك إلى ${destAr}`:`Your Flights to ${dest}`;

  const lbl = {
    date:   isAr?"التاريخ":"Date",
    airline:isAr?"شركة الطيران":"Airline",
    flight: isAr?"رقم الرحلة":"Flight",
    dep:    isAr?"المغادرة":"Departs",
    from:   isAr?"من":"From",
    arr:    isAr?"الوصول":"Arrives",
    to:     isAr?"إلى":"To",
    dur:    isAr?"المدة":"Duration",
    cls:    isAr?"الدرجة":"Class",
    dist:   isAr?"المسافة":"Distance",
    bag:    isAr?"الأمتعة":"Baggage"
  };

  const thStyle = `padding:9px 12px;background:#1e293b;color:#fff;font-size:11px;text-transform:uppercase;`;
  let headerRow = opts.showLogo?`<th style="${thStyle}"></th>`:"";
  headerRow+=`<th style="${thStyle}">${lbl.date}</th>`;
  if (opts.showAirline)   headerRow+=`<th style="${thStyle}">${lbl.airline}</th>`;
  if (opts.showFlightNum) headerRow+=`<th style="${thStyle}">${lbl.flight}</th>`;
  headerRow+=`<th style="${thStyle}">${lbl.dep}</th>`;
  headerRow+=`<th style="${thStyle}">${lbl.from}</th>`;
  headerRow+=`<th style="${thStyle}">${lbl.arr}</th>`;
  headerRow+=`<th style="${thStyle}">${lbl.to}</th>`;
  if (opts.showDuration)  headerRow+=`<th style="${thStyle}">${lbl.dur}</th>`;
  if (opts.showCabin)     headerRow+=`<th style="${thStyle}">${lbl.cls}</th>`;
  if (opts.showDistance)  headerRow+=`<th style="${thStyle}">${lbl.dist}</th>`;
  if (opts.showBaggage)   headerRow+=`<th style="${thStyle}">${lbl.bag}</th>`;

  let rows="";
  segs.forEach((seg,i)=>{
    if (i>0&&opts.showTransit) {
      const t=getTransitInfo(segs[i-1],seg);
      const colspan = 2 + (opts.showAirline?1:0) + (opts.showFlightNum?1:0) + (opts.showDuration?1:0) + (opts.showCabin?1:0) + (opts.showDistance?1:0) + (opts.showBaggage?1:0) + (opts.showLogo?1:0);
      if (t) {
        const msg=isAr?`✈ ترانزيت في ${segs[i-1].to} – ${t.labelAr}`:`✈ Transit at ${segs[i-1].to} – ${t.label} layover`;
        rows+=`<tr><td colspan="${colspan}" style="background:#fff7ed;color:#c2410c;font-size:12px;padding:6px 12px;text-align:center;font-family:Arial,sans-serif;">${msg}</td></tr>`;
      } else {
        const msg=isAr?`✈ رحلة منفصلة`:`✈ Separate Flight`;
        rows+=`<tr><td colspan="${colspan}" style="background:#f1f5f9;color:#334155;font-size:12px;padding:6px 12px;text-align:center;font-family:Arial,sans-serif;">${msg}</td></tr>`;
      }
    }
    const bagVal=opts.baggageMode==="multi"?(seg.baggageOverride||""):opts.baggageValue;
    const depStr=fmtTime(seg.depMins,opts.use12hr), arrStr=fmtTime(seg.arrMins,opts.use12hr);
    const dv=opts.showDistance?(opts.distUnit==="km"?(seg.distKm?seg.distKm+(isAr?" كم":" KM"):"–"):(seg.distMiles?seg.distMiles+(isAr?" ميل":" mi"):"–")):"";
    const bg=i%2===0?"#ffffff":"#f8fafc";
    const cityFrom = isAr ? seg.fromCityAr : seg.fromCity;
    const cityTo   = isAr ? seg.toCityAr   : seg.toCity;
    const cabinStr = isAr ? seg.cabinAr : seg.cabin;
    const durStr   = isAr ? seg.durationAr : seg.duration;

    const tdS = "padding:10px 12px;vertical-align:middle;border-bottom:1px solid #e8edf5;font-size:14px;font-family:Arial,sans-serif;";

    // Logo cell – fixed 54px wide so logo never squishes
    const logoCell = opts.showLogo
      ? `<td style="padding:8px 10px;vertical-align:middle;border-bottom:1px solid #e8edf5;width:54px;text-align:center;">${airlineLogoEmail(seg, true)}</td>`
      : "";

    rows+=`<tr style="background:${bg};">
      ${logoCell}
      <td style="${tdS}font-weight:600;white-space:nowrap;">${formatDate(seg.depDate, isAr)}</td>
      ${opts.showAirline?`<td style="${tdS}font-weight:600;">${seg.airlineName}</td>`:""}
      ${opts.showFlightNum?`<td style="${tdS}font-family:monospace;">${seg.airline}${seg.flightNum}</td>`:""}
      <td style="${tdS}font-weight:700;">${depStr}</td>
      <td style="${tdS}"><strong>${seg.from}</strong><br><span style="color:#64748b;font-size:12px;">${cityFrom}</span></td>
      <td style="${tdS}font-weight:700;">${arrStr}${dayDiffBadge(seg.dayDiff)}</td>
      <td style="${tdS}"><strong>${seg.to}</strong><br><span style="color:#64748b;font-size:12px;">${cityTo}</span></td>
      ${opts.showDuration?`<td style="${tdS}color:#0891b2;">${durStr}</td>`:""}
      ${opts.showCabin?`<td style="${tdS}">${cabinStr}</td>`:""}
      ${opts.showDistance?`<td style="${tdS}color:#64748b;">${dv}</td>`:""}
      ${opts.showBaggage?`<td style="${tdS}color:#0891b2;font-weight:600;">${bagVal||"–"}</td>`:""}
    </tr>`;
  });

  const soHtml = signOff?`<div style="margin-top:24px;padding-top:16px;border-top:1px solid #e2e8f0;font-size:14px;color:#334155;line-height:1.8;">${signOff.replace(/\n/g,"<br>")}</div>`:"";

  return `<div class="itin-email" style="font-family:Arial,sans-serif;max-width:760px;direction:${isAr?"rtl":"ltr"};">
    <div class="email-header" style="background:#0a1628;border-radius:10px 10px 0 0;padding:16px 20px;font-size:13px;color:rgba(255,255,255,.65);">
      <div><strong style="color:#f0c060;">${isAr?"إلى:":"To:"}</strong> ${pName}</div>
      <div><strong style="color:#f0c060;">${isAr?"الموضوع:":"Subject:"}</strong> ${subj}</div>
    </div>
    <div style="border:1px solid #dde4f0;border-top:none;border-radius:0 0 10px 10px;padding:26px 30px;background:#fff;">
      <div style="font-size:15px;margin-bottom:18px;color:#1a2744;">${greeting}</div>
      <table style="width:100%;border-collapse:collapse;font-size:13px;" ${isAr?'dir="rtl"':''}>
        <thead><tr>${headerRow}</tr></thead>
        <tbody>${rows}</tbody>
      </table>
      ${soHtml}
    </div>
  </div>`;
}

// ── Fare Summary – clean, professional (fare + fee combined) ──
function buildFareSummary(currency) {
  const isAr = currentLang==="ar";
  const curr = currency||"KWD";
  const sym  = {USD:"$",EUR:"€",GBP:"£",AUD:"A$",NZD:"NZ$",SAR:"ر.س",AED:"د.إ",KWD:"د.ك",BHD:"BD",QAR:"ر.ق",OMR:"ر.ع"}[curr]||curr;
  const dp   = ["KWD","BHD","OMR"].includes(curr)?3:2;

  const av=parseFloat(document.getElementById("adultFare")?.value)||0;
  const af=parseFloat(document.getElementById("adultFee")?.value)||0;
  const cv=parseFloat(document.getElementById("childFare")?.value)||0;
  const cf=parseFloat(document.getElementById("childFee")?.value)||0;
  const iv=parseFloat(document.getElementById("infantFare")?.value)||0;
  const nf=parseFloat(document.getElementById("infantFee")?.value)||0;

  if (!av&&!cv&&!iv) return "";

  // Combine fare + fee for each pax type
  const aTotal=av+af, cTotal=cv+cf, iTotal=iv+nf;
  const grand = aTotal+cTotal+iTotal;

  const dir = isAr ? "rtl" : "ltr";
  const adultLbl  = isAr?"أجرة البالغ":"Adult Fare";
  const childLbl  = isAr?"أجرة الطفل":"Child Fare";
  const infantLbl = isAr?"أجرة الرضيع":"Infant Fare";
  const totalLbl  = isAr?"الإجمالي الكلي":"Grand Total";

  // Real <table> with fully inline styles so this block survives copy/paste into
  // Gmail/Outlook/WhatsApp Web etc. (external CSS classes are stripped by email
  // clients — the old flex-based classes collapsed into an unstyled, "misaligned" mess).
  const tdLbl = `padding:11px 16px;border-top:1px solid #dde4f0;font-size:13px;color:#5a6a8a;font-family:Arial,Helvetica,sans-serif;${isAr?"text-align:right;":"text-align:left;"}`;
  const tdVal = `padding:11px 16px;border-top:1px solid #dde4f0;font-size:14px;font-weight:700;color:#0a1628;font-family:Arial,Helvetica,sans-serif;${isAr?"text-align:left;":"text-align:right;"}`;

  let rows="";
  if (aTotal>0) rows+=`<tr><td style="${tdLbl}">👤 ${adultLbl}</td><td style="${tdVal}">${sym}&nbsp;${aTotal.toFixed(dp)}</td></tr>`;
  if (cTotal>0) rows+=`<tr><td style="${tdLbl}">🧒 ${childLbl}</td><td style="${tdVal}">${sym}&nbsp;${cTotal.toFixed(dp)}</td></tr>`;
  if (iTotal>0) rows+=`<tr><td style="${tdLbl}">👶 ${infantLbl}</td><td style="${tdVal}">${sym}&nbsp;${iTotal.toFixed(dp)}</td></tr>`;

  return `<table dir="${dir}" cellpadding="0" cellspacing="0" style="margin-top:22px;border-radius:10px;overflow:hidden;border:1px solid rgba(212,168,67,0.3);background:#ffffff;box-shadow:0 2px 12px rgba(10,22,40,0.08);font-family:Arial,Helvetica,sans-serif;width:100%;border-collapse:collapse;">
    <tr><td colspan="2" style="background:#0a1628;color:#f0c060;font-size:13px;font-weight:700;padding:10px 16px;letter-spacing:0.03em;text-transform:uppercase;${isAr?"text-align:right;":"text-align:left;"}">💰 ${isAr?"ملخص الأسعار":"Fare Summary"}</td></tr>
    ${rows}
    <tr>
      <td style="padding:12px 16px;background:#f0f4fc;border-top:2px solid rgba(212,168,67,0.4);font-size:13px;font-weight:700;color:#0a1628;text-transform:uppercase;letter-spacing:0.04em;font-family:Arial,Helvetica,sans-serif;${isAr?"text-align:right;":"text-align:left;"}">${totalLbl}</td>
      <td style="padding:12px 16px;background:#f0f4fc;border-top:2px solid rgba(212,168,67,0.4);font-size:18px;font-weight:800;color:#0d9488;font-family:Arial,Helvetica,sans-serif;${isAr?"text-align:left;":"text-align:right;"}">${sym}&nbsp;${grand.toFixed(dp)}</td>
    </tr>
  </table>`;
}

// ── Fixed-format share message (WhatsApp + Copy Text) ──────────
// Arabic name + flag lookup for the airlines agents use most often.
// Falls back to the airline's English name / a plain plane emoji if unknown.
const AIRLINE_NAME_AR = {
  KU:"الخطوط الجوية الكويتية",EK:"طيران الإمارات",EY:"الاتحاد للطيران",QR:"الخطوط الجوية القطرية",
  WY:"الطيران العماني",TK:"الخطوط الجوية التركية",SV:"الخطوط السعودية",GF:"طيران الخليج",
  RJ:"الملكية الأردنية",MS:"مصر للطيران",FZ:"فلاي دبي",G9:"طيران العربية",
  BA:"الخطوط الجوية البريطانية",LH:"لوفتهانزا",AF:"الخطوط الجوية الفرنسية",KL:"كي إل إم",
  TG:"طيران تايلاند",SQ:"طيران سنغافورة",CX:"كاثي باسيفيك",MH:"طيران ماليزيا",
  AI:"طيران الهند",PK:"الخطوط الجوية الباكستانية",JL:"الخطوط الجوية اليابانية",NH:"أول نيبون إيرويز",
  KE:"طيران كوريا",QF:"كانتاس",NZ:"طيران نيوزيلندا",AA:"أمريكان إيرلاينز",UA:"يونايتد إيرلاينز",
  DL:"دلتا إيرلاينز",ET:"الخطوط الإثيوبية",IB:"الخطوط الجوية الإسبانية",AZ:"إيتا إيرويز",
  LX:"سويس إير",OS:"النمساوية",SN:"بروكسل إيرلاينز",TP:"تاب البرتغالية"
};
const AIRLINE_FLAGS = {
  KU:"🇰🇼",EK:"🇦🇪",EY:"🇦🇪",QR:"🇶🇦",WY:"🇴🇲",TK:"🇹🇷",SV:"🇸🇦",GF:"🇧🇭",
  RJ:"🇯🇴",MS:"🇪🇬",FZ:"🇦🇪",G9:"🇦🇪",BA:"🇬🇧",LH:"🇩🇪",AF:"🇫🇷",KL:"🇳🇱",
  IB:"🇪🇸",AZ:"🇮🇹",OS:"🇦🇹",LX:"🇨🇭",SN:"🇧🇪",TP:"🇵🇹",SK:"🇸🇪",AY:"🇫🇮",
  TG:"🇹🇭",SQ:"🇸🇬",CX:"🇭🇰",MH:"🇲🇾",GA:"🇮🇩",VN:"🇻🇳",PR:"🇵🇭",
  AI:"🇮🇳",PK:"🇵🇰",BG:"🇧🇩",UL:"🇱🇰",JL:"🇯🇵",NH:"🇯🇵",KE:"🇰🇷",OZ:"🇰🇷",
  CA:"🇨🇳",MU:"🇨🇳",HU:"🇨🇳",CI:"🇹🇼",QF:"🇦🇺",NZ:"🇳🇿",
  AA:"🇺🇸",UA:"🇺🇸",DL:"🇺🇸",AC:"🇨🇦",ET:"🇪🇹",KQ:"🇰🇪"
};

function arTimePeriod(hour) {
  if (hour<5)  return "منتصف الليل";
  if (hour<12) return "صباحاً";
  if (hour<13) return "ظهراً";
  if (hour<18) return "عصراً";
  return "مساءً";
}
function fmtTimeShare(mins, isAr) {
  if (mins===null||mins===undefined) return "--:--";
  mins = ((mins%1440)+1440)%1440;
  const h=Math.floor(mins/60), m=mins%60;
  const h12 = h===0?12:(h>12?h-12:h);
  const mm = String(m).padStart(2,"0");
  return isAr ? `${h12}:${mm} ${arTimePeriod(h)}` : `${h12}:${mm} ${h<12?"AM":"PM"}`;
}

// Builds the single, fixed share format used by both "Copy Text" and the
// WhatsApp message tool — airline, date, route, departure, transit (if any),
// arrival, baggage weight, and a blank price line for the agent to fill in.
function buildStructuredShareText(segs, opts, isAr) {
  if (!segs || !segs.length) return "";
  const legs = groupIntoLegs(segs);
  const sep = "▬".repeat(30);
  const blocks = [];

  legs.forEach((leg, li) => {
    const first = leg[0], last = leg[leg.length-1];
    const airlineName = isAr ? (AIRLINE_NAME_AR[first.airline] || first.airlineName) : first.airlineName;
    const flag = AIRLINE_FLAGS[first.airline] || "";
    const legLabel = legs.length===2
      ? (li===0 ? (isAr?"رحلة الذهاب":"Outbound Flight") : (isAr?"رحلة العودة":"Return Flight"))
      : (isAr?`الرحلة ${li+1}`:`Flight ${li+1}`);

    const routeCodes = [first, ...leg.slice(1)];
    const cities = [ (isAr?first.fromCityAr:first.fromCity)+` (${first.from})` ]
      .concat(leg.map(s => (isAr?s.toCityAr:s.toCity)+` (${s.to})`));
    const arrow = isAr ? "⬅️" : "➡️";
    const routeLine = cities.map(c=>"`"+c+"`").join(` ${arrow} `);

    const lines = [];
    lines.push(`*${airlineName} ✈️${flag}*`);
    lines.push(`${legLabel} | ${formatDate(first.depDate, isAr)}`);
    lines.push("");
    lines.push(`*✈️ ${isAr?"المسار":"Route"}:*`);
    lines.push(` ${routeLine}`);
    lines.push("");
    lines.push(`* 🛫 ${isAr?"الإقلاع":"Departure"}: ${fmtTimeShare(first.depMins,isAr)}`);
    for (let i=1;i<leg.length;i++) {
      const t = getTransitInfo(leg[i-1], leg[i]);
      if (t) {
        const cityName = isAr ? leg[i-1].toCityAr : leg[i-1].toCity;
        lines.push(`* 🔄 ${isAr?"ترانزيت في":"Transit in"} ${cityName} (${leg[i-1].to}): ${isAr?t.labelAr:t.label}`);
      }
    }
    lines.push(`* 🛬 ${isAr?"الوصول":"Arrival"}: ${fmtTimeShare(last.arrMins,isAr)}`);
    blocks.push(lines.join("\n"));
  });

  const baggage = (opts && opts.showBaggage && opts.baggageValue) ? opts.baggageValue : (isAr?"يُحدد لاحقاً":"TBA");

  const out = [];
  out.push(blocks.join(`\n\n${sep}\n\n`));
  out.push("");
  out.push(sep);
  out.push("");
  out.push(`*${isAr?"الأمتعة المسموحة":"Baggage Allowance"}:*`);
  out.push(`🧳 ${isAr?"الوزن المسموح":"Allowance"}: ${baggage}`);
  out.push("");
  out.push(`*💰 ${isAr?"السعر الإجمالي":"Total Price"}:*`);
  out.push("");
  return out.join("\n");
}

// ── Gather options ────────────────────────────────────────────
function gatherOpts() {
  const mode=document.querySelector("input[name='baggageMode']:checked")?.value||"single";
  let baggageValue="", baggageMap={};
  if (mode==="single") { baggageValue=(document.getElementById("baggageValue")||{value:""}).value.trim(); }
  else {
    const raw=(document.getElementById("baggageMultiValue")||{value:""}).value.trim();
    raw.split(/\n/).forEach(l=>{ const m=l.match(/(\d+)\s*[=:]\s*(.+)/); if(m) baggageMap[parseInt(m[1])]=m[2].trim(); });
  }
  return {
    showAirline:  document.getElementById("opt_airlineName")?.checked,
    showFlightNum:document.getElementById("opt_flightNum")?.checked,
    showLogo:     document.getElementById("opt_logo")?.checked,
    showDuration: document.getElementById("opt_duration")?.checked,
    showDistance: document.getElementById("opt_distance")?.checked,
    showTransit:  document.getElementById("opt_transit")?.checked,
    showCabin:    document.getElementById("opt_cabin")?.checked,
    use12hr:      document.getElementById("opt_12hr")?.checked,
    showBaggage:  document.getElementById("opt_baggage")?.checked,
    baggageMode:  mode, baggageValue, baggageMap,
    distUnit:     document.querySelector("input[name='distUnit']:checked")?.value||"km",
    format:       document.querySelector("input[name='fmt']:checked")?.value||"table"
  };
}

function doConvert() {
  const inputText=document.getElementById("pnrInput").value.trim();
  const isAr = currentLang==="ar";
  if (!inputText) {
    showError(isAr?"الرجاء لصق بيانات الرحلة أولاً!":"Please paste your GDS itinerary first!");
    return;
  }
  const opts     =gatherOpts();
  const currency =document.getElementById("currency").value;
  const passenger=document.getElementById("passengerName")?.value.trim();
  const signOff  =document.getElementById("agentSignOff")?.value.trim();
  const rawSegs  =parsePNR(inputText);

  if (rawSegs.length===0) {
    showError(isAr
      ?`<b>تعذّر قراءة أي رحلة.</b><br><small>تحقق من صيغة البيانات والصق نص GDS مباشرةً في الحقل.</small>`
      :`<b>Could not parse any flight segments.</b><br><small>Check PNR format and paste GDS text directly.</small>`);
    return;
  }

  const segments=rawSegs.map((seg,idx)=>{
    const s=enrichSegment(seg);
    if (opts.showBaggage&&opts.baggageMode==="multi") s.baggageOverride=opts.baggageMap[idx+1]||"";
    return s;
  });

  /* Use window.renderAndShow so features.js can override it properly */
  if (window._featuresRenderAndShow) {
    window._featuresRenderAndShow(segments,opts,currency,passenger,signOff);
  } else {
    renderAndShow(segments,opts,currency,passenger,signOff);
  }
}

function renderAndShow(segs,opts,currency,passenger,signOff) {
  let out="";
  if (opts.format==="table")      out=renderTable(segs,opts);
  else if (opts.format==="lines") out=renderLines(segs,opts);
  else if (opts.format==="email") out=renderEmail(segs,opts,passenger,signOff);

  out+=buildFareSummary(currency);

  document.getElementById("outputContent").innerHTML=out;
  const sec=document.getElementById("outputSection");
  sec.style.display="block";

  const eb=document.getElementById("copyEmailBtn");
  if (eb) eb.style.display=(opts.format==="email")?"inline-flex":"none";

  setTimeout(()=>sec.scrollIntoView({behavior:"smooth",block:"start"}),100);
}

function showError(msg) {
  document.getElementById("outputContent").innerHTML=`<div class="parse-error"><i class="fas fa-exclamation-triangle"></i> ${msg}</div>`;
  document.getElementById("outputSection").style.display="block";
}

// ── Copy functions ─────────────────────────────────────────────
function copyHTML() {
  const h=document.getElementById("outputContent").innerHTML;
  navigator.clipboard.writeText(h)
    .then(()=>flashBtn("copyHtmlBtn","✓"))
    .catch(()=>{fallbackCopy(h);flashBtn("copyHtmlBtn","✓");});
}
function copyText() {
  const isAr = currentLang==="ar";
  const segs = window._lastSegments;
  const opts = gatherOpts();
  let t = segs && segs.length ? buildStructuredShareText(segs, opts, isAr) : "";
  if (!t) t = document.getElementById("outputContent").innerText; // fallback safety net
  navigator.clipboard.writeText(t)
    .then(()=>flashBtn("copyTextBtn","✓"))
    .catch(()=>{fallbackCopy(t);flashBtn("copyTextBtn","✓");});
}
function copyEmail() {
  // Copy both text/html and text/plain so it pastes as rich table in email clients
  const h = document.getElementById("outputContent").innerHTML;
  const blob = new Blob([h], {type:"text/html"});
  try {
    navigator.clipboard.write([new ClipboardItem({"text/html": blob, "text/plain": new Blob([document.getElementById("outputContent").innerText],{type:"text/plain"})})]).then(()=>flashBtn("copyEmailBtn","✓")).catch(()=>{fallbackCopy(h);flashBtn("copyEmailBtn","✓");});
  } catch(e) {
    fallbackCopy(h);flashBtn("copyEmailBtn","✓");
  }
}
function fallbackCopy(text) {
  const ta=document.createElement("textarea");
  ta.value=text; ta.style.position="fixed"; ta.style.opacity="0";
  document.body.appendChild(ta); ta.select(); document.execCommand("copy");
  document.body.removeChild(ta);
}
function flashBtn(id,msg) {
  const b=document.getElementById(id); if(!b) return;
  const o=b.innerHTML;
  b.innerHTML=`<i class="fas fa-check"></i> ${msg}`; b.style.background="#dcfce7"; b.style.color="#059669";
  setTimeout(()=>{b.innerHTML=o;b.style.background="";b.style.color="";},2000);
}

function toggleBaggageMode(mode) {
  document.getElementById("baggageSingleBox").style.display=mode==="single"?"block":"none";
  document.getElementById("baggageMultiBox").style.display=mode==="multi"?"block":"none";
}
function toggleMobileNav() { document.getElementById("mobileNav").classList.toggle("open"); }

// ═══════════════════════════════════════════════════════════════
//   BILINGUAL ENGINE – Arabic ↔ English
//   setLang(lang) updates ALL text on the page
// ═══════════════════════════════════════════════════════════════
const I18N = {
en: {
  navHome:"Home",navHow:"How It Works",navFaq:"FAQ",navBlog:"Blog",navAbout:"About",navContact:"Contact",
  heroTitle:"Flight Itinerary <span>PNR Converter</span>",
  heroSub:"Transform raw GDS codes into beautiful, client-ready itineraries in seconds",
  cardTitle:"Paste Your PNR / Itinerary",
  cardHint:"Supports Galileo, Smartpoint, Amadeus, Sabre, Worldspan — Kuwait Airways, Emirates, Etihad & more",
  pnrPlaceholder:`Paste GDS text here… e.g.:\n\n--- Galileo ---\nNZ 456 H 26OCT 5 WLGAKL HK1 1945 2050\n\n--- Kuwait Airways ---\n1  KU 417 V 20SEP KWI MNL 0215 1655\n\n--- Amadeus/Sabre ---\n1. EY 658 L 20SEP KWIAUH HS1 2225 0105\n\nCtrl+Enter for quick convert`,
  fbColType:"Passenger",fbColFare:"Fare",fbColFee:"Fee",
  fbAdult:"Adult",fbChild:"Child",fbInfant:"Infant",fbCurrency:"Currency",
  convertBtn:"Convert Itinerary",
  extractBtn:"Extract & Convert",clearBtn:"Clear",
  optTitle:"Display Options",
  optAirlineName:"Show Airline Name",optFlightNum:"Show Flight Number",optLogo:"Show Airline Logo",
  optDuration:"Show Duration",optDistance:"Show Distance",optTransit:"Transit Time",
  optCabin:"Show Cabin Class",optOpBy:"Show Operated By",opt12hr:"12-Hour Clock",optBaggage:"Show Baggage",
  baggageSameAll:"Same for all flights",baggageDifferent:"Different per flight",
  baggageSinglePlaceholder:"e.g. 30 KG  /  2 Pieces",baggageSingleNote:"Applied to all flights",
  baggageMultiNote:"Format: flight number = weight (one per line)",
  baggageMultiPlaceholder:"1 = 30 KG\n2 = 23 KG",
  distUnit:"Distance Unit",distKM:"KM",distMiles:"Miles",
  resultsFormat:"Results Format",fmtTable:"Table",fmtCards:"Cards",fmtEmail:"Email",
  passengerLabel:"Passenger Name",passengerPlaceholder:"e.g. Ahmed Al-Rashidi",
  agentLabel:"Agent Sign-off",agentPlaceholder:"Kind regards,\nAhmed\nYour Travel Agency",
  convertedTitle:"Converted Itinerary",
  copyHtml:"Copy HTML",copyText:"Copy Text",copyEmail:"Copy Email",printBtn:"Print",
  howTitle:"The Clearest Free Flight Itinerary<br>Converter on the Web",
  howSub:"Instantly transform raw GDS booking codes into beautiful, readable travel itineraries",
  howStep1Title:"Paste Your PNR",howStep1Desc:"Copy raw itinerary text from your GDS and paste it in.",
  howStep2Title:"Choose Options",howStep2Desc:"Select format, currency, fare details, and display fields.",
  howStep3Title:"Convert",howStep3Desc:"Click Convert for a clean, professional client-ready itinerary.",
  howStep4Title:"Share",howStep4Desc:"Copy HTML or plain text and paste into your email or system.",
  aboutTitle:"Why Choose Itinovo",aboutSub:"Professional travel solutions built for agents and travelers",
  about1T:"Global Coverage",about1D:"300+ airports and 100+ airlines worldwide including full Middle East coverage.",
  about2T:"Instant Conversion",about2D:"No sign-up required. Paste your PNR and get a beautiful itinerary in milliseconds.",
  about3T:"Private & Secure",about3D:"All processing happens in your browser. We never store your itinerary data.",
  about4T:"100% Free",about4D:"Unlimited free conversions. No hidden fees or subscriptions required.",
  faqTitle:"Frequently Asked Questions",faqSub:"Everything you need to know about PNR conversion",
  faq1Q:"What is a PNR converter?",
  faq1A:"A <strong>PNR converter</strong> transforms raw GDS booking codes from Galileo, Amadeus, Sabre or Worldspan into clean, readable flight itineraries. Travel agents use it to quickly share professional itineraries with clients.",
  faq2Q:"How do I convert a PNR to a readable itinerary?",
  faq2A:"Paste your raw GDS itinerary text into the converter box, choose display options, then click <strong>Convert</strong>. Your itinerary will be instantly transformed into a professional, client-ready format.",
  faq3Q:"Which GDS systems are supported?",
  faq3A:"We support all major GDS systems: <strong>Galileo, Amadeus, Sabre, Worldspan,</strong> Smartpoint, and direct airline formats like Kuwait Airways (KU), Emirates (EK), Etihad (EY), and more.",
  faq4Q:"Is this PNR converter free?",
  faq4A:"Yes! <strong>100% free</strong> with no sign-up required. Unlimited conversions. All processing is in your browser so your data stays private.",
  faq5Q:"Can I use this for Kuwait Airways tickets?",
  faq5A:"Absolutely! Fully supports <strong>Kuwait Airways (KU)</strong> and all Gulf carriers: Emirates, Etihad, Qatar Airways, flydubai, Air Arabia and more.",
  faq6Q:"What is a GDS (Global Distribution System)?",
  faq6A:"A <strong>GDS</strong> is a computerized network enabling transactions between travel providers and agencies. Popular platforms: Amadeus, Sabre, Galileo (Travelport), Worldspan.",
  blogTitle:"Travel Agent Resources",blogSub:"Tips, guides and industry insights",
  blog1Tag:"Guide",blog1Title:"Understanding GDS PNR Codes",
  blog1Desc:"A complete breakdown of how airline reservation codes work in major Global Distribution Systems.",
  blog1Link:"Read More",
  blog2Tag:"Reference",blog2Title:"Travel Agent Glossary: A–Z",
  blog2Desc:"From HK1 to ARNK – the essential glossary every travel professional needs to know.",
  blog2Link:"Read More",
  blog3Tag:"Industry",blog3Title:"GDS Booking Codes Explained",
  blog3Desc:"Complete guide to Galileo, Amadeus and Sabre codes. Cabin classes, status codes and IATA.",
  blog3Link:"Read More",
  apiTitle:"Developer API",
  apiDesc:"Integrate PNR conversion directly into your travel platform. Get structured JSON output in milliseconds.",
  apiFeat1:"RESTful JSON API",apiFeat2:"Supports all major GDS formats",
  apiFeat3:"Returns structured flight data",apiFeat4:"Lightning-fast response times",
  apiDocsBtn:"View API Docs",
  footerTagline:"Built for the World of Travel",
  footerDesc:"The easiest way to convert GDS itinerary data into beautiful, client-ready flight summaries. Built for the world of travel.",
  footerTools:"Tools",footerContact:"Contact Us",footerFollow:"Follow Us",
  footerLink1:"What is PNR?",footerLink2:"GDS Codes Guide",footerLink3:"Travel Glossary",
  footerPnr:"PNR Converter",
  copyright:"© 2026 Itinovo. All rights reserved.",
  privacyLink:"Privacy Policy",termsLink:"Terms of Use",contactLink:"Contact",
  adLabel:"Advertisement",cookieMsg:"We use cookies to improve your experience.",cookieAccept:"Accept",
  // Features labels
  lbl_agentSettings:"Agent Settings",lbl_agentName:"Agent Name",lbl_agencyName:"Agency Name",
  lbl_agentPhone:"Phone",lbl_agentEmail:"Email",lbl_agencyLicense:"License #",lbl_agentLogoUrl:"Logo URL",
  lbl_defaultCurrency:"Default Currency",lbl_defaultLang:"Default Language",
  lbl_agentSignOffSetting:"Default Sign-off",lbl_whatsappTemplateSetting:"WhatsApp Template",
  lbl_b2bMode:"B2B Mode (hides ads)",btn_cancel:"Cancel",btn_saveSettings:"Save Settings",
  lbl_history:"Trip History",btn_clearHistory:"Clear All",btn_close:"Close",
  lbl_stats:"Usage Statistics",lbl_buildPackage:"Build Your Package",
  lbl_pkgCurrency:"Currency",btn_addItem:"Add Item",lbl_grandTotal:"Grand Total",
  btn_printPkg:"Print",btn_copyPkg:"Copy Table",
  lbl_commission:"Commission Tracker",lbl_ticketPrice:"Ticket Price",lbl_commRate:"Commission %",
  lbl_serviceCharge:"Service Charge",lbl_commCurrency:"Currency",btn_calcComm:"Calculate",
  lbl_pnrExpiry:"PNR Expiry Alert",lbl_pnrRef:"PNR Reference",lbl_expiryDate:"Expiry Date",btn_checkExpiry:"Check Expiry",
  lbl_tzDiff:"Time Zone Difference",lbl_city1:"City 1",lbl_city2:"City 2",btn_calcTz:"Calculate",
  lbl_waTemplate:"WhatsApp Message",lbl_waHint:"A ready-to-send message is generated in a fixed format — airline, route, times, baggage & a blank price line you can edit before sending.",btn_generateWa:"Generate Message",
  btn_sendWa:"Send via WhatsApp",btn_copyWa:"Copy",
  lbl_currency:"Currency Converter",lbl_xeAmount:"Amount",lbl_xeFrom:"From",lbl_xeTo:"To",
  lbl_templates:"Visual Templates",lbl_tmplHint:"Choose a color theme.",
  lbl_multiPnr:"Multi-Trip Tabs",lbl_multiHint:"Manage multiple trips.",btn_newTab:"New Trip",
  lbl_agentNotes:"Agent Notes (shown in output)",
  lbl_letterhead:"Letterhead",lbl_present:"Present",lbl_waBtn:"WhatsApp",
  chip_package:"Package",chip_commission:"Commission",chip_expiry:"PNR Expiry",
  chip_timezone:"Time Zone",chip_currency:"Currency",chip_visa:"Visa Check",
  tip_settings:"Settings",tip_history:"History",tip_stats:"Statistics",
  tip_templates:"Templates",tip_multitab:"Multi-Trip",tip_visaCheck:"Visa Check",
  lbl_visaCheck:"Visa Requirements Check",
  lbl_scanUpload:"Scan a booking photo instead",tip_aiChat:"AI Assistant",lbl_aiChatTitle:"Itinovo Assistant",
  lbl_qaTitle:"AI-Powered Visa & Entry Requirements",lbl_qaSub:"Answered right here — always free, no redirects",
  lbl_visaHint:"Fill in the nationality and destination below and get an instant answer — no need to leave this page.",
  lbl_scanFreeAlways:"or use the always-free basic scan"
},
ar: {
  navHome:"الرئيسية",navHow:"كيف يعمل",navFaq:"الأسئلة الشائعة",navBlog:"المدونة",navAbout:"من نحن",navContact:"تواصل معنا",
  heroTitle:"محوّل جدول رحلات <span>PNR</span>",
  heroSub:"حوّل رموز GDS الخام إلى جداول رحلات احترافية جاهزة للعملاء في ثوانٍ",
  cardTitle:"الصق بيانات الرحلة / PNR",
  cardHint:"يدعم Galileo وSmartpoint وAmadeus وSabre وWorldspan — الكويتية والإماراتية والاتحاد وغيرها",
  pnrPlaceholder:`الصق نص GDS هنا… مثال:\n\n--- Galileo ---\nNZ 456 H 26OCT 5 WLGAKL HK1 1945 2050\n\n--- الخطوط الكويتية ---\n1  KU 417 V 20SEP KWI MNL 0215 1655\n\n--- Amadeus/Sabre ---\n1. EY 658 L 20SEP KWIAUH HS1 2225 0105\n\nCtrl+Enter للتحويل السريع`,
  fbColType:"المسافر",fbColFare:"الأجرة",fbColFee:"الرسوم",
  fbAdult:"بالغ",fbChild:"طفل",fbInfant:"رضيع",fbCurrency:"العملة",
  convertBtn:"تحويل الرحلة",
  extractBtn:"استخراج وتحويل",clearBtn:"مسح",
  optTitle:"خيارات العرض",
  optAirlineName:"إظهار اسم شركة الطيران",optFlightNum:"إظهار رقم الرحلة",optLogo:"إظهار شعار الطيران",
  optDuration:"إظهار مدة الرحلة",optDistance:"إظهار المسافة",optTransit:"وقت الترانزيت",
  optCabin:"إظهار درجة السفر",optOpBy:"الشركة المشغّلة",opt12hr:"توقيت 12 ساعة",optBaggage:"إظهار الأمتعة",
  baggageSameAll:"نفس الوزن لجميع الرحلات",baggageDifferent:"أوزان مختلفة لكل رحلة",
  baggageSinglePlaceholder:"مثال: 30 كيلو  /  قطعتان",baggageSingleNote:"يُطبق على جميع الرحلات",
  baggageMultiNote:"الصيغة: رقم الرحلة = الوزن (سطر لكل رحلة)",
  baggageMultiPlaceholder:"1 = 30 كيلو\n2 = 23 كيلو",
  distUnit:"وحدة المسافة",distKM:"كيلومتر",distMiles:"ميل",
  resultsFormat:"صيغة العرض",fmtTable:"جدول",fmtCards:"بطاقات",fmtEmail:"بريد إلكتروني",
  passengerLabel:"اسم المسافر",passengerPlaceholder:"مثال: أحمد الرشيدي",
  agentLabel:"توقيع الوكيل",agentPlaceholder:"مع تحياتي،\nأحمد\nوكالة السفر الخاصة بك",
  convertedTitle:"الرحلة المحوّلة",
  copyHtml:"نسخ HTML",copyText:"نسخ النص",copyEmail:"نسخ البريد",printBtn:"طباعة",
  howTitle:"محوّل مجاني لجداول الرحلات<br>الأسهل والأوضح على الإطلاق",
  howSub:"حوّل رموز حجز GDS الخام فوراً إلى جداول رحلات جميلة وقابلة للإرسال",
  howStep1Title:"الصق بيانات PNR",howStep1Desc:"انسخ نص الرحلة الخام من نظام GDS والصقه في المحوّل.",
  howStep2Title:"اختر الخيارات",howStep2Desc:"حدد صيغة العرض والعملة وتفاصيل الأجرة والحقول المطلوبة.",
  howStep3Title:"حوّل الرحلة",howStep3Desc:"اضغط تحويل واحصل فوراً على جدول رحلة احترافي جاهز للعميل.",
  howStep4Title:"شارك",howStep4Desc:"انسخ HTML أو النص العادي والصقه في بريدك الإلكتروني أو نظام الحجز.",
  aboutTitle:"لماذا تختار Itinovo",aboutSub:"حلول سفر احترافية مصممة لوكلاء السفر والمسافرين",
  about1T:"تغطية عالمية",about1D:"أكثر من 300 مطار و100 شركة طيران حول العالم، مع تغطية كاملة للشرق الأوسط.",
  about2T:"تحويل فوري",about2D:"لا حاجة للتسجيل. الصق بيانات PNR واحصل على جدول رحلة جميل في ثوانٍ.",
  about3T:"خاص وآمن",about3D:"تتم جميع العمليات في متصفحك. لا نحتفظ ببيانات رحلاتك أبداً.",
  about4T:"مجاني 100%",about4D:"تحويلات غير محدودة بلا رسوم خفية أو اشتراكات.",
  faqTitle:"الأسئلة الشائعة",faqSub:"كل ما تحتاج معرفته عن تحويل PNR",
  faq1Q:"ما هو محوّل PNR؟",
  faq1A:"<strong>محوّل PNR</strong> هو أداة تحوّل رموز حجز GDS الخام من أنظمة مثل Galileo وAmadeus وSabre وWorldspan إلى جداول رحلات واضحة وقابلة للقراءة. يستخدمها وكلاء السفر لمشاركة الرحلات بشكل احترافي مع العملاء.",
  faq2Q:"كيف أحوّل PNR إلى جدول رحلة قابل للقراءة؟",
  faq2A:"الصق نص رحلتك الخام في الحقل المخصص، اختر خيارات العرض المناسبة، ثم اضغط <strong>تحويل</strong>. ستحصل فوراً على جدول رحلة احترافي جاهز للإرسال.",
  faq3Q:"ما أنظمة GDS المدعومة؟",
  faq3A:"ندعم جميع أنظمة GDS الكبرى: <strong>Galileo وAmadeus وSabre وWorldspan</strong> وSmartpoint، إضافةً إلى الصيغ المباشرة مثل الكويتية (KU) والإماراتية (EK) والاتحاد (EY) وغيرها.",
  faq4Q:"هل محوّل PNR مجاني؟",
  faq4A:"نعم! <strong>مجاني 100%</strong> دون الحاجة للتسجيل. تحويلات غير محدودة. تتم المعالجة في متصفحك فبياناتك تظل خاصة.",
  faq5Q:"هل يعمل مع تذاكر الخطوط الكويتية؟",
  faq5A:"بالتأكيد! يدعم بالكامل <strong>الخطوط الجوية الكويتية (KU)</strong> وجميع شركات الخليج: الإماراتية والاتحاد والقطرية وفلاي دبي والعربية للطيران.",
  faq6Q:"ما هو نظام GDS؟",
  faq6A:"<strong>GDS</strong> (نظام التوزيع العالمي) هو شبكة حاسوبية تتيح المعاملات بين مزودي خدمات السفر ووكالات السفر. أشهر الأنظمة: Amadeus وSabre وGalileo (Travelport) وWorldspan.",
  blogTitle:"مصادر وكلاء السفر",blogSub:"نصائح وأدلة ورؤى من صناعة السفر",
  blog1Tag:"دليل",blog1Title:"فهم رموز GDS PNR",
  blog1Desc:"شرح تفصيلي لكيفية عمل رموز حجوزات الطيران في أنظمة التوزيع العالمية الكبرى.",
  blog1Link:"اقرأ المزيد",
  blog2Tag:"مرجع",blog2Title:"قاموس وكيل السفر من أ إلى ي",
  blog2Desc:"من HK1 إلى ARNK – القاموس الأساسي الذي يحتاجه كل محترف في مجال السفر.",
  blog2Link:"اقرأ المزيد",
  blog3Tag:"صناعة",blog3Title:"شرح رموز حجز GDS",
  blog3Desc:"دليل شامل لرموز Galileo وAmadeus وSabre. تعرّف على درجات الكابينة وأكواد الحالة.",
  blog3Link:"اقرأ المزيد",
  apiTitle:"واجهة برمجية للمطورين",
  apiDesc:"ادمج تحويل PNR مباشرةً في منصة سفرك. احصل على مخرجات JSON منظمة في أجزاء من الثانية.",
  apiFeat1:"واجهة RESTful JSON",apiFeat2:"تدعم جميع صيغ GDS الكبرى",
  apiFeat3:"تُعيد بيانات الرحلة منظمة",apiFeat4:"سرعة استجابة فائقة",
  apiDocsBtn:"عرض توثيق API",
  footerTagline:"صُنع لعالم السفر",
  footerDesc:"أسهل طريقة لتحويل بيانات GDS إلى جداول رحلات احترافية جاهزة للعملاء. صُنع لعالم السفر.",
  footerTools:"الأدوات",footerContact:"تواصل معنا",footerFollow:"تابعنا",
  footerLink1:"ما هو PNR؟",footerLink2:"دليل رموز GDS",footerLink3:"قاموس السفر",
  footerPnr:"محوّل PNR",
  copyright:"© 2026 Itinovo. جميع الحقوق محفوظة.",
  privacyLink:"سياسة الخصوصية",termsLink:"شروط الاستخدام",contactLink:"تواصل معنا",
  adLabel:"إعلان",cookieMsg:"نستخدم ملفات تعريف الارتباط لتحسين تجربتك.",cookieAccept:"موافق",
  // Features labels AR
  lbl_agentSettings:"إعدادات الوكيل",lbl_agentName:"اسم الوكيل",lbl_agencyName:"اسم الوكالة",
  lbl_agentPhone:"الهاتف",lbl_agentEmail:"البريد الإلكتروني",lbl_agencyLicense:"رقم الترخيص",lbl_agentLogoUrl:"رابط الشعار",
  lbl_defaultCurrency:"العملة الافتراضية",lbl_defaultLang:"اللغة الافتراضية",
  lbl_agentSignOffSetting:"التوقيع الافتراضي",lbl_whatsappTemplateSetting:"قالب واتساب",
  lbl_b2bMode:"وضع B2B (يخفي الإعلانات)",btn_cancel:"إلغاء",btn_saveSettings:"حفظ الإعدادات",
  lbl_history:"سجل الرحلات",btn_clearHistory:"حذف الكل",btn_close:"إغلاق",
  lbl_stats:"إحصاء الاستخدام",lbl_buildPackage:"بناء الباقة",
  lbl_pkgCurrency:"العملة",btn_addItem:"إضافة بند",lbl_grandTotal:"المجموع الكلي",
  btn_printPkg:"طباعة",btn_copyPkg:"نسخ الجدول",
  lbl_commission:"تتبع العمولة",lbl_ticketPrice:"سعر التذكرة",lbl_commRate:"نسبة العمولة %",
  lbl_serviceCharge:"رسوم الخدمة",lbl_commCurrency:"العملة",btn_calcComm:"احسب",
  lbl_pnrExpiry:"تنبيه انتهاء PNR",lbl_pnrRef:"مرجع PNR",lbl_expiryDate:"تاريخ الانتهاء",btn_checkExpiry:"فحص الصلاحية",
  lbl_tzDiff:"فارق التوقيت",lbl_city1:"المدينة الأولى",lbl_city2:"المدينة الثانية",btn_calcTz:"احسب الفارق",
  lbl_waTemplate:"رسالة واتساب",lbl_waHint:"تُنشأ رسالة جاهزة بصيغة ثابتة — شركة الطيران، المسار، الأوقات، الوزن، وخانة سعر فاضية تقدر تعدّلها قبل الإرسال.",btn_generateWa:"توليد الرسالة",
  btn_sendWa:"إرسال عبر واتساب",btn_copyWa:"نسخ",
  lbl_currency:"محوّل العملات",lbl_xeAmount:"المبلغ",lbl_xeFrom:"من",lbl_xeTo:"إلى",
  lbl_templates:"القوالب البصرية",lbl_tmplHint:"اختر لون واجهة الموقع.",
  lbl_multiPnr:"تبويبات متعددة",lbl_multiHint:"إدارة رحلات متعددة في تبويبات.",btn_newTab:"رحلة جديدة",
  lbl_agentNotes:"ملاحظات الوكيل (تظهر في الناتج)",
  lbl_letterhead:"ورقة رسمية",lbl_present:"عرض تقديمي",lbl_waBtn:"واتساب",
  chip_package:"باقة",chip_commission:"عمولة",chip_expiry:"انتهاء PNR",
  chip_timezone:"فارق التوقيت",chip_currency:"عملة",
  tip_settings:"الإعدادات",tip_history:"السجل",tip_stats:"الإحصاء",
  tip_templates:"القوالب",tip_multitab:"تبويبات",
  chip_visa:"فحص التأشيرة",tip_visaCheck:"فحص التأشيرة",
  lbl_visaCheck:"فحص متطلبات التأشيرة",
  lbl_scanUpload:"امسح صورة الحجز بدلاً من ذلك",tip_aiChat:"مساعد ذكي",lbl_aiChatTitle:"مساعد Itinovo",
  lbl_qaTitle:"متطلبات الفيزا والدخول بالذكاء الاصطناعي",lbl_qaSub:"الإجابة تظهر هنا مباشرة — مجاناً دائماً بدون تحويل",
  lbl_visaHint:"عبّي الجنسية والوجهة تحت واحصل على إجابة فورية — بدون ما تطلع من هالصفحة.",
  lbl_scanFreeAlways:"أو استخدم المسح الأساسي المجاني دائماً"
}}

let currentLang = localStorage.getItem("mg_lang") || "en";

function setLang(lang) {
  currentLang = lang;
  localStorage.setItem("mg_lang", lang);
  const t = I18N[lang], isAr = lang==="ar";

  document.documentElement.lang = lang;
  document.documentElement.dir  = isAr ? "rtl" : "ltr";
  document.body.dir              = isAr ? "rtl" : "ltr";
  document.body.classList.toggle("rtl", isAr);

  // Toggle active button
  document.getElementById("langEN")?.classList.toggle("active",!isAr);
  document.getElementById("langAR")?.classList.toggle("active",isAr);

  // Nav links
  sT("navHome",t.navHome); sT("navHow",t.navHow); sT("navFaq",t.navFaq);
  sT("navBlog",t.navBlog); sT("navAbout",t.navAbout); sT("navContact",t.navContact);

  // Mobile nav
  const mLinks=document.querySelectorAll(".mobile-nav a");
  const navKeys=["navHome","navHow","navFaq","navBlog","navAbout","navContact"];
  mLinks.forEach((a,i)=>{ if(navKeys[i]) a.textContent=t[navKeys[i]]; });

  // Footer tagline
  sT("footerTaglineEl", t.footerTagline);
  sT("footerBrandTaglineEl", t.footerTagline);

  // Hero
  sH("heroTitle",t.heroTitle); sT("heroSub",t.heroSub);

  // Converter card
  sH("cardTitle_icon",`<i class="fas fa-exchange-alt"></i> ${t.cardTitle}`);
  sT("cardHintEl",t.cardHint);
  sA("pnrInput","placeholder",t.pnrPlaceholder);

  // Fare section headers
  sT("fbColType",t.fbColType); sT("fbColFare",t.fbColFare); sT("fbColFee",t.fbColFee);
  sH("fbAdultLbl",`<i class="fas fa-user"></i> ${t.fbAdult}`);
  sH("fbChildLbl",`<i class="fas fa-child"></i> ${t.fbChild}`);
  sH("fbInfantLbl",`<i class="fas fa-baby"></i> ${t.fbInfant}`);
  sH("fbCurrencyLbl",`<i class="fas fa-coins"></i> ${t.fbCurrency}`);

  // Buttons
  sH("convertBtn",`<i class="fas fa-paper-plane"></i> ${t.convertBtn}`);

  // Display options
  sH("optTitleEl",`<i class="fas fa-sliders-h"></i> ${t.optTitle}`);
  sT("optAirlineNameLbl",t.optAirlineName); sT("optFlightNumLbl",t.optFlightNum);
  sT("optLogoLbl",t.optLogo); sT("optDurationLbl",t.optDuration);
  sT("optDistanceLbl",t.optDistance); sT("optTransitLbl",t.optTransit);
  sT("optCabinLbl",t.optCabin); sT("optOpByLbl",t.optOpBy);
  sT("opt12hrLbl",t.opt12hr); sT("optBaggageLbl",t.optBaggage);
  sT("baggageSameAllLbl",t.baggageSameAll); sT("baggageDiffLbl",t.baggageDifferent);
  sA("baggageValue","placeholder",t.baggageSinglePlaceholder);
  sT("baggageSingleNote_el",t.baggageSingleNote);
  sH("baggageMultiNote_el",`<i class="fas fa-info-circle"></i> ${t.baggageMultiNote}`);
  sA("baggageMultiValue","placeholder",t.baggageMultiPlaceholder);
  sT("distUnitLbl",t.distUnit); sT("distKMLbl",t.distKM); sT("distMilesLbl",t.distMiles);
  sT("resultsFormatLbl",t.resultsFormat); sT("fmtTableLbl",t.fmtTable);
  sT("fmtCardsLbl",t.fmtCards); sT("fmtEmailLbl",t.fmtEmail);
  sT("passengerLabelEl",t.passengerLabel); sA("passengerName","placeholder",t.passengerPlaceholder);
  sT("agentLabelEl",t.agentLabel); sA("agentSignOff","placeholder",t.agentPlaceholder);

  // Output section
  sH("outputTitleEl",`<i class="fas fa-check-circle"></i> ${t.convertedTitle}`);
  sH("copyHtmlBtn",`<i class="fas fa-code"></i> ${t.copyHtml}`);
  sH("copyTextBtn",`<i class="fas fa-copy"></i> ${t.copyText}`);
  sH("copyEmailBtn",`<i class="fas fa-envelope"></i> ${t.copyEmail}`);
  sT("printBtnEl",t.printBtn);

  // How It Works
  sH("howTitleEl",t.howTitle); sT("howSubEl",t.howSub);
  sT("step1TitleEl",t.howStep1Title); sT("step1DescEl",t.howStep1Desc);
  sT("step2TitleEl",t.howStep2Title); sT("step2DescEl",t.howStep2Desc);
  sT("step3TitleEl",t.howStep3Title); sT("step3DescEl",t.howStep3Desc);
  sT("step4TitleEl",t.howStep4Title); sT("step4DescEl",t.howStep4Desc);

  // About
  sT("aboutTitleEl",t.aboutTitle); sT("aboutSubEl",t.aboutSub);
  sT("about1TitleEl",t.about1T); sT("about1DescEl",t.about1D);
  sT("about2TitleEl",t.about2T); sT("about2DescEl",t.about2D);
  sT("about3TitleEl",t.about3T); sT("about3DescEl",t.about3D);
  sT("about4TitleEl",t.about4T); sT("about4DescEl",t.about4D);

  // FAQ
  sT("faqTitleEl",t.faqTitle); sT("faqSubEl",t.faqSub);
  sT("faq1Q",t.faq1Q); sH("faq1A",`<p>${t.faq1A}</p>`);
  sT("faq2Q",t.faq2Q); sH("faq2A",`<p>${t.faq2A}</p>`);
  sT("faq3Q",t.faq3Q); sH("faq3A",`<p>${t.faq3A}</p>`);
  sT("faq4Q",t.faq4Q); sH("faq4A",`<p>${t.faq4A}</p>`);
  sT("faq5Q",t.faq5Q); sH("faq5A",`<p>${t.faq5A}</p>`);
  sT("faq6Q",t.faq6Q); sH("faq6A",`<p>${t.faq6A}</p>`);

  // Blog
  sT("blogTitleEl",t.blogTitle); sT("blogSubEl",t.blogSub);
  sT("blog1Tag",t.blog1Tag); sT("blog1Title",t.blog1Title); sT("blog1Desc",t.blog1Desc);
  sH("blog1Link",`${t.blog1Link} <i class="fas fa-arrow-${isAr?"left":"right"}"></i>`);
  sT("blog2Tag",t.blog2Tag); sT("blog2Title",t.blog2Title); sT("blog2Desc",t.blog2Desc);
  sH("blog2Link",`${t.blog2Link} <i class="fas fa-arrow-${isAr?"left":"right"}"></i>`);
  sT("blog3Tag",t.blog3Tag); sT("blog3Title",t.blog3Title); sT("blog3Desc",t.blog3Desc);
  sH("blog3Link",`${t.blog3Link} <i class="fas fa-arrow-${isAr?"left":"right"}"></i>`);

  // API section
  sH("apiTitleEl",`<i class="fas fa-code"></i> ${t.apiTitle}`);
  sT("apiDescEl",t.apiDesc);
  sT("apiFeat1",t.apiFeat1); sT("apiFeat2",t.apiFeat2);
  sT("apiFeat3",t.apiFeat3); sT("apiFeat4",t.apiFeat4);
  sH("apiDocsBtn",`${t.apiDocsBtn} <i class="fas fa-arrow-${isAr?"left":"right"}"></i>`);

  // Footer
  sT("footerDescEl",t.footerDesc);
  sT("footerToolsTitle",t.footerTools); sT("footerContactTitle",t.footerContact);
  sT("footerFollowTitle",t.footerFollow);
  sT("footerLink1",t.footerLink1); sT("footerLink2",t.footerLink2); sT("footerLink3",t.footerLink3);
  sT("footerPnrLink",t.footerPnr);
  sT("footerCopyright",t.copyright);
  sT("footerPrivacyLink",t.privacyLink);
  sT("footerTermsLink",t.termsLink);
  sT("footerContactLink",t.contactLink);

  // Ad labels
  // Ad labels removed (no ads on this site)

  // Cookie bar
  const cookieMsg=document.querySelector(".cookie-bar p");
  if (cookieMsg) cookieMsg.innerHTML=`${t.cookieMsg} <a href="#">${isAr?"اعرف المزيد":"Learn more"}</a>`;
  const cookieBtn=document.querySelector(".cookie-accept");
  if (cookieBtn) cookieBtn.textContent=t.cookieAccept;

  // GDS badges (keep as-is, brand names)
  // Footer brand tagline (separate from logo tagline)
  const fbTagline=document.querySelector(".footer-brand-tagline");
  if (fbTagline) fbTagline.textContent=t.footerTagline;

  // Re-render output if visible
  const outSec = document.getElementById("outputSection");
  if (outSec && outSec.style.display !== "none") {
    doConvert();
  }

  // ── Features labels ──
  const featureIds = [
    "lbl_agentSettings","lbl_agentName","lbl_agencyName","lbl_agentPhone","lbl_agentEmail",
    "lbl_agencyLicense","lbl_agentLogoUrl","lbl_defaultCurrency","lbl_defaultLang",
    "lbl_agentSignOffSetting","lbl_whatsappTemplateSetting","lbl_b2bMode",
    "btn_cancel","btn_saveSettings","lbl_history","btn_clearHistory","btn_close",
    "lbl_stats","lbl_buildPackage","lbl_pkgCurrency","btn_addItem","lbl_grandTotal",
    "btn_printPkg","btn_copyPkg","lbl_commission","lbl_ticketPrice","lbl_commRate",
    "lbl_serviceCharge","lbl_commCurrency","btn_calcComm","lbl_pnrExpiry","lbl_pnrRef",
    "lbl_expiryDate","btn_checkExpiry","lbl_tzDiff","lbl_city1","lbl_city2","btn_calcTz",
    "lbl_waTemplate","lbl_waHint","btn_generateWa","btn_sendWa","btn_copyWa",
    "lbl_currency","lbl_xeAmount","lbl_xeFrom","lbl_xeTo",
    "lbl_templates","lbl_tmplHint","lbl_multiPnr","lbl_multiHint","btn_newTab",
    "lbl_agentNotes","lbl_letterhead","lbl_present","lbl_waBtn",
    "chip_package","chip_commission","chip_expiry","chip_timezone","chip_currency",
    "chip_visa","tip_settings","tip_history","tip_stats","tip_templates","tip_multitab",
    "tip_visaCheck","lbl_visaCheck","lbl_scanUpload","tip_aiChat","lbl_aiChatTitle",
    "lbl_qaTitle","lbl_qaSub","lbl_visaHint","lbl_scanFreeAlways"
  ];
  featureIds.forEach(id => {
    if (t[id]) sT(id, t[id]);
  });

  // Update toolbar tooltip direction
  const toolbar = document.getElementById("featuresToolbar");
  if (toolbar) toolbar.classList.toggle("rtl-pos", isAr);
}

function sT(id,v){const e=document.getElementById(id);if(e)e.textContent=v;}
function sH(id,v){const e=document.getElementById(id);if(e)e.innerHTML=v;}
function sA(id,a,v){const e=document.getElementById(id);if(e)e.setAttribute(a,v);}

// ── Events ────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded",()=>{
  document.getElementById("convertBtn")?.addEventListener("click",doConvert);
  document.getElementById("copyHtmlBtn")?.addEventListener("click",copyHTML);
  document.getElementById("copyTextBtn")?.addEventListener("click",copyText);
  document.getElementById("copyEmailBtn")?.addEventListener("click",copyEmail);
  document.getElementById("hamburger")?.addEventListener("click",toggleMobileNav);

  document.getElementById("opt_baggage")?.addEventListener("change",function(){
    const g=document.getElementById("baggageInputGroup");
    if(g) g.style.display=this.checked?"block":"none";
  });

  document.getElementById("pnrInput")?.addEventListener("keydown",e=>{
    if(e.ctrlKey&&e.key==="Enter") doConvert();
  });

  // Apply saved or default language
  const savedLang = localStorage.getItem("mg_lang") || "en";
  setLang(savedLang);
});
