/* ============================================================
   Itinovo – AI features (chat assistant, photo scan, visa Q&A)
   All three talk to ONE serverless function: /.netlify/functions/ai,
   which runs on Google Gemini's FREE tier (no billing, no subscriptions).
   See netlify/functions/ai.js for the backend implementation and
   setup instructions (you need to add GEMINI_API_KEY once — it's free
   at https://aistudio.google.com/apikey).

   Because the free tier has a shared daily quota for the whole site,
   the photo-scan feature also has a 100% free, unlimited, in-browser
   fallback (Tesseract.js OCR) that kicks in automatically if the AI
   quota is used up — see runBrowserOcrFallback() below.
   ============================================================ */

const AI_ENDPOINT = "/.netlify/functions/ai";
let aiChatHistory = []; // {role:"user"|"assistant", content:"..."}

async function callAI(body) {
  const res = await fetch(AI_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  let data;
  try { data = await res.json(); } catch { data = {}; }
  if (!res.ok) {
    const err = new Error(data.message || data.error || `Request failed (${res.status})`);
    err.code = data.error; // "not_configured" | "quota_exceeded" | undefined
    throw err;
  }
  return data;
}

function aiErrorMessage(err, isAr) {
  if (err.code === "not_configured") {
    return isAr
      ? "⚠️ ميزة الذكاء الاصطناعي غير مفعّلة على هذا الرابط بعد. أضف مفتاح Gemini المجاني (GEMINI_API_KEY) بإعدادات Netlify — راجع تعليمات netlify/functions/ai.js."
      : "⚠️ AI features aren't switched on for this link yet. Add a free Gemini key (GEMINI_API_KEY) in Netlify — see the setup notes in netlify/functions/ai.js.";
  }
  if (err.code === "quota_exceeded") {
    return err.message; // backend already gives a friendly bilingual message
  }
  return err.message;
}

/* ── Free, unlimited, in-browser fallback (Tesseract.js OCR) ───
   Only loaded on demand (it's a couple MB) when the Gemini free quota
   runs out or the function isn't configured yet, so normal page loads
   stay fast. This never talks to any server — 100% free, no limits,
   but plain OCR is noticeably less accurate than the AI scan: it dumps
   raw text for the agent to tidy up rather than ready-made segments. */
let _tesseractLoading = null;
function loadTesseractScript() {
  if (window.Tesseract) return Promise.resolve();
  if (_tesseractLoading) return _tesseractLoading;
  _tesseractLoading = new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js";
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("Could not load the free OCR library (check your internet connection)."));
    document.head.appendChild(s);
  });
  return _tesseractLoading;
}

async function runBrowserOcrFallback(file, setStatus, isAr) {
  setStatus(isAr ? "🆓 نجرب القراءة المجانية غير المحدودة بالمتصفح…" : "🆓 Trying the free, unlimited in-browser scan…", false);
  try {
    await loadTesseractScript();
    const { data } = await window.Tesseract.recognize(file, "eng");
    const text = (data.text || "").trim();
    if (!text) {
      setStatus(isAr ? "ما قدرت أقرا أي نص من الصورة. جرب صورة أوضح." : "Couldn't read any text from that image. Try a clearer photo.", true);
      return;
    }
    const textarea = document.getElementById("pnrInput");
    const existing = textarea.value.trim();
    textarea.value = existing ? existing + "\n\n" + text : text;
    setStatus(isAr
      ? "✅ تمت قراءة نص الصورة (قراءة أساسية مجانية وغير محدودة — راجع وعدّل يدوياً قبل التحويل)."
      : "✅ Read the image text (free, unlimited basic scan — please review & tidy it up before converting).", false);
  } catch (err) {
    setStatus(isAr ? "تعذّرت القراءة المجانية أيضاً: " + err.message : "The free scan also failed: " + err.message, true);
  }
}

/* ── 1) Floating AI Chat Assistant ─────────────────────────── */
function toggleAIChat() {
  const panel = document.getElementById("aiChatPanel");
  if (!panel) return;
  const open = panel.classList.toggle("open");
  if (open && !aiChatHistory.length) {
    const isAr = currentLang === "ar";
    appendAIChatBubble("assistant", isAr
      ? "أهلاً! أنا مساعد Itinovo. اسألني عن أكواد GDS، شركات الطيران، فروقات التوقيت، أو أي شي يخص شغل الوكيل. 👋"
      : "Hi! I'm the Itinovo assistant. Ask me about GDS codes, airlines, time-zone math, or anything agent-workflow related. 👋");
  }
}

function appendAIChatBubble(role, text) {
  const log = document.getElementById("aiChatLog");
  if (!log) return;
  const div = document.createElement("div");
  div.className = `ai-bubble ai-bubble-${role}`;
  div.textContent = text;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
}

async function sendAIChat() {
  const input = document.getElementById("aiChatInput");
  const text = input.value.trim();
  if (!text) return;
  const isAr = currentLang === "ar";

  appendAIChatBubble("user", text);
  aiChatHistory.push({ role: "user", content: text });
  input.value = "";

  const typingId = "ai-typing-" + Date.now();
  const log = document.getElementById("aiChatLog");
  const typingEl = document.createElement("div");
  typingEl.className = "ai-bubble ai-bubble-assistant ai-typing";
  typingEl.id = typingId;
  typingEl.textContent = isAr ? "يكتب…" : "Typing…";
  log.appendChild(typingEl);
  log.scrollTop = log.scrollHeight;

  try {
    const data = await callAI({ mode: "chat", history: aiChatHistory, lang: currentLang });
    document.getElementById(typingId)?.remove();
    appendAIChatBubble("assistant", data.reply);
    aiChatHistory.push({ role: "assistant", content: data.reply });
  } catch (err) {
    document.getElementById(typingId)?.remove();
    const msg = aiErrorMessage(err, isAr);
    appendAIChatBubble("assistant", msg);
  }
}

function handleAIChatKey(e) {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendAIChat();
  }
}

/* ── 2) Scan a booking photo → auto-fill the PNR box ───────── */
const CABIN_WORD_TO_CODE = { "Economy": "Y", "Premium Economy": "W", "Business": "C", "First": "F" };

function triggerScanUpload() {
  document.getElementById("scanFileInput")?.click();
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function segmentToPnrLine(seg, idx) {
  // Reconstructs a plain-format line the existing parser already understands
  // (Pattern D: "AL FN C DDMMM FROMTO DEPTIME ARRTIME"), so scanned photos
  // flow through the exact same, already-tested conversion pipeline.
  const cabinCode = CABIN_WORD_TO_CODE[seg.cabin] || "Y";
  const dep = (seg.depDate || "").toUpperCase();
  const from = (seg.from || "").toUpperCase();
  const to = (seg.to || "").toUpperCase();
  const dt = (seg.depTime || "").padStart(4, "0");
  const at = (seg.arrTime || "").padStart(4, "0");
  if (!seg.airline || !seg.flightNum || !dep || !from || !to || !dt || !at) return null;
  return `${idx + 1}. ${seg.airline} ${seg.flightNum} ${cabinCode} ${dep} ${from}${to} ${dt} ${at}`;
}

function getScanStatusHelper() {
  const statusEl = document.getElementById("scanStatus");
  return (msg, isError) => {
    if (!statusEl) return;
    statusEl.textContent = msg;
    statusEl.style.color = isError ? "#dc2626" : "#0d9488";
    statusEl.style.display = msg ? "block" : "none";
  };
}

async function handleScanFile(fileInputEl) {
  const file = fileInputEl.files && fileInputEl.files[0];
  if (!file) return;
  const isAr = currentLang === "ar";
  const setStatus = getScanStatusHelper();

  if (!file.type.startsWith("image/")) {
    setStatus(isAr ? "الرجاء اختيار صورة (jpg, png, webp)." : "Please choose an image file (jpg, png, webp).", true);
    return;
  }

  setStatus(isAr ? "📷 جارٍ قراءة الصورة بالذكاء الاصطناعي…" : "📷 Reading the image with AI…", false);
  try {
    const base64 = await fileToBase64(file);
    const data = await callAI({ mode: "scan", image: base64, mediaType: file.type, lang: currentLang });

    if (!data.segments || !data.segments.length) {
      setStatus(isAr ? "ما قدرت ألقى تفاصيل رحلة واضحة بهذي الصورة. جرب صورة أوضح." : "Couldn't find clear flight details in that image. Try a clearer photo.", true);
      return;
    }

    const lines = data.segments.map(segmentToPnrLine).filter(Boolean);
    if (!lines.length) {
      setStatus(isAr ? "لقيت معلومات لكن ناقصة (تاريخ/وقت). عدّلها يدوياً بالمربع." : "Found some info but key fields were missing (date/time). Please fill gaps manually.", true);
      return;
    }

    const textarea = document.getElementById("pnrInput");
    const existing = textarea.value.trim();
    textarea.value = existing ? existing + "\n" + lines.join("\n") : lines.join("\n");
    setStatus(isAr ? `✅ تمت إضافة ${lines.length} رحلة من الصورة. راجعها ثم اضغط تحويل.` : `✅ Added ${lines.length} flight(s) from the photo. Review, then hit Convert.`, false);
  } catch (err) {
    setStatus(aiErrorMessage(err, isAr), true);
    if (err.code === "quota_exceeded" || err.code === "not_configured") {
      await runBrowserOcrFallback(file, setStatus, isAr);
    }
  } finally {
    fileInputEl.value = ""; // allow re-selecting the same file later
  }
}

// Explicit "always free" path — skips the AI call entirely, so it never
// touches the shared quota. Same underlying OCR used as the automatic
// fallback above.
async function handleScanFileFree(fileInputEl) {
  const file = fileInputEl.files && fileInputEl.files[0];
  if (!file) return;
  const isAr = currentLang === "ar";
  const setStatus = getScanStatusHelper();

  if (!file.type.startsWith("image/")) {
    setStatus(isAr ? "الرجاء اختيار صورة (jpg, png, webp)." : "Please choose an image file (jpg, png, webp).", true);
    fileInputEl.value = "";
    return;
  }

  await runBrowserOcrFallback(file, setStatus, isAr);
  fileInputEl.value = "";
}

/* ── 3) Visa Q&A, answered right here (no redirect) ────────── */
async function runAIVisaCheck() {
  const isAr = currentLang === "ar";
  const nationality = document.getElementById("aiVisaNationality")?.value.trim();
  const to = document.getElementById("aiVisaTo")?.value.trim();
  const from = document.getElementById("aiVisaFrom")?.value.trim();
  const transit = document.getElementById("aiVisaTransit")?.value.trim();
  const resultEl = document.getElementById("aiVisaResult");
  const btn = document.getElementById("aiVisaBtn");

  if (!nationality || !to) {
    resultEl.innerHTML = `<div class="ai-visa-error">${isAr ? "الرجاء تعبئة الجنسية والوجهة على الأقل." : "Please fill in at least nationality and destination."}</div>`;
    return;
  }

  btn.disabled = true;
  btn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${isAr ? "جارٍ البحث…" : "Checking…"}`;
  resultEl.innerHTML = `<div class="ai-visa-loading">${isAr ? "🔎 نبحث عن أحدث المتطلبات الرسمية…" : "🔎 Searching for the latest official requirements…"}</div>`;

  try {
    const data = await callAI({ mode: "visa", nationality, from, to, transit, lang: currentLang });
    resultEl.innerHTML = `<div class="ai-visa-answer">${(data.reply || "").replace(/\n/g, "<br>")}</div>`;
  } catch (err) {
    const msg = aiErrorMessage(err, isAr);
    resultEl.innerHTML = `<div class="ai-visa-error">${msg}</div>`;
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<i class="fas fa-search"></i> <span id="lbl_aiVisaBtn">${isAr ? "تحقق من المتطلبات" : "Check Requirements"}</span>`;
  }
}

// Pre-fill the visa form's "to" (and "from") from the last converted trip, if any
function prefillAIVisaFromTrip() {
  const segs = window._lastSegments;
  if (!segs || !segs.length) return;
  const toEl = document.getElementById("aiVisaTo");
  const fromEl = document.getElementById("aiVisaFrom");
  const isAr = currentLang === "ar";
  if (toEl && !toEl.value) {
    const toCC = IATA_COUNTRY[segs[segs.length - 1].to];
    toEl.value = (isAr ? CNTR_AR[toCC] : CNTR[toCC]) || segs[segs.length - 1].to;
  }
  if (fromEl && !fromEl.value) {
    const fromCC = IATA_COUNTRY[segs[0].from];
    fromEl.value = (isAr ? CNTR_AR[fromCC] : CNTR[fromCC]) || segs[0].from;
  }
}
