/* ============================================================
   Itinovo – Features Module v1.0
   Implements all agreed features 12-46
   ============================================================ */
"use strict";

/* ─── STORAGE HELPERS ──────────────────────────────────── */
const MG = {
  get: (k, def=null) => { try { const v=localStorage.getItem("mg_"+k); return v!==null?JSON.parse(v):def; } catch{ return def; } },
  set: (k, v)       => { try { localStorage.setItem("mg_"+k, JSON.stringify(v)); } catch{} },
  del: (k)           => { localStorage.removeItem("mg_"+k); }
};

/* ─── CURRENCY HELPERS ─────────────────────────────────── */
const CURRENCY_SYMBOLS = {
  USD:"$", EUR:"€", GBP:"£", AUD:"A$", NZD:"NZ$",
  KWD:"د.ك", SAR:"ر.س", AED:"د.إ", BHD:"BD",
  QAR:"ر.ق", OMR:"ر.ع", EGP:"ج.م", JOD:"د.أ",
  TRY:"₺", INR:"₹", PKR:"₨", MYR:"RM", SGD:"S$", CAD:"C$"
};
const CURRENCY_DP = { KWD:3, BHD:3, OMR:3 };
function getCurrSymbol(c){ return CURRENCY_SYMBOLS[c]||c; }
function getCurrDP(c){ return CURRENCY_DP[c]||2; }

/* ═══════════════════════════════════════════════════════
   TOAST NOTIFICATION
   ═══════════════════════════════════════════════════════ */
function showToast(msg, duration=3000, color="#0d9488") {
  let toast = document.getElementById("mgToast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "mgToast";
    document.body.appendChild(toast);
  }
  toast.style.cssText = `position:fixed;bottom:24px;${currentLang==="ar"?"left":"right"}:24px;z-index:99999;background:${color};color:#fff;padding:12px 20px;border-radius:10px;font-size:14px;font-weight:600;box-shadow:0 4px 16px rgba(0,0,0,.2);transition:all .3s;opacity:1;transform:translateY(0);max-width:320px;`;
  toast.innerHTML = msg;
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => { toast.style.opacity="0"; toast.style.transform="translateY(10px)"; }, duration);
}

/* ─── MODAL HELPERS ───────────────────────────────────── */
/* NOTE: openModal is defined later (after visa functions) to support visaModal */
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) { m.style.display = "none"; document.body.style.overflow = ""; }
}

/* ═══════════════════════════════════════════════════════
   20 – AGENT SETTINGS
   ═══════════════════════════════════════════════════════ */
function saveAgentSettings() {
  const settings = {
    agentName:    document.getElementById("agentNameSetting")?.value.trim()||"",
    agencyName:   document.getElementById("agencyNameSetting")?.value.trim()||"",
    agentPhone:   document.getElementById("agentPhoneSetting")?.value.trim()||"",
    agentEmail:   document.getElementById("agentEmailSetting")?.value.trim()||"",
    agentLogo:    document.getElementById("agentLogoUrl")?.value.trim()||"",
    agencyLicense:document.getElementById("agencyLicense")?.value.trim()||"",
    agentSignOff: document.getElementById("agentSignOffSetting")?.value.trim()||"",
    defaultCurrency: document.getElementById("defaultCurrencySetting")?.value||"KWD",
    defaultLang:  document.getElementById("defaultLangSetting")?.value||"en",
    b2bMode:      document.getElementById("b2bModeSetting")?.checked||false,
    whatsappTemplate: document.getElementById("whatsappTemplateSetting")?.value.trim()||"",
    passportNationality: document.getElementById("passportNationalitySetting")?.value||""
  };
  MG.set("agentSettings", settings);
  applyAgentSettings(settings);
  showToast(currentLang==="ar"?"✅ تم حفظ الإعدادات":"✅ Settings saved");
  closeModal("agentSettingsModal");
}

function loadAgentSettings() {
  const s = MG.get("agentSettings", {});
  const fill = (id, val) => { const el=document.getElementById(id); if(el&&val!==undefined&&val!=="") el.value=val; };
  fill("agentNameSetting",    s.agentName);
  fill("agencyNameSetting",   s.agencyName);
  fill("agentPhoneSetting",   s.agentPhone);
  fill("agentEmailSetting",   s.agentEmail);
  fill("agentLogoUrl",        s.agentLogo);
  fill("agencyLicense",       s.agencyLicense);
  fill("agentSignOffSetting", s.agentSignOff);
  fill("defaultCurrencySetting", s.defaultCurrency);
  fill("defaultLangSetting",  s.defaultLang);
  const b2bEl = document.getElementById("b2bModeSetting");
  if (b2bEl) b2bEl.checked = s.b2bMode||false;
  fill("whatsappTemplateSetting", s.whatsappTemplate);
  fill("passportNationalitySetting", s.passportNationality);
  applyAgentSettings(s);
}

function applyAgentSettings(s) {
  if (!s) return;
  if (s.agentSignOff) {
    const el = document.getElementById("agentSignOff");
    if (el && !el.value) el.value = s.agentSignOff;
  }
  if (s.defaultCurrency) {
    const el = document.getElementById("currency");
    if (el) el.value = s.defaultCurrency;
  }
  if (s.b2bMode) document.body.classList.add("b2b-mode");
  else document.body.classList.remove("b2b-mode");
}

/* ═══════════════════════════════════════════════════════
   21 – HISTORY
   ═══════════════════════════════════════════════════════ */
function saveToHistory(pnrText, outputHTML) {
  if (!pnrText) return;
  let history = MG.get("history", []);
  const entry = {
    id: Date.now(),
    timestamp: new Date().toISOString(),
    pnrText: pnrText.trim(),
    outputHTML: outputHTML||"",
    label: extractHistoryLabel(pnrText)
  };
  history = history.filter(h => h.pnrText !== entry.pnrText);
  history.unshift(entry);
  if (history.length > 10) history = history.slice(0, 10);
  MG.set("history", history);
  updateHistoryBadge();
}

function extractHistoryLabel(pnr) {
  const lines = pnr.split("\n");
  for (const line of lines) {
    const m = line.match(/\b([A-Z]{3})\b.*\b([A-Z]{3})\b/);
    if (m) return `${m[1]} → ${m[2]}`;
  }
  return pnr.slice(0,40).trim();
}

function updateHistoryBadge() {
  const history = MG.get("history", []);
  const badge = document.getElementById("historyBadge");
  if (badge) { badge.textContent = history.length||""; badge.style.display = history.length?"flex":"none"; }
}

function renderHistoryList() {
  const history = MG.get("history", []);
  const container = document.getElementById("historyList");
  if (!container) return;
  const isAr = currentLang === "ar";
  if (!history.length) {
    container.innerHTML = `<p style="text-align:center;color:#94a3b8;padding:30px;">${isAr?"لا توجد رحلات محفوظة بعد":"No saved trips yet"}</p>`;
    return;
  }
  container.innerHTML = history.map(h => `
    <div class="history-item">
      <div class="history-item-info">
        <div class="history-label"><i class="fas fa-plane" style="color:#0d9488;margin-${isAr?"left":"right"}:6px;"></i>${h.label}</div>
        <div class="history-time">${new Date(h.timestamp).toLocaleString(isAr?"ar-KW":"en-GB")}</div>
      </div>
      <div class="history-actions">
        <button class="h-btn h-load" onclick="loadFromHistory(${h.id})" title="${isAr?"تحميل":"Load"}"><i class="fas fa-upload"></i></button>
        <button class="h-btn h-view" onclick="viewHistoryOutput(${h.id})" title="${isAr?"عرض":"View"}"><i class="fas fa-eye"></i></button>
        <button class="h-btn h-del"  onclick="deleteHistory(${h.id})"   title="${isAr?"حذف":"Delete"}"><i class="fas fa-trash"></i></button>
      </div>
    </div>`).join("");
}

function loadFromHistory(id) {
  const entry = MG.get("history",[]).find(h=>h.id===id);
  if (!entry) return;
  const el = document.getElementById("pnrInput");
  if (el) { el.value = entry.pnrText; closeModal("historyModal"); el.scrollIntoView({behavior:"smooth"}); showToast(currentLang==="ar"?"✈ تم تحميل الرحلة":"✈ Trip loaded"); }
}

function viewHistoryOutput(id) {
  const entry = MG.get("history",[]).find(h=>h.id===id);
  if (!entry||!entry.outputHTML) return;
  document.getElementById("outputContent").innerHTML = entry.outputHTML;
  document.getElementById("outputSection").style.display = "block";
  closeModal("historyModal");
  document.getElementById("outputSection").scrollIntoView({behavior:"smooth"});
}

function deleteHistory(id) {
  let h = MG.get("history",[]).filter(x=>x.id!==id);
  MG.set("history", h);
  renderHistoryList();
  updateHistoryBadge();
}

function clearAllHistory() {
  if (confirm(currentLang==="ar"?"هل تريد حذف كل السجل؟":"Clear all history?")) {
    MG.del("history"); renderHistoryList(); updateHistoryBadge();
  }
}

/* ═══════════════════════════════════════════════════════
   16 – USAGE STATISTICS
   ═══════════════════════════════════════════════════════ */
function recordConversion(segments) {
  const stats = MG.get("stats", {total:0,today:0,lastDate:"",airlines:{}});
  const today = new Date().toDateString();
  if (stats.lastDate !== today) { stats.today=0; stats.lastDate=today; }
  stats.total++; stats.today++;
  if (segments) segments.forEach(s=>{ if(s.airline) stats.airlines[s.airline]=(stats.airlines[s.airline]||0)+1; });
  MG.set("stats", stats);

  const wk = MG.get("statsWeek",{key:"",count:0});
  const wkKey = getWeekKey();
  MG.set("statsWeek", {key:wkKey, count:(wk.key===wkKey?wk.count:0)+1});
}

function getWeekKey() {
  const now=new Date(), jan1=new Date(now.getFullYear(),0,1);
  return `${now.getFullYear()}-W${Math.ceil(((now-jan1)/86400000+jan1.getDay()+1)/7)}`;
}

function renderStatsPopup() {
  const stats = MG.get("stats",{total:0,today:0,airlines:{}});
  const wk    = MG.get("statsWeek",{key:"",count:0});
  const week  = wk.key===getWeekKey()?wk.count:0;
  const isAr  = currentLang==="ar";
  const el    = document.getElementById("statsContent");
  if (!el) return;

  const topAirlines = Object.entries(stats.airlines||{}).sort((a,b)=>b[1]-a[1]).slice(0,5);
  el.innerHTML = `
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-num">${stats.total||0}</div><div class="stat-lbl">${isAr?"إجمالي":"Total"}</div></div>
      <div class="stat-card"><div class="stat-num">${stats.today||0}</div><div class="stat-lbl">${isAr?"اليوم":"Today"}</div></div>
      <div class="stat-card"><div class="stat-num">${week}</div><div class="stat-lbl">${isAr?"الأسبوع":"Week"}</div></div>
    </div>
    ${topAirlines.length?`
    <div class="stats-airlines">
      <h4 style="margin:12px 0 8px;font-size:13px;color:#64748b;">${isAr?"أكثر الطيران استخداماً":"Most Used Airlines"}</h4>
      ${topAirlines.map(([code,count])=>`
        <div class="stat-airline-row">
          <span class="stat-airline-code">${code}</span>
          <div class="stat-bar-wrap"><div class="stat-bar" style="width:${Math.min(100,count/topAirlines[0][1]*100)}%"></div></div>
          <span class="stat-airline-count">${count}</span>
        </div>`).join("")}
    </div>`:""}
    <button onclick="clearStats()" style="display:block;margin:14px auto 0;font-size:12px;padding:6px 14px;background:#fee2e2;color:#dc2626;border:none;border-radius:6px;cursor:pointer;">
      <i class="fas fa-trash"></i> ${isAr?"مسح الإحصاء":"Clear Stats"}
    </button>`;
}

function clearStats() {
  MG.del("stats"); MG.del("statsWeek"); renderStatsPopup();
  showToast(currentLang==="ar"?"تم مسح الإحصاء":"Stats cleared");
}

/* ═══════════════════════════════════════════════════════
   12 – BUILD YOUR PACKAGE
   ═══════════════════════════════════════════════════════ */
let packageItems = [];

function addPackageItem() {
  const isAr = currentLang==="ar";
  packageItems.push({id:Date.now(),type:"ticket",desc:"",amount:0,pax:1});
  renderPackageRows();
}

function removePackageItem(id) {
  packageItems = packageItems.filter(p=>p.id!==id);
  renderPackageRows();
}

function renderPackageRows() {
  const container = document.getElementById("packageRows");
  if (!container) return;
  const isAr = currentLang==="ar";
  const types = {
    ticket:isAr?"✈ تذكرة":"✈ Ticket", hotel:isAr?"🏨 فندق":"🏨 Hotel",
    visa:isAr?"📋 تأشيرة":"📋 Visa",  insurance:isAr?"🛡 تأمين":"🛡 Insurance",
    transfer:isAr?"🚗 نقل":"🚗 Transfer", tour:isAr?"🗺 جولة":"🗺 Tour",
    other:isAr?"📌 أخرى":"📌 Other"
  };

  if (!packageItems.length) {
    container.innerHTML = `<p style="text-align:center;color:#94a3b8;padding:20px;font-style:italic;">${isAr?"اضغط + لإضافة بند":"Click + to add item"}</p>`;
    updatePackageTotal(); return;
  }

  container.innerHTML = packageItems.map(item=>`
    <div class="pkg-row">
      <select class="pkg-type" onchange="updatePkgField(${item.id},'type',this.value)">
        ${Object.entries(types).map(([k,v])=>`<option value="${k}" ${item.type===k?"selected":""}>${v}</option>`).join("")}
      </select>
      <input class="pkg-desc" type="text" placeholder="${isAr?"الوصف":"Description"}" value="${item.desc||""}" oninput="updatePkgField(${item.id},'desc',this.value)"/>
      <input class="pkg-pax" type="number" min="1" value="${item.pax||1}" title="${isAr?"أشخاص":"Pax"}" oninput="updatePkgField(${item.id},'pax',parseInt(this.value)||1)"/>
      <input class="pkg-amount" type="number" min="0" step="0.001" placeholder="0.000" value="${item.amount||""}" oninput="updatePkgField(${item.id},'amount',parseFloat(this.value)||0)"/>
      <button class="pkg-del" onclick="removePackageItem(${item.id})"><i class="fas fa-times"></i></button>
    </div>`).join("");
  updatePackageTotal();
}

function updatePkgField(id,field,value) {
  const item=packageItems.find(p=>p.id===id);
  if(item){item[field]=value;updatePackageTotal();}
}

function updatePackageTotal() {
  const currency = document.getElementById("packageCurrency")?.value||"KWD";
  const sym=getCurrSymbol(currency), dp=getCurrDP(currency);
  const total = packageItems.reduce((s,i)=>s+(parseFloat(i.amount)||0)*(parseInt(i.pax)||1),0);
  const el=document.getElementById("packageTotal");
  if(el) el.innerHTML=`${sym} ${total.toFixed(dp)}`;
  buildPackagePreview(currency,sym,dp);
}

function buildPackagePreview(currency,sym,dp) {
  const isAr=currentLang==="ar";
  const preview=document.getElementById("packagePreview");
  if(!preview||!packageItems.length){if(preview)preview.innerHTML="";return;}
  const typeLabels={ticket:isAr?"✈ تذكرة":"✈ Ticket",hotel:isAr?"🏨 فندق":"🏨 Hotel",visa:isAr?"📋 تأشيرة":"📋 Visa",insurance:isAr?"🛡 تأمين":"🛡 Insurance",transfer:isAr?"🚗 نقل":"🚗 Transfer",tour:isAr?"🗺 جولة":"🗺 Tour",other:isAr?"📌 أخرى":"📌 Other"};
  let total=0;
  const rows=packageItems.map(item=>{
    const sub=(parseFloat(item.amount)||0)*(parseInt(item.pax)||1);
    total+=sub;
    return `<tr><td>${typeLabels[item.type]||item.type}</td><td>${item.desc||"–"}</td><td style="text-align:center">${item.pax||1}</td><td style="text-align:right">${sym} ${(parseFloat(item.amount)||0).toFixed(dp)}</td><td style="text-align:right;font-weight:600">${sym} ${sub.toFixed(dp)}</td></tr>`;
  }).join("");
  preview.innerHTML=`<div class="pkg-preview-wrap" dir="${isAr?"rtl":"ltr"}">
    <table class="pkg-table"><thead><tr>
      <th>${isAr?"النوع":"Type"}</th><th>${isAr?"الوصف":"Description"}</th>
      <th>${isAr?"أشخاص":"Pax"}</th><th>${isAr?"سعر الوحدة":"Unit Price"}</th>
      <th>${isAr?"الإجمالي":"Total"}</th>
    </tr></thead><tbody>${rows}</tbody>
    <tfoot><tr><td colspan="4" style="text-align:${isAr?"left":"right"};font-weight:700;padding:10px 8px">${isAr?"المجموع الكلي":"Grand Total"}</td>
      <td style="text-align:right;font-weight:800;color:#0d9488;font-size:16px;padding:10px 8px">${sym} ${total.toFixed(dp)}</td>
    </tr></tfoot></table></div>`;
}

function copyPackageTable() {
  const isAr=currentLang==="ar";
  const preview=document.getElementById("packagePreview");
  if(!preview||!preview.innerHTML){showToast(isAr?"لا توجد بيانات للنسخ":"Nothing to copy");return;}
  try{
    navigator.clipboard.write([new ClipboardItem({"text/html":new Blob([preview.innerHTML],{type:"text/html"}),"text/plain":new Blob([preview.innerText],{type:"text/plain"})})]).then(()=>showToast(isAr?"✅ تم نسخ الجدول":"✅ Table copied"));
  }catch{
    if(typeof fallbackCopy==="function") fallbackCopy(preview.innerHTML);
    showToast(isAr?"✅ تم النسخ":"✅ Copied");
  }
}

function printPackage() {
  const preview=document.getElementById("packagePreview");
  if(!preview||!preview.innerHTML){showToast(currentLang==="ar"?"لا توجد بيانات":"Nothing to print");return;}
  const isAr=currentLang==="ar";
  const s=MG.get("agentSettings",{});
  const win=window.open("","_blank");
  win.document.write(`<!DOCTYPE html><html dir="${isAr?"rtl":"ltr"}"><head><meta charset="UTF-8"><title>Package – ${s.agencyName||"Itinovo"}</title>
  <style>body{font-family:Arial,sans-serif;padding:20px;}.pkg-table{width:100%;border-collapse:collapse;}.pkg-table th,.pkg-table td{border:1px solid #ddd;padding:8px 12px;}.pkg-table th{background:#0a1628;color:#fff;}.pkg-table tfoot td{background:#f0fdf4;}</style></head>
  <body><h2 style="color:#0a1628">${isAr?"باقة السفر":"Travel Package"} – ${s.agencyName||"Itinovo"}</h2>${preview.innerHTML}</body></html>`);
  win.document.close();
  setTimeout(()=>win.print(),400);
}

/* ═══════════════════════════════════════════════════════
   25 – COMMISSION TRACKER
   ═══════════════════════════════════════════════════════ */
function calcCommission() {
  const ticket=parseFloat(document.getElementById("commTicketPrice")?.value)||0;
  const rate  =parseFloat(document.getElementById("commRate")?.value)||0;
  const svc   =parseFloat(document.getElementById("commServiceCharge")?.value)||0;
  const currency=document.getElementById("commCurrency")?.value||"KWD";
  const sym=getCurrSymbol(currency), dp=getCurrDP(currency);
  const commission=ticket*rate/100;
  const profit=commission+svc;
  const gross=ticket+svc;
  const isAr=currentLang==="ar";
  const el=document.getElementById("commResult");
  if(!el) return;
  el.innerHTML=`<div class="comm-result-grid">
    <div class="comm-row"><span>${isAr?"سعر التذكرة":"Ticket Price"}</span><span>${sym} ${ticket.toFixed(dp)}</span></div>
    <div class="comm-row"><span>${isAr?"العمولة":"Commission"} (${rate}%)</span><span style="color:#0d9488">${sym} ${commission.toFixed(dp)}</span></div>
    <div class="comm-row"><span>${isAr?"رسوم الخدمة":"Service Charge"}</span><span>${sym} ${svc.toFixed(dp)}</span></div>
    <div class="comm-row comm-total"><span>${isAr?"صافي الربح":"Net Profit"}</span><span style="color:#16a34a;font-weight:800">${sym} ${profit.toFixed(dp)}</span></div>
    <div class="comm-row" style="border-top:1px dashed #e2e8f0;margin-top:6px;padding-top:8px">
      <span>${isAr?"العميل يدفع":"Client Pays"}</span><span style="font-weight:700">${sym} ${gross.toFixed(dp)}</span>
    </div></div>`;
  // Save
  let tracker=MG.get("commTracker",[]);
  tracker.unshift({date:new Date().toISOString(),ticket,comm:commission,svc,currency,month:new Date().toISOString().slice(0,7)});
  MG.set("commTracker",tracker.slice(0,100));
  renderCommissionSummary();
}

function renderCommissionSummary() {
  const isAr=currentLang==="ar";
  const tracker=MG.get("commTracker",[]);
  const month=new Date().toISOString().slice(0,7);
  const thisMonth=tracker.filter(t=>t.month===month);
  const totalProfit=thisMonth.reduce((s,t)=>s+(t.comm||0)+(t.svc||0),0);
  const el=document.getElementById("commMonthlySummary");
  if(!el) return;
  el.innerHTML=`<div class="comm-monthly">
    <i class="fas fa-chart-line" style="color:#0d9488"></i>
    <span>${isAr?"هذا الشهر:":"This Month:"} <strong>${thisMonth.length}</strong> ${isAr?"صفقة":"deals"}</span>
    <span style="margin-left:auto;font-weight:700;color:#16a34a">${isAr?"الربح:":"Profit:"} ${totalProfit.toFixed(3)}</span>
  </div>`;
}

/* ═══════════════════════════════════════════════════════
   26 – PNR EXPIRATION ALERT
   ═══════════════════════════════════════════════════════ */
function checkPNRExpiry() {
  const dateStr=document.getElementById("pnrExpiryDate")?.value;
  const refStr =document.getElementById("pnrRef")?.value.trim()||"";
  const el     =document.getElementById("expiryResult");
  const isAr   =currentLang==="ar";
  if(!el) return;
  if(!dateStr){el.innerHTML=`<p style="color:#f97316"><i class="fas fa-exclamation-circle"></i> ${isAr?"أدخل تاريخ الانتهاء":"Enter expiry date"}</p>`;return;}
  const expiry=new Date(dateStr), now=new Date();
  const diff=Math.ceil((expiry-now)/86400000);
  let color="#16a34a",icon="check-circle",msg="";
  if(diff<0){color="#dc2626";icon="times-circle";msg=isAr?`انتهت صلاحية PNR منذ ${Math.abs(diff)} يوم`:`PNR expired ${Math.abs(diff)} days ago`;}
  else if(diff===0){color="#dc2626";icon="exclamation-circle";msg=isAr?"PNR تنتهي صلاحيته اليوم! تصرف الآن":"PNR expires TODAY! Act now";}
  else if(diff<=2){color="#f97316";icon="exclamation-triangle";msg=isAr?`تنتهي خلال ${diff} يوم`:`Expires in ${diff} day(s) – urgent`;}
  else if(diff<=7){color="#d97706";icon="clock";msg=isAr?`تنتهي خلال ${diff} أيام`:`Expires in ${diff} days`;}
  else{msg=isAr?`صالحة لـ ${diff} يوماً`:`Valid for ${diff} more days`;}
  el.innerHTML=`<div class="expiry-result" style="border-color:${color};background:${color}18">
    <i class="fas fa-${icon}" style="color:${color};font-size:20px;flex-shrink:0"></i>
    <div>${refStr?`<div style="font-size:12px;color:#64748b;margin-bottom:4px">${isAr?"المرجع:":"Ref:"} ${refStr}</div>`:""}
    <div style="color:${color};font-weight:600">${msg}</div>
    <div style="font-size:12px;color:#64748b;margin-top:4px">${isAr?"تاريخ الانتهاء:":"Expires:"} ${expiry.toLocaleDateString(isAr?"ar-KW":"en-GB")}</div></div></div>`;
  // Save
  let alerts=MG.get("pnrAlerts",[]);
  alerts=alerts.filter(a=>!(a.ref===refStr&&a.date===dateStr));
  alerts.unshift({ref:refStr,date:dateStr,daysLeft:diff,savedAt:new Date().toISOString()});
  MG.set("pnrAlerts",alerts.slice(0,20));
}

function checkSavedAlerts() {
  const alerts=MG.get("pnrAlerts",[]);
  const urgent=alerts.filter(a=>{const d=Math.ceil((new Date(a.date)-new Date())/86400000);return d>=0&&d<=2;});
  if(urgent.length>0) showToast(currentLang==="ar"?`⚠️ ${urgent.length} PNR تنتهي قريباً`:`⚠️ ${urgent.length} PNR(s) expiring soon`,6000,"#f97316");
}

/* ═══════════════════════════════════════════════════════
   28 – TIME ZONE DIFFERENCE
   ═══════════════════════════════════════════════════════ */
const CITY_ZONES = {
  "Kuwait":"Asia/Kuwait","Bahrain":"Asia/Bahrain","Dubai":"Asia/Dubai","Abu Dhabi":"Asia/Dubai",
  "Riyadh":"Asia/Riyadh","Doha":"Asia/Qatar","Muscat":"Asia/Muscat","Cairo":"Africa/Cairo",
  "Beirut":"Asia/Beirut","Amman":"Asia/Amman","Istanbul":"Europe/Istanbul",
  "London":"Europe/London","Paris":"Europe/Paris","Frankfurt":"Europe/Berlin",
  "Amsterdam":"Europe/Amsterdam","Zurich":"Europe/Zurich","Vienna":"Europe/Vienna",
  "Madrid":"Europe/Madrid","Rome":"Europe/Rome","Athens":"Europe/Athens",
  "Moscow":"Europe/Moscow","New York":"America/New_York","Los Angeles":"America/Los_Angeles",
  "Chicago":"America/Chicago","Toronto":"America/Toronto","Vancouver":"America/Vancouver",
  "Mumbai":"Asia/Kolkata","Delhi":"Asia/Kolkata","Karachi":"Asia/Karachi",
  "Islamabad":"Asia/Karachi","Colombo":"Asia/Colombo","Dhaka":"Asia/Dhaka",
  "Bangkok":"Asia/Bangkok","Singapore":"Asia/Singapore","Kuala Lumpur":"Asia/Kuala_Lumpur",
  "Manila":"Asia/Manila","Hong Kong":"Asia/Hong_Kong","Seoul":"Asia/Seoul",
  "Tokyo":"Asia/Tokyo","Sydney":"Australia/Sydney","Melbourne":"Australia/Melbourne",
  "Auckland":"Pacific/Auckland","Nairobi":"Africa/Nairobi","Johannesburg":"Africa/Johannesburg",
  "Lagos":"Africa/Lagos","São Paulo":"America/Sao_Paulo","Mexico City":"America/Mexico_City"
};

function calcTimeDiff() {
  const city1=document.getElementById("tzCity1")?.value;
  const city2=document.getElementById("tzCity2")?.value;
  const el=document.getElementById("tzResult");
  const isAr=currentLang==="ar";
  if(!el||!city1||!city2) return;
  const tz1=CITY_ZONES[city1],tz2=CITY_ZONES[city2];
  if(!tz1||!tz2){el.innerHTML=`<p style="color:#f97316">${isAr?"مدينة غير معروفة":"Unknown city"}</p>`;return;}
  const now=new Date();
  const fmt=tz=>new Date(now.toLocaleString("en-US",{timeZone:tz}));
  const t1=fmt(tz1),t2=fmt(tz2);
  const diffH=(t2-t1)/3600000;
  const absDiff=Math.abs(diffH);
  const h=Math.floor(absDiff),m=Math.round((absDiff-h)*60);
  const sign=diffH>=0?"+":"-";
  const timeStr=tz=>now.toLocaleTimeString(isAr?"ar-KW":"en-GB",{timeZone:tz,hour:"2-digit",minute:"2-digit"});
  const dateStr=tz=>now.toLocaleDateString(isAr?"ar-KW":"en-GB",{timeZone:tz,weekday:"short",day:"numeric",month:"short"});
  el.innerHTML=`<div class="tz-result">
    <div class="tz-card"><div class="tz-city">${city1}</div><div class="tz-time">${timeStr(tz1)}</div><div class="tz-date">${dateStr(tz1)}</div></div>
    <div class="tz-diff"><div class="tz-arrow">↔</div><div class="tz-diff-val">${sign}${h}h${m?` ${m}m`:""}</div></div>
    <div class="tz-card"><div class="tz-city">${city2}</div><div class="tz-time">${timeStr(tz2)}</div><div class="tz-date">${dateStr(tz2)}</div></div>
  </div>
  <p style="text-align:center;font-size:13px;color:#64748b;margin-top:8px">
    ${city2} ${diffH>=0?(isAr?"يسبق":"is ahead of"):(isAr?"يتأخر عن":"is behind")} ${city1} ${isAr?"بـ":"by"} <strong>${sign}${h}${m?":"+String(m).padStart(2,"0"):""}h</strong>
  </p>`;
}

/* ═══════════════════════════════════════════════════════
   34 – WHATSAPP PERSONAL TEMPLATE
   ═══════════════════════════════════════════════════════ */
function generateWhatsAppMsg() {
  const isAr=currentLang==="ar";
  const segs=window._lastSegments||[];
  if(!segs.length){showToast(isAr?"قم بتحويل رحلة أولاً":"Convert an itinerary first",3000,"#f97316");return;}

  const opts = (typeof gatherOpts==="function") ? gatherOpts() : {};
  let msg = buildStructuredShareText(segs, opts, isAr);

  const s=MG.get("agentSettings",{});
  const signOff = document.getElementById("agentSignOff")?.value.trim() || [s.agentName,s.agencyName,s.agentPhone].filter(Boolean).join("\n");
  if (signOff) msg += `\n${signOff}`;

  const preview = document.getElementById("whatsappPreview");
  preview.innerText = msg;
  preview.setAttribute("contenteditable","true");
  document.getElementById("whatsappPreviewWrap").style.display="block";
  showToast(isAr?"✏️ يمكنك تعديل السعر أو الوزن قبل الإرسال":"✏️ You can edit the price or weight before sending",3500,"#0d9488");
}

function sendWhatsApp() {
  const msg=document.getElementById("whatsappPreview")?.innerText;
  if(!msg) return;
  window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`,"_blank");
}

function copyWhatsAppMsg() {
  const msg=document.getElementById("whatsappPreview")?.innerText;
  if(!msg) return;
  navigator.clipboard.writeText(msg).then(()=>showToast(currentLang==="ar"?"✅ تم نسخ الرسالة":"✅ Message copied"));
}

/* ═══════════════════════════════════════════════════════
   41 – VISA WARNING (FULL IMPLEMENTATION)
   ═══════════════════════════════════════════════════════ */

/* ── Full IATA→Country Map ── */
const IATA_COUNTRY = {
  /* Gulf */
  KWI:"KW",DXB:"AE",AUH:"AE",SHJ:"AE",AJM:"AE",RKT:"AE",FJR:"AE",
  DOH:"QA",BAH:"BH",MCT:"OM",SLL:"OM",ADE:"YE",SAH:"YE",
  RUH:"SA",JED:"SA",DMM:"SA",MED:"SA",TIF:"SA",AHB:"SA",YNB:"SA",HOF:"SA",ABT:"SA",
  /* Arab World */
  CAI:"EG",HRG:"EG",SSH:"EG",LXR:"EG",AMM:"JO",AQJ:"JO",
  BEY:"LB",TLV:"IL",SDV:"IL",BGW:"IQ",BSR:"IQ",EBL:"IQ",NJF:"IQ",
  DAM:"SY",KHT:"AF",KBL:"AF",
  TUN:"TN",ALG:"DZ",CMN:"MA",RAK:"MA",AGA:"MA",FEZ:"MA",
  TIP:"LY",BEN:"LY",KRT:"SD",
  /* Europe */
  LHR:"GB",LGW:"GB",STN:"GB",MAN:"GB",EDI:"GB",GLA:"GB",BHX:"GB",
  CDG:"FR",ORY:"FR",NCE:"FR",MRS:"FR",LYS:"FR",
  FRA:"DE",MUC:"DE",BER:"DE",DUS:"DE",HAM:"DE",STR:"DE",CGN:"DE",
  AMS:"NL",ZRH:"CH",GVA:"CH",VIE:"AT",BRU:"BE",
  MAD:"ES",BCN:"ES",PMI:"ES",AGP:"ES",ALC:"ES",VLC:"ES",SVQ:"ES",
  FCO:"IT",MXP:"IT",VCE:"IT",NAP:"IT",BLQ:"IT",PSA:"IT",
  ATH:"GR",SKG:"GR",HER:"GR",RHO:"GR",
  LIS:"PT",OPO:"PT",ARN:"SE",CPH:"DK",OSL:"NO",HEL:"FI",
  DUB:"IE",PRG:"CZ",BUD:"HU",WAW:"PL",BUH:"RO",SOF:"BG",
  ZAG:"HR",LJU:"SI",SKP:"MK",TIA:"AL",BEG:"RS",SJJ:"BA",
  OTP:"RO",KIV:"MD",TBS:"GE",EVN:"AM",GYD:"AZ",
  SVO:"RU",DME:"RU",LED:"RU",KZN:"RU",
  IEV:"UA",KBP:"UA",LWO:"UA",
  /* North America */
  JFK:"US",LAX:"US",ORD:"US",ATL:"US",SFO:"US",MIA:"US",BOS:"US",
  DFW:"US",SEA:"US",DEN:"US",LAS:"US",MCO:"US",PHL:"US",IAD:"US",
  EWR:"US",CLT:"US",MSP:"US",DTW:"US",PDX:"US",SAN:"US",
  YYZ:"CA",YVR:"CA",YUL:"CA",YYC:"CA",YOW:"CA",YHZ:"CA",YEG:"CA",
  MEX:"MX",CUN:"MX",GDL:"MX",MTY:"MX",
  /* South & Central America */
  GRU:"BR",GIG:"BR",BSB:"BR",FOR:"BR",SSA:"BR",REC:"BR",
  EZE:"AR",AEP:"AR",SCL:"CL",BOG:"CO",LIM:"PE",UIO:"EC",GYE:"EC",
  ASU:"PY",MVD:"UY",LPB:"BO",CCS:"VE",
  HAV:"CU",MBJ:"JM",POS:"TT",BGI:"BB",
  /* Asia */
  DEL:"IN",BOM:"IN",MAA:"IN",BLR:"IN",CCU:"IN",HYD:"IN",COK:"IN",
  AMD:"IN",GOI:"IN",JAI:"IN",PNQ:"IN",LKO:"IN",IXC:"IN",ATQ:"IN",
  CMB:"LK",DAC:"BD",CGP:"BD",ZYL:"BD",
  KHI:"PK",LHE:"PK",ISB:"PK",SKT:"PK",PEW:"PK",MUX:"PK",
  KTM:"NP",PBH:"BT",MLE:"MV",
  RGN:"MM",BKK:"TH",DMK:"TH",HKT:"TH",CNX:"TH",USM:"TH",
  SIN:"SG",KUL:"MY",PEN:"MY",LGK:"MY",BKI:"MY",JHB:"MY",
  CGK:"ID",DPS:"ID",SUB:"ID",UPG:"ID",MDC:"ID",PLM:"ID",
  MNL:"PH",CEB:"PH",DVO:"PH",ILO:"PH",
  HAN:"VN",SGN:"VN",DAD:"VN",
  PNH:"KH",VTE:"LA",RGN:"MM",
  HKG:"HK",MFM:"MO",
  PEK:"CN",PKX:"CN",PVG:"CN",SHA:"CN",CAN:"CN",SZX:"CN",CTU:"CN",
  XMN:"CN",WUH:"CN",KMG:"CN",HGH:"CN",NKG:"CN",CSX:"CN",CKG:"CN",
  ICN:"KR",GMP:"KR",PUS:"KR",
  NRT:"JP",HND:"JP",KIX:"JP",ITM:"JP",CTS:"JP",FUK:"JP",NGO:"JP",OKA:"JP",
  TPE:"TW",TSA:"TW",KHH:"TW",
  /* Australia & NZ */
  SYD:"AU",MEL:"AU",BNE:"AU",PER:"AU",ADL:"AU",CBR:"AU",DRW:"AU",OOL:"AU",
  AKL:"NZ",CHC:"NZ",WLG:"NZ",
  /* Africa */
  NBO:"KE",MBA:"KE",ADD:"ET",DIR:"ET",JNB:"ZA",CPT:"ZA",DUR:"ZA",
  LOS:"NG",ABV:"NG",KAN:"NG",ACC:"GH",ABJ:"CI",DKR:"SN",
  TNR:"MG",MRU:"MU",SEZ:"SC",
  /* Other Asia */
  ULN:"MN",TSE:"KZ",ALA:"KZ",TAS:"UZ",OSS:"KG",DYU:"TJ",ASB:"TM",
  LHE:"PK"
};

/* ── Country Names (EN & AR) ── */
const COUNTRY_NAMES = {
  KW:{en:"Kuwait",ar:"الكويت"},AE:{en:"UAE",ar:"الإمارات"},SA:{en:"Saudi Arabia",ar:"السعودية"},
  BH:{en:"Bahrain",ar:"البحرين"},QA:{en:"Qatar",ar:"قطر"},OM:{en:"Oman",ar:"عُمان"},
  EG:{en:"Egypt",ar:"مصر"},JO:{en:"Jordan",ar:"الأردن"},LB:{en:"Lebanon",ar:"لبنان"},
  SY:{en:"Syria",ar:"سوريا"},IQ:{en:"Iraq",ar:"العراق"},YE:{en:"Yemen",ar:"اليمن"},
  PS:{en:"Palestine",ar:"فلسطين"},IL:{en:"Israel",ar:"إسرائيل"},
  TR:{en:"Turkey",ar:"تركيا"},IR:{en:"Iran",ar:"إيران"},
  GB:{en:"UK",ar:"المملكة المتحدة"},FR:{en:"France",ar:"فرنسا"},
  DE:{en:"Germany",ar:"ألمانيا"},IT:{en:"Italy",ar:"إيطاليا"},
  ES:{en:"Spain",ar:"إسبانيا"},NL:{en:"Netherlands",ar:"هولندا"},
  CH:{en:"Switzerland",ar:"سويسرا"},AT:{en:"Austria",ar:"النمسا"},
  BE:{en:"Belgium",ar:"بلجيكا"},PT:{en:"Portugal",ar:"البرتغال"},
  GR:{en:"Greece",ar:"اليونان"},SE:{en:"Sweden",ar:"السويد"},
  DK:{en:"Denmark",ar:"الدنمارك"},NO:{en:"Norway",ar:"النرويج"},
  FI:{en:"Finland",ar:"فنلندا"},IE:{en:"Ireland",ar:"أيرلندا"},
  PL:{en:"Poland",ar:"بولندا"},CZ:{en:"Czech Republic",ar:"التشيك"},
  HU:{en:"Hungary",ar:"المجر"},RO:{en:"Romania",ar:"رومانيا"},
  RU:{en:"Russia",ar:"روسيا"},UA:{en:"Ukraine",ar:"أوكرانيا"},
  US:{en:"USA",ar:"الولايات المتحدة"},CA:{en:"Canada",ar:"كندا"},
  MX:{en:"Mexico",ar:"المكسيك"},BR:{en:"Brazil",ar:"البرازيل"},
  AR:{en:"Argentina",ar:"الأرجنتين"},AU:{en:"Australia",ar:"أستراليا"},
  NZ:{en:"New Zealand",ar:"نيوزيلندا"},
  IN:{en:"India",ar:"الهند"},PK:{en:"Pakistan",ar:"باكستان"},
  BD:{en:"Bangladesh",ar:"بنغلاديش"},LK:{en:"Sri Lanka",ar:"سريلانكا"},
  NP:{en:"Nepal",ar:"نيبال"},MV:{en:"Maldives",ar:"المالديف"},
  TH:{en:"Thailand",ar:"تايلاند"},SG:{en:"Singapore",ar:"سنغافورة"},
  MY:{en:"Malaysia",ar:"ماليزيا"},ID:{en:"Indonesia",ar:"إندونيسيا"},
  PH:{en:"Philippines",ar:"الفلبين"},VN:{en:"Vietnam",ar:"فيتنام"},
  KH:{en:"Cambodia",ar:"كمبوديا"},MM:{en:"Myanmar",ar:"ميانمار"},
  HK:{en:"Hong Kong",ar:"هونج كونج"},CN:{en:"China",ar:"الصين"},
  KR:{en:"South Korea",ar:"كوريا الجنوبية"},JP:{en:"Japan",ar:"اليابان"},
  TW:{en:"Taiwan",ar:"تايوان"},MO:{en:"Macau",ar:"ماكاو"},
  KE:{en:"Kenya",ar:"كينيا"},ET:{en:"Ethiopia",ar:"إثيوبيا"},
  ZA:{en:"South Africa",ar:"جنوب أفريقيا"},NG:{en:"Nigeria",ar:"نيجيريا"},
  GH:{en:"Ghana",ar:"غانا"},SN:{en:"Senegal",ar:"السنغال"},
  MU:{en:"Mauritius",ar:"موريشيوس"},MA:{en:"Morocco",ar:"المغرب"},
  DZ:{en:"Algeria",ar:"الجزائر"},TN:{en:"Tunisia",ar:"تونس"},
  TZ:{en:"Tanzania",ar:"تنزانيا"},UG:{en:"Uganda",ar:"أوغندا"},
  KZ:{en:"Kazakhstan",ar:"كازاخستان"},UZ:{en:"Uzbekistan",ar:"أوزبكستان"}
};

/* ── Comprehensive Visa Database ──
   Format: "NATIONALITY→DESTINATION" : {status, note, noteAr, link}
   status: "free" | "voa" | "evisa" | "required" | "eta"
── */
const VISA_DB_FULL = {
  /* ═══ KUWAIT (KW) PASSPORT ═══ */
  /* Gulf Cooperation Council - Visa Free */
  "KW→AE":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "KW→SA":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "KW→BH":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "KW→QA":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "KW→OM":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  /* Arab countries */
  "KW→EG":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "KW→JO":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "KW→LB":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "KW→MA":{status:"free",note:"No visa required (90 days)",noteAr:"لا تأشيرة (90 يوماً)"},
  "KW→TN":{status:"free",note:"No visa required (30 days)",noteAr:"لا تأشيرة (30 يوماً)"},
  "KW→TR":{status:"voa",note:"Visa on arrival (30 days) – eVisa also available",noteAr:"تأشيرة عند الوصول (30 يوماً) أو إلكترونية",link:"https://www.evisa.gov.tr"},
  /* Asia */
  "KW→TH":{status:"voa",note:"Visa on arrival – 30 days (BOI waiver may apply)",noteAr:"تأشيرة عند الوصول – 30 يوماً"},
  "KW→MY":{status:"free",note:"No visa required – 30 days",noteAr:"لا تأشيرة – 30 يوماً"},
  "KW→SG":{status:"free",note:"No visa required – 30 days",noteAr:"لا تأشيرة – 30 يوماً"},
  "KW→ID":{status:"voa",note:"Visa on arrival – 30 days (extendable)",noteAr:"تأشيرة عند الوصول – 30 يوماً"},
  "KW→PH":{status:"voa",note:"Visa on arrival – 30 days",noteAr:"تأشيرة عند الوصول – 30 يوماً"},
  "KW→MV":{status:"voa",note:"Visa on arrival – 30 days (Free)",noteAr:"تأشيرة مجانية عند الوصول – 30 يوماً"},
  "KW→LK":{status:"eta",note:"ETA required – apply online before travel",noteAr:"تصريح إلكتروني مطلوب قبل السفر",link:"https://www.eta.gov.lk"},
  "KW→IN":{status:"evisa",note:"e-Visa required – apply at least 4 days before",noteAr:"تأشيرة إلكترونية مطلوبة قبل 4 أيام",link:"https://indianvisaonline.gov.in"},
  "KW→JP":{status:"required",note:"Visa required – apply at Japanese embassy",noteAr:"تأشيرة مطلوبة من سفارة اليابان"},
  "KW→KR":{status:"eta",note:"K-ETA required (electronic – free)",noteAr:"K-ETA إلكتروني مطلوب (مجاني)",link:"https://www.k-eta.go.kr"},
  "KW→CN":{status:"required",note:"Visa required – apply at Chinese embassy",noteAr:"تأشيرة مطلوبة من سفارة الصين"},
  "KW→HK":{status:"free",note:"No visa required – 30 days",noteAr:"لا تأشيرة – 30 يوماً"},
  "KW→VN":{status:"evisa",note:"e-Visa available online (90 days, single/multiple)",noteAr:"تأشيرة إلكترونية متاحة (90 يوماً)",link:"https://evisa.xuatnhapcanh.gov.vn"},
  "KW→KH":{status:"voa",note:"Visa on arrival – 30 days",noteAr:"تأشيرة عند الوصول – 30 يوماً"},
  "KW→KZ":{status:"free",note:"No visa required – 30 days",noteAr:"لا تأشيرة – 30 يوماً"},
  /* Europe */
  "KW→GB":{status:"required",note:"UK Standard Visitor Visa required",noteAr:"تأشيرة زيارة بريطانية مطلوبة"},
  "KW→FR":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→DE":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→IT":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→ES":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→NL":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→CH":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→AT":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→BE":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→PT":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→GR":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→SE":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→DK":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→NO":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→FI":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "KW→RU":{status:"required",note:"Visa required – check current travel advisories",noteAr:"تأشيرة مطلوبة – راجع التحذيرات الحالية"},
  /* Americas */
  "KW→US":{status:"required",note:"US B1/B2 Tourist Visa required",noteAr:"تأشيرة أمريكية B1/B2 مطلوبة"},
  "KW→CA":{status:"required",note:"Canadian Visa or eTA required",noteAr:"تأشيرة كندية أو eTA مطلوبة"},
  "KW→MX":{status:"free",note:"No visa required – 180 days",noteAr:"لا تأشيرة – 180 يوماً"},
  "KW→BR":{status:"evisa",note:"e-Visa required – apply online",noteAr:"تأشيرة إلكترونية مطلوبة",link:"https://evisas.itamaraty.gov.br"},
  "KW→AR":{status:"free",note:"No visa required – 90 days",noteAr:"لا تأشيرة – 90 يوماً"},
  /* Pacific */
  "KW→AU":{status:"eta",note:"ETA (subclass 601) required – apply via app/online",noteAr:"تصريح إلكتروني ETA مطلوب",link:"https://immi.homeaffairs.gov.au"},
  "KW→NZ":{status:"eta",note:"NZeTA required – apply online before travel",noteAr:"تصريح NZeTA مطلوب قبل السفر",link:"https://www.immigration.govt.nz"},
  /* Africa */
  "KW→KE":{status:"evisa",note:"e-Visa required – apply online",noteAr:"تأشيرة إلكترونية مطلوبة",link:"https://evisa.go.ke"},
  "KW→ET":{status:"evisa",note:"e-Visa required (EEO) – apply online",noteAr:"تأشيرة إلكترونية مطلوبة",link:"https://www.evisa.gov.et"},
  "KW→ZA":{status:"free",note:"No visa required – 30 days",noteAr:"لا تأشيرة – 30 يوماً"},
  "KW→MU":{status:"free",note:"No visa required – 90 days",noteAr:"لا تأشيرة – 90 يوماً"},

  /* ═══ UAE (AE) PASSPORT ═══ */
  "AE→KW":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "AE→SA":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "AE→EG":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "AE→GB":{status:"free",note:"No visa required – 6 months",noteAr:"لا تأشيرة – 6 أشهر"},
  "AE→FR":{status:"free",note:"No visa required (Schengen – 90 days)",noteAr:"لا تأشيرة – 90 يوماً"},
  "AE→US":{status:"free",note:"ESTA required (Visa Waiver Program)",noteAr:"ESTA مطلوب (برنامج إعفاء التأشيرة)",link:"https://esta.cbp.dhs.gov"},
  "AE→JP":{status:"free",note:"No visa required – 30 days",noteAr:"لا تأشيرة – 30 يوماً"},
  "AE→KR":{status:"free",note:"No visa required – 90 days",noteAr:"لا تأشيرة – 90 يوماً"},
  "AE→AU":{status:"free",note:"No visa required – 3 months",noteAr:"لا تأشيرة – 3 أشهر"},
  "AE→CA":{status:"eta",note:"eTA required (free for visa-exempt)",noteAr:"eTA مطلوب (مجاني)",link:"https://www.canada.ca/en/immigration-refugees-citizenship/services/visit-canada/eta.html"},
  "AE→IN":{status:"evisa",note:"e-Visa available online",noteAr:"تأشيرة إلكترونية متاحة",link:"https://indianvisaonline.gov.in"},
  "AE→CN":{status:"free",note:"No visa required – 30 days (new 2024 policy)",noteAr:"لا تأشيرة – 30 يوماً (سياسة 2024)"},

  /* ═══ SAUDI ARABIA (SA) PASSPORT ═══ */
  "SA→AE":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "SA→KW":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "SA→EG":{status:"free",note:"No visa required",noteAr:"لا يلزم تأشيرة"},
  "SA→TR":{status:"voa",note:"Visa on arrival or eVisa",noteAr:"تأشيرة عند الوصول أو إلكترونية",link:"https://www.evisa.gov.tr"},
  "SA→GB":{status:"required",note:"UK Standard Visitor Visa required",noteAr:"تأشيرة بريطانية مطلوبة"},
  "SA→FR":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "SA→US":{status:"required",note:"US Visa required",noteAr:"تأشيرة أمريكية مطلوبة"},
  "SA→AU":{status:"required",note:"Australian Visa required",noteAr:"تأشيرة أسترالية مطلوبة"},
  "SA→IN":{status:"evisa",note:"e-Visa available online",noteAr:"تأشيرة إلكترونية متاحة",link:"https://indianvisaonline.gov.in"},

  /* ═══ INDIA (IN) PASSPORT ═══ */
  "IN→AE":{status:"free",note:"Visa on arrival (14-day) or prior visa",noteAr:"تأشيرة عند الوصول (14 يوماً) أو مسبقة"},
  "IN→TH":{status:"free",note:"No visa required – 30 days (e-Passport) or VoA",noteAr:"لا تأشيرة – 30 يوماً (جواز إلكتروني)"},
  "IN→MY":{status:"free",note:"No visa required – 30 days",noteAr:"لا تأشيرة – 30 يوماً"},
  "IN→SG":{status:"required",note:"Visa required or ICA approval",noteAr:"تأشيرة مطلوبة"},
  "IN→GB":{status:"required",note:"UK Standard Visitor Visa required",noteAr:"تأشيرة بريطانية مطلوبة"},
  "IN→FR":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "IN→US":{status:"required",note:"US B1/B2 Visa required",noteAr:"تأشيرة أمريكية B1/B2 مطلوبة"},
  "IN→CA":{status:"required",note:"Canadian Visa required",noteAr:"تأشيرة كندية مطلوبة"},
  "IN→AU":{status:"required",note:"Australian Visa required",noteAr:"تأشيرة أسترالية مطلوبة"},
  "IN→JP":{status:"free",note:"No visa required – 15 days (Indian e-Passport)",noteAr:"لا تأشيرة – 15 يوماً (جواز إلكتروني)"},

  /* ═══ PAKISTAN (PK) PASSPORT ═══ */
  "PK→AE":{status:"required",note:"Prior UAE visa required",noteAr:"تأشيرة إماراتية مسبقة مطلوبة"},
  "PK→TR":{status:"evisa",note:"e-Visa available online – 90 days",noteAr:"تأشيرة إلكترونية – 90 يوماً",link:"https://www.evisa.gov.tr"},
  "PK→MY":{status:"free",note:"No visa required – 30 days",noteAr:"لا تأشيرة – 30 يوماً"},
  "PK→TH":{status:"voa",note:"Visa on arrival – 30 days",noteAr:"تأشيرة عند الوصول – 30 يوماً"},
  "PK→GB":{status:"required",note:"UK Visa required",noteAr:"تأشيرة بريطانية مطلوبة"},
  "PK→US":{status:"required",note:"US Visa required",noteAr:"تأشيرة أمريكية مطلوبة"},

  /* ═══ EGYPT (EG) PASSPORT ═══ */
  "EG→AE":{status:"required",note:"Prior UAE visa required (online/embassy)",noteAr:"تأشيرة إماراتية مسبقة مطلوبة"},
  "EG→SA":{status:"required",note:"Saudi Visa required",noteAr:"تأشيرة سعودية مطلوبة"},
  "EG→KW":{status:"required",note:"Kuwaiti Visa required",noteAr:"تأشيرة كويتية مطلوبة"},
  "EG→TR":{status:"free",note:"No visa required – 90 days",noteAr:"لا تأشيرة – 90 يوماً"},
  "EG→GB":{status:"required",note:"UK Visa required",noteAr:"تأشيرة بريطانية مطلوبة"},
  "EG→FR":{status:"required",note:"Schengen Visa required",noteAr:"تأشيرة شنغن مطلوبة"},
  "EG→US":{status:"required",note:"US Visa required",noteAr:"تأشيرة أمريكية مطلوبة"},

  /* ═══ UK (GB) PASSPORT ═══ */
  "GB→AE":{status:"free",note:"No visa required – 90 days",noteAr:"لا تأشيرة – 90 يوماً"},
  "GB→SA":{status:"free",note:"eVisa required – apply online",noteAr:"تأشيرة إلكترونية مطلوبة",link:"https://visa.visitsaudi.com"},
  "GB→US":{status:"eta",note:"ESTA required (Visa Waiver Program)",noteAr:"ESTA مطلوب",link:"https://esta.cbp.dhs.gov"},
  "GB→AU":{status:"eta",note:"ETA required – apply via Australian ETA app",noteAr:"تصريح ETA مطلوب",link:"https://immi.homeaffairs.gov.au"},
  "GB→CA":{status:"eta",note:"eTA required – apply online before travel",noteAr:"eTA مطلوب قبل السفر",link:"https://www.canada.ca"},
  "GB→JP":{status:"free",note:"No visa required – 90 days",noteAr:"لا تأشيرة – 90 يوماً"},
  "GB→CN":{status:"free",note:"No visa required – 15 days (2024 visa-free policy)",noteAr:"لا تأشيرة – 15 يوماً (سياسة 2024)"},
  "GB→IN":{status:"evisa",note:"e-Visa available online",noteAr:"تأشيرة إلكترونية متاحة",link:"https://indianvisaonline.gov.in"},

  /* ═══ USA (US) PASSPORT ═══ */
  "US→AE":{status:"free",note:"No visa required – 30 days",noteAr:"لا تأشيرة – 30 يوماً"},
  "US→SA":{status:"free",note:"eVisa required – apply online",noteAr:"تأشيرة إلكترونية مطلوبة",link:"https://visa.visitsaudi.com"},
  "US→JP":{status:"free",note:"No visa required – 90 days",noteAr:"لا تأشيرة – 90 يوماً"},
  "US→CN":{status:"required",note:"Chinese Visa required",noteAr:"تأشيرة صينية مطلوبة"},
  "US→AU":{status:"eta",note:"ETA required – apply via Australian ETA app",noteAr:"تصريح ETA مطلوب",link:"https://immi.homeaffairs.gov.au"},
  "US→IN":{status:"evisa",note:"e-Visa available online",noteAr:"تأشيرة إلكترونية متاحة",link:"https://indianvisaonline.gov.in"},
  "US→GB":{status:"free",note:"No visa required – 6 months",noteAr:"لا تأشيرة – 6 أشهر"},
  "US→FR":{status:"free",note:"No visa required – 90 days (Schengen)",noteAr:"لا تأشيرة – 90 يوماً"},
  "US→RU":{status:"required",note:"Russian Visa required – check advisories",noteAr:"تأشيرة روسية مطلوبة"}
};

/* Status → display config */
const VISA_STATUS_CONFIG = {
  free:     {icon:"✅",cls:"visa-free",    label:"Visa Free",    labelAr:"بدون تأشيرة",   badgeCls:"badge-free"},
  voa:      {icon:"🟡",cls:"visa-voa",     label:"Visa on Arrival",labelAr:"عند الوصول",  badgeCls:"badge-voa"},
  eta:      {icon:"🔵",cls:"visa-eta",     label:"ETA / eVisa",  labelAr:"تصريح إلكتروني", badgeCls:"badge-eta"},
  evisa:    {icon:"🔵",cls:"visa-evisa",   label:"e-Visa Required",labelAr:"تأشيرة إلكترونية",badgeCls:"badge-eta"},
  required: {icon:"🔴",cls:"visa-required",label:"Visa Required", labelAr:"تأشيرة مطلوبة",badgeCls:"badge-req"}
};

/* Nationality passport list for the modal */
const PASSPORT_LIST = [
  {code:"KW",en:"🇰🇼 Kuwait",ar:"🇰🇼 الكويت"},
  {code:"AE",en:"🇦🇪 UAE",ar:"🇦🇪 الإمارات"},
  {code:"SA",en:"🇸🇦 Saudi Arabia",ar:"🇸🇦 السعودية"},
  {code:"BH",en:"🇧🇭 Bahrain",ar:"🇧🇭 البحرين"},
  {code:"QA",en:"🇶🇦 Qatar",ar:"🇶🇦 قطر"},
  {code:"OM",en:"🇴🇲 Oman",ar:"🇴🇲 عُمان"},
  {code:"EG",en:"🇪🇬 Egypt",ar:"🇪🇬 مصر"},
  {code:"JO",en:"🇯🇴 Jordan",ar:"🇯🇴 الأردن"},
  {code:"LB",en:"🇱🇧 Lebanon",ar:"🇱🇧 لبنان"},
  {code:"IQ",en:"🇮🇶 Iraq",ar:"🇮🇶 العراق"},
  {code:"YE",en:"🇾🇪 Yemen",ar:"🇾🇪 اليمن"},
  {code:"SY",en:"🇸🇾 Syria",ar:"🇸🇾 سوريا"},
  {code:"TR",en:"🇹🇷 Turkey",ar:"🇹🇷 تركيا"},
  {code:"GB",en:"🇬🇧 UK",ar:"🇬🇧 المملكة المتحدة"},
  {code:"US",en:"🇺🇸 USA",ar:"🇺🇸 الولايات المتحدة"},
  {code:"FR",en:"🇫🇷 France",ar:"🇫🇷 فرنسا"},
  {code:"DE",en:"🇩🇪 Germany",ar:"🇩🇪 ألمانيا"},
  {code:"IN",en:"🇮🇳 India",ar:"🇮🇳 الهند"},
  {code:"PK",en:"🇵🇰 Pakistan",ar:"🇵🇰 باكستان"},
  {code:"BD",en:"🇧🇩 Bangladesh",ar:"🇧🇩 بنغلاديش"},
  {code:"PH",en:"🇵🇭 Philippines",ar:"🇵🇭 الفلبين"},
  {code:"LK",en:"🇱🇰 Sri Lanka",ar:"🇱🇰 سريلانكا"},
  {code:"NP",en:"🇳🇵 Nepal",ar:"🇳🇵 نيبال"},
  {code:"MY",en:"🇲🇾 Malaysia",ar:"🇲🇾 ماليزيا"},
  {code:"AU",en:"🇦🇺 Australia",ar:"🇦🇺 أستراليا"},
  {code:"CA",en:"🇨🇦 Canada",ar:"🇨🇦 كندا"},
  {code:"JP",en:"🇯🇵 Japan",ar:"🇯🇵 اليابان"},
  {code:"KR",en:"🇰🇷 South Korea",ar:"🇰🇷 كوريا الجنوبية"}
];

/* ── Core lookup function ── */
function checkVisaRequirements(from, to) {
  const fc = IATA_COUNTRY[from], tc = IATA_COUNTRY[to];
  if (!fc || !tc || fc === tc) return null;
  const key = `${fc}→${tc}`;
  return VISA_DB_FULL[key] || null;
}

/* ── Build visa warnings block (used in output) ── */
function buildVisaWarnings(segments) {
  if (!segments || !segments.length) return "";
  const isAr = currentLang === "ar";
  const seen = new Set();
  const warnings = [];

  segments.forEach(seg => {
    const key = `${seg.from}→${seg.to}`;
    if (seen.has(key)) return;
    seen.add(key);
    const req = checkVisaRequirements(seg.from, seg.to);
    if (req) {
      const cfg = VISA_STATUS_CONFIG[req.status] || VISA_STATUS_CONFIG.required;
      const noteText = isAr ? req.noteAr : req.note;
      const fromC = COUNTRY_NAMES[IATA_COUNTRY[seg.from]];
      const toC   = COUNTRY_NAMES[IATA_COUNTRY[seg.to]];
      const fromName = fromC ? (isAr ? fromC.ar : fromC.en) : seg.from;
      const toName   = toC   ? (isAr ? toC.ar   : toC.en)   : seg.to;
      warnings.push(`
        <div class="visa-row ${cfg.cls}">
          <div class="visa-row-icon">${cfg.icon}</div>
          <div class="visa-row-body">
            <div class="visa-row-route">${fromName} <i class="fas fa-arrow-right" style="font-size:9px;margin:0 4px;color:#94a3b8"></i> ${toName}
              <span class="visa-badge ${cfg.badgeCls}">${isAr ? cfg.labelAr : cfg.label}</span>
            </div>
            <div class="visa-row-note">${noteText}${req.link ? ` <a href="${req.link}" target="_blank" class="visa-link" rel="noopener">🔗 ${isAr?"رابط":"Apply"}</a>` : ""}</div>
          </div>
        </div>`);
    }
  });

  if (!warnings.length) return "";
  return `<div class="visa-warnings-section">
    <div class="visa-header">
      <i class="fas fa-passport"></i>
      <span>${isAr ? "متطلبات التأشيرة" : "Visa Requirements"}</span>
      <button class="visa-expand-btn" onclick="openModal('visaModal')" title="${isAr?"فحص تفصيلي":"Full Check"}">
        <i class="fas fa-search-plus"></i> ${isAr?"فحص تفصيلي":"Full Check"}
      </button>
    </div>
    ${warnings.join("")}
    <small class="visa-disclaimer">${isAr?"معلومات تقريبية، تحقق دائماً من السفارة":"Approximate info – always verify with embassy"}</small>
  </div>`;
}

/* ──────────────────────────────────────────────────────
   41-B – VISA CHECK MODAL FUNCTIONS
   ────────────────────────────────────────────────────── */

/* Country display names (compact) */
const CNTR = {
  KW:"Kuwait",AE:"UAE",SA:"Saudi Arabia",BH:"Bahrain",QA:"Qatar",OM:"Oman",
  EG:"Egypt",JO:"Jordan",LB:"Lebanon",IQ:"Iraq",SY:"Syria",YE:"Yemen",
  MA:"Morocco",TN:"Tunisia",DZ:"Algeria",TR:"Turkey",
  IN:"India",PK:"Pakistan",BD:"Bangladesh",LK:"Sri Lanka",NP:"Nepal",
  PH:"Philippines",MY:"Malaysia",ID:"Indonesia",TH:"Thailand",SG:"Singapore",
  JP:"Japan",KR:"South Korea",CN:"China",HK:"Hong Kong",VN:"Vietnam",
  KH:"Cambodia",MV:"Maldives",KZ:"Kazakhstan",
  GB:"UK",FR:"France",DE:"Germany",IT:"Italy",ES:"Spain",NL:"Netherlands",
  CH:"Switzerland",AT:"Austria",BE:"Belgium",GR:"Greece",PT:"Portugal",
  SE:"Sweden",NO:"Norway",DK:"Denmark",FI:"Finland",IE:"Ireland",RU:"Russia",
  US:"USA",CA:"Canada",MX:"Mexico",BR:"Brazil",AR:"Argentina",
  AU:"Australia",NZ:"New Zealand",
  ZA:"South Africa",KE:"Kenya",ET:"Ethiopia",NG:"Nigeria",MU:"Mauritius"
};
const CNTR_AR = {
  KW:"الكويت",AE:"الإمارات",SA:"السعودية",BH:"البحرين",QA:"قطر",OM:"عُمان",
  EG:"مصر",JO:"الأردن",LB:"لبنان",IQ:"العراق",SY:"سوريا",YE:"اليمن",
  MA:"المغرب",TN:"تونس",DZ:"الجزائر",TR:"تركيا",
  IN:"الهند",PK:"باكستان",BD:"بنغلاديش",LK:"سريلانكا",NP:"نيبال",
  PH:"الفلبين",MY:"ماليزيا",ID:"إندونيسيا",TH:"تايلاند",SG:"سنغافورة",
  JP:"اليابان",KR:"كوريا الجنوبية",CN:"الصين",HK:"هونج كونج",VN:"فيتنام",
  KH:"كمبوديا",MV:"المالديف",KZ:"كازاخستان",
  GB:"المملكة المتحدة",FR:"فرنسا",DE:"ألمانيا",IT:"إيطاليا",ES:"إسبانيا",
  NL:"هولندا",CH:"سويسرا",AT:"النمسا",BE:"بلجيكا",GR:"اليونان",
  PT:"البرتغال",SE:"السويد",NO:"النرويج",DK:"الدنمارك",FI:"فنلندا",RU:"روسيا",
  US:"الولايات المتحدة",CA:"كندا",MX:"المكسيك",BR:"البرازيل",AR:"الأرجنتين",
  AU:"أستراليا",NZ:"نيوزيلندا",
  ZA:"جنوب أفريقيا",KE:"كينيا",ET:"إثيوبيا",NG:"نيجيريا",MU:"موريشيوس"
};

/* Country flags (emoji) */
const FLAGS = {
  KW:"🇰🇼",AE:"🇦🇪",SA:"🇸🇦",BH:"🇧🇭",QA:"🇶🇦",OM:"🇴🇲",
  EG:"🇪🇬",JO:"🇯🇴",LB:"🇱🇧",IQ:"🇮🇶",SY:"🇸🇾",YE:"🇾🇪",
  MA:"🇲🇦",TN:"🇹🇳",DZ:"🇩🇿",TR:"🇹🇷",
  IN:"🇮🇳",PK:"🇵🇰",BD:"🇧🇩",LK:"🇱🇰",NP:"🇳🇵",
  PH:"🇵🇭",MY:"🇲🇾",ID:"🇮🇩",TH:"🇹🇭",SG:"🇸🇬",
  JP:"🇯🇵",KR:"🇰🇷",CN:"🇨🇳",HK:"🇭🇰",VN:"🇻🇳",
  KH:"🇰🇭",MV:"🇲🇻",KZ:"🇰🇿",
  GB:"🇬🇧",FR:"🇫🇷",DE:"🇩🇪",IT:"🇮🇹",ES:"🇪🇸",
  NL:"🇳🇱",CH:"🇨🇭",AT:"🇦🇹",BE:"🇧🇪",GR:"🇬🇷",
  PT:"🇵🇹",SE:"🇸🇪",NO:"🇳🇴",DK:"🇩🇰",FI:"🇫🇮",RU:"🇷🇺",
  US:"🇺🇸",CA:"🇨🇦",MX:"🇲🇽",BR:"🇧🇷",AR:"🇦🇷",
  AU:"🇦🇺",NZ:"🇳🇿",
  ZA:"🇿🇦",KE:"🇰🇪",ET:"🇪🇹",NG:"🇳🇬",MU:"🇲🇺"
};

/* ──────────────────────────────────────────────────────
   UNIFIED VISA CHECK – single source of truth: Qatar Airways
   official "Travel Requirements" tool. We no longer keep our
   own visa status database in the UI (it could go stale and
   disagree with the airline). Instead this shows each leg of
   the current trip and one clear button that opens Qatar
   Airways' official, always-current requirements checker.
   ────────────────────────────────────────────────────── */
const QATAR_REQUIREMENTS_URL = "https://www.qatarairways.com/en-kw/travel-alerts/requirements.html";

function openQatarRequirements() {
  window.open(QATAR_REQUIREMENTS_URL, "_blank", "noopener");
}

function renderUnifiedVisaCheck() {
  const el = document.getElementById("visaTripResult");
  if (!el) return;
  const isAr = currentLang === "ar";
  const segs = window._lastSegments;

  let legsHtml = "";
  if (segs && segs.length) {
    const seen = new Set();
    segs.forEach(seg => {
      const key = `${seg.from}→${seg.to}`;
      if (seen.has(key)) return;
      seen.add(key);
      const fromCC = IATA_COUNTRY[seg.from], toCC = IATA_COUNTRY[seg.to];
      const fromName = (isAr ? CNTR_AR[fromCC] : CNTR[fromCC]) || seg.from;
      const toName   = (isAr ? CNTR_AR[toCC]   : CNTR[toCC])   || seg.to;
      const fromFlag = FLAGS[fromCC] || "🌍", toFlag = FLAGS[toCC] || "🌍";
      legsHtml += `<div class="visa-row">
        <div class="visa-row-icon">🛂</div>
        <div class="visa-row-body">
          <div class="visa-row-route">${fromFlag} ${fromName} <i class="fas fa-arrow-right" style="font-size:9px;color:#94a3b8;margin:0 4px"></i> ${toFlag} ${toName}</div>
        </div>
      </div>`;
    });
  }

  el.innerHTML = `
    ${legsHtml}
    <div class="ai-visa-form">
      <div class="full">
        <label>${isAr?"الجنسية (جواز السفر)":"Nationality (passport)"}</label>
        <input id="aiVisaNationality" type="text" placeholder="${isAr?"مثال: كويتي":"e.g. Kuwaiti"}"/>
      </div>
      <div>
        <label>${isAr?"من (اختياري)":"From (optional)"}</label>
        <input id="aiVisaFrom" type="text" placeholder="${isAr?"دولة المغادرة":"Departure country"}"/>
      </div>
      <div>
        <label>${isAr?"إلى":"To"}</label>
        <input id="aiVisaTo" type="text" placeholder="${isAr?"دولة الوجهة":"Destination country"}"/>
      </div>
      <div class="full">
        <label>${isAr?"ترانزيت (إن وجد)":"Transit (if any)"}</label>
        <input id="aiVisaTransit" type="text" placeholder="${isAr?"مثال: دبي":"e.g. Dubai"}"/>
      </div>
      <button class="ai-visa-submit full" id="aiVisaBtn" onclick="runAIVisaCheck()">
        <i class="fas fa-search"></i> <span id="lbl_aiVisaBtn">${isAr?"تحقق من المتطلبات":"Check Requirements"}</span>
      </button>
    </div>
    <div id="aiVisaResult"></div>
    <p class="visa-iframe-note" style="margin-top:14px;"><i class="fas fa-info-circle"></i> ${isAr?"الإجابة مولّدة بالذكاء الاصطناعي من معرفته العامة (بدون بحث حي) وقد تكون غير محدّثة — تحقق دائماً من السفارة أو":"This answer is AI-generated from general knowledge (not a live search) and may be outdated — always verify with the embassy or"} <a href="#" onclick="openQatarRequirements();return false;">${isAr?"الموقع الرسمي لقطر ايرويز":"Qatar Airways' official site"}</a> ${isAr?"قبل السفر.":"before you travel."}</p>
  `;

  if (typeof prefillAIVisaFromTrip === "function") prefillAIVisaFromTrip();
}


/* Open the visa modal and pre-load trip summary */
function openModal(id) {
  const m = document.getElementById(id);
  if (!m) return;
  m.style.display = "flex";
  document.body.style.overflow = "hidden";
  if (id === "historyModal")       renderHistoryList();
  if (id === "statsModal")         renderStatsPopup();
  if (id === "packageModal")       renderPackageRows();
  if (id === "agentSettingsModal") loadAgentSettings();
  if (id === "templateModal")      renderTemplateSelector();
  if (id === "multiPNRModal")      renderTabs();
  if (id === "xeModal")            loadXECurrencies();
  if (id === "commissionModal")    renderCommissionSummary();
  if (id === "visaModal") renderUnifiedVisaCheck();
}

/* ═══════════════════════════════════════════════════════
   39 – AI SUGGESTIONS
   ═══════════════════════════════════════════════════════ */
function buildAISuggestions(segments) {
  if(!segments||!segments.length) return "";
  const isAr=currentLang==="ar";
  const tips=[];

  segments.forEach((seg,i)=>{
    if(seg.durationMins>600){
      tips.push({icon:"fas fa-bed",type:"info",
        msg:isAr?`رحلة ${seg.airline}${seg.flightNum} تستغرق ${seg.durationAr||seg.duration} – يُنصح بطلب مقعد مريح أو الترقية`
               :`Flight ${seg.airline}${seg.flightNum} is ${seg.duration} – consider a comfort seat or upgrade`});
    }
    if(seg.depMins!==null&&seg.depMins<240){
      tips.push({icon:"fas fa-moon",type:"warning",
        msg:isAr?`رحلة ${seg.airline}${seg.flightNum} تغادر مبكراً – رتّب وسيلة النقل إلى المطار مسبقاً`
               :`Flight ${seg.airline}${seg.flightNum} is a very early departure – arrange airport transport`});
    }
    if(seg.arrMins!==null&&seg.arrMins>1320){
      tips.push({icon:"fas fa-hotel",type:"info",
        msg:isAr?`الوصول إلى ${seg.to} في وقت متأخر – تأكد من الحجز الفندقي`:`Late arrival to ${seg.to} – ensure hotel is booked`});
    }
    if(i>0){
      const t=calcTransit(segments[i-1].arrMins,seg.depMins,0);
      if(t&&t.mins<60){
        tips.push({icon:"fas fa-running",type:"critical",
          msg:isAr?`ترانزيت قصير جداً في ${segments[i-1].to}: ${t.labelAr||t.label} – خطر التفويت`
                 :`Very short transit at ${segments[i-1].to}: ${t.label} – connection risk!`});
      } else if(t&&t.mins>600){
        tips.push({icon:"fas fa-city",type:"info",
          msg:isAr?`ترانزيت طويل في ${segments[i-1].to}: ${t.labelAr||t.label} – يمكن استغلاله لجولة قصيرة`
                 :`Long transit at ${segments[i-1].to}: ${t.label} – consider a city tour`});
      }
    }
  });

  const visaWarn=segments.some(seg=>{const r=checkVisaRequirements(seg.from,seg.to);return r&&(r.status==="required"||r.status==="evisa"||r.status==="eta");});
  if(visaWarn) tips.push({icon:"fas fa-passport",type:"warning",msg:isAr?"⚠️ بعض الوجهات تستلزم تأشيرة – راجع قسم التأشيرة":"⚠️ Some destinations require a visa – see visa section"});

  if(!tips.length) tips.push({icon:"fas fa-check-circle",type:"success",msg:isAr?"✅ الرحلة تبدو ممتازة – لا ملاحظات":"✅ Itinerary looks great – no issues detected"});

  return `<div class="ai-suggestions">
    <div class="ai-header"><i class="fas fa-robot"></i> ${isAr?"اقتراحات ذكية":"Smart Suggestions"}</div>
    ${tips.map(t=>`<div class="ai-tip ai-tip-${t.type}"><i class="${t.icon}"></i><span>${t.msg}</span></div>`).join("")}
  </div>`;
}

/* ═══════════════════════════════════════════════════════
   36 – AIRPORT RATINGS
   ═══════════════════════════════════════════════════════ */
const AIRPORT_RATINGS = {
  SIN:{score:5,label:"World's Best",wifi:true,lounge:true,transit:true},
  HND:{score:5,label:"Excellent",wifi:true,lounge:true,transit:true},
  ICN:{score:5,label:"Excellent",wifi:true,lounge:true,transit:true},
  NRT:{score:4.5,label:"Very Good",wifi:true,lounge:true,transit:true},
  LHR:{score:4,label:"Good",wifi:true,lounge:true,transit:true},
  DXB:{score:4.5,label:"Very Good",wifi:true,lounge:true,transit:true},
  AMS:{score:4.5,label:"Very Good",wifi:true,lounge:true,transit:true},
  DOH:{score:4.5,label:"Very Good",wifi:true,lounge:true,transit:true},
  AUH:{score:4.2,label:"Very Good",wifi:true,lounge:true,transit:true},
  KWI:{score:3.5,label:"Good",wifi:true,lounge:true,transit:false},
  BAH:{score:3.5,label:"Good",wifi:true,lounge:true,transit:false},
  IST:{score:4.2,label:"Very Good",wifi:true,lounge:true,transit:true},
  CDG:{score:3.8,label:"Good",wifi:true,lounge:true,transit:true},
  FRA:{score:4.0,label:"Good",wifi:true,lounge:true,transit:true},
  ZRH:{score:4.5,label:"Very Good",wifi:true,lounge:true,transit:true},
  BKK:{score:4.2,label:"Very Good",wifi:true,lounge:true,transit:true},
  KUL:{score:4.0,label:"Good",wifi:true,lounge:true,transit:true},
  SYD:{score:4.0,label:"Good",wifi:true,lounge:true,transit:true},
  JFK:{score:3.5,label:"Average",wifi:true,lounge:true,transit:false},
  CAI:{score:3.0,label:"Average",wifi:false,lounge:true,transit:false}
};

function buildAirportRatings(segments) {
  if(!segments||!segments.length) return "";
  const isAr=currentLang==="ar";
  const seen=new Set(),cards=[];
  segments.forEach(seg=>{
    [seg.from,seg.to].forEach(code=>{
      if(!seen.has(code)&&AIRPORT_RATINGS[code]){
        seen.add(code);
        const r=AIRPORT_RATINGS[code];
        const stars="★".repeat(Math.round(r.score))+"☆".repeat(5-Math.round(r.score));
        cards.push(`<div class="airport-rating-card">
          <div class="ar-code">${code}</div>
          <div class="ar-stars">${stars}</div>
          <div class="ar-label">${r.label}</div>
          <div class="ar-icons">
            ${r.wifi?`<span title="Free WiFi"><i class="fas fa-wifi"></i></span>`:""}
            ${r.lounge?`<span title="Lounge"><i class="fas fa-couch"></i></span>`:""}
            ${r.transit?`<span title="Transit Hotel"><i class="fas fa-hotel"></i></span>`:""}
          </div></div>`);
      }
    });
  });
  if(!cards.length) return "";
  return `<div class="airport-ratings-section">
    <div class="ar-header"><i class="fas fa-star"></i> ${isAr?"تقييم المطارات":"Airport Ratings"}</div>
    <div class="ar-grid">${cards.join("")}</div>
  </div>`;
}

/* ═══════════════════════════════════════════════════════
   14 – AGENT NOTES
   ═══════════════════════════════════════════════════════ */
function buildAgentNotes() {
  const notes=document.getElementById("agentNotesInput")?.value.trim();
  if(!notes) return "";
  const isAr=currentLang==="ar";
  return `<div class="agent-notes-output" dir="${isAr?"rtl":"ltr"}">
    <div class="an-header"><i class="fas fa-sticky-note"></i> ${isAr?"ملاحظات الوكيل":"Agent Notes"}</div>
    <div class="an-body">${notes.replace(/\n/g,"<br>")}</div>
  </div>`;
}

/* ═══════════════════════════════════════════════════════
   30 – AGENCY LETTERHEAD
   ═══════════════════════════════════════════════════════ */
function generateLetterhead() {
  const isAr=currentLang==="ar";
  const s=MG.get("agentSettings",{});
  const outputEl=document.getElementById("outputContent");
  if(!outputEl||!outputEl.innerHTML.trim()){showToast(isAr?"قم بتحويل رحلة أولاً":"Convert an itinerary first",3000,"#f97316");return;}
  const itinerary=outputEl.innerHTML;
  const notes=document.getElementById("agentNotesInput")?.value.trim()||"";
  const win=window.open("","_blank");
  win.document.write(`<!DOCTYPE html>
<html dir="${isAr?"rtl":"ltr"}" lang="${isAr?"ar":"en"}">
<head><meta charset="UTF-8"><title>Itinerary – ${s.agencyName||"Itinovo"}</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css"/>
<style>
  body{font-family:Arial,sans-serif;margin:0;padding:0;background:#f5f5f5}
  .letter{max-width:820px;margin:20px auto;background:#fff;box-shadow:0 4px 20px rgba(0,0,0,.1)}
  .lh-header{background:linear-gradient(135deg,#0a1628,#1a3460);padding:22px 30px;display:flex;align-items:center;gap:18px;color:#fff}
  .lh-logo{width:54px;height:54px;border-radius:50%;background:rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;font-size:22px;color:#d4a843;overflow:hidden;flex-shrink:0}
  .lh-logo img{width:54px;height:54px;border-radius:50%;object-fit:cover}
  .lh-agency-name{font-size:20px;font-weight:700}.lh-agency-sub{font-size:11px;color:rgba(255,255,255,.65);margin-top:2px}
  .lh-contact{margin-${isAr?"right":"left"}:auto;color:rgba(255,255,255,.7);font-size:12px;text-align:${isAr?"left":"right"}}
  .lh-body{padding:26px 30px}.lh-title{font-size:17px;font-weight:700;color:#0a1628;margin-bottom:16px;padding-bottom:10px;border-bottom:2px solid #0d9488}
  .lh-notes{background:#f8fbff;border-${isAr?"right":"left"}:4px solid #d4a843;padding:12px 16px;margin:16px 0;border-radius:0 8px 8px 0;font-size:14px;color:#334155}
  .lh-footer{background:#f8f6f0;padding:14px 30px;display:flex;justify-content:space-between;font-size:12px;color:#64748b;border-top:1px solid #e2e8f0}
  table{width:100%;border-collapse:collapse} th,td{padding:8px 12px;border:1px solid #e2e8f0;font-size:13px} th{background:#0a1628;color:#fff}
  .itin-table{width:100%} .itin-segment{border:1px solid #e2e8f0;border-radius:8px;padding:14px;margin-bottom:10px}
  @media print{body{background:#fff}.letter{box-shadow:none}}
</style></head><body>
<div class="letter">
  <div class="lh-header">
    <div class="lh-logo">${s.agentLogo?`<img src="${s.agentLogo}" alt="logo">`:"✈"}</div>
    <div>
      <div class="lh-agency-name">${s.agencyName||"Itinovo"}</div>
      <div class="lh-agency-sub">${isAr?"وكالة سفر":"Travel Agency"}</div>
      ${s.agencyLicense?`<div style="font-size:11px;color:rgba(255,255,255,.5)">${isAr?"ترخيص:":"License:"} ${s.agencyLicense}</div>`:""}
    </div>
    <div class="lh-contact">
      ${s.agentPhone?`<div>📞 ${s.agentPhone}</div>`:""}
      ${s.agentEmail?`<div>✉️ ${s.agentEmail}</div>`:""}
      <div>${new Date().toLocaleDateString(isAr?"ar-KW":"en-GB")}</div>
    </div>
  </div>
  <div class="lh-body">
    <div class="lh-title">✈ ${isAr?"جدول رحلة السفر":"Flight Itinerary"}</div>
    ${itinerary}
    ${notes?`<div class="lh-notes">📝 ${isAr?"ملاحظات الوكيل:":"Agent Notes:"}<br>${notes.replace(/\n/g,"<br>")}</div>`:""}
  </div>
  <div class="lh-footer">
    <span>${s.agentName||""}${s.agencyName?" – "+s.agencyName:""}</span>
    <span>${isAr?"صدر بتاريخ":"Issued"} ${new Date().toLocaleDateString(isAr?"ar-KW":"en-GB")}</span>
  </div>
</div>
</body></html>`);
  win.document.close();
  setTimeout(()=>win.print(),500);
}

/* ═══════════════════════════════════════════════════════
   17 – PRESENTATION MODE
   ═══════════════════════════════════════════════════════ */
function enterPresentationMode() {
  const isAr=currentLang==="ar";
  const outputEl=document.getElementById("outputContent");
  if(!outputEl||!outputEl.innerHTML.trim()){showToast(isAr?"قم بتحويل رحلة أولاً":"Convert an itinerary first",3000,"#f97316");return;}
  const s=MG.get("agentSettings",{});
  const modal=document.getElementById("presentationModal");
  const content=document.getElementById("presentationContent");
  if(!modal||!content) return;
  const paxName=document.getElementById("passengerName")?.value.trim()||"";
  const notes=document.getElementById("agentNotesInput")?.value.trim()||"";

  /* Use the existing static header elements (#presAgencyName / #presPassengerName)
     instead of rebuilding a second .pres-header inside the content — the old code
     rendered the agency/passenger name twice. */
  const agencyEl=document.getElementById("presAgencyName");
  if (agencyEl) agencyEl.textContent = s.agencyName||"Itinovo";
  const paxEl=document.getElementById("presPassengerName");
  if (paxEl) paxEl.textContent = paxName ? `${isAr?"المسافر:":"Passenger:"} ${paxName}` : "";

  content.innerHTML=`
    <div class="pres-itinerary">${outputEl.innerHTML}</div>
    ${notes?`<div class="pres-notes"><i class="fas fa-sticky-note"></i> ${notes}</div>`:""}
    <div class="pres-footer">${[s.agentName,s.agentPhone].filter(Boolean).join(" · ")}</div>`;
  modal.style.display="flex";
  document.body.style.overflow="hidden";
}

/* ═══════════════════════════════════════════════════════
   33 – VISUAL TEMPLATES
   ═══════════════════════════════════════════════════════ */
const VISUAL_TEMPLATES = {
  classic:{name:"Classic Navy",    bg:"#0a1628",accent:"#d4a843",text:"#ffffff"},
  teal:   {name:"Modern Teal",     bg:"#0d4f4a",accent:"#f0c060",text:"#ffffff"},
  minimal:{name:"Clean White",     bg:"#ffffff", accent:"#0a1628",text:"#1a2744"},
  rose:   {name:"Rose Gold",       bg:"#7f1d1d",accent:"#fca5a5",text:"#ffffff"},
  forest: {name:"Forest Green",    bg:"#14532d",accent:"#86efac",text:"#ffffff"},
  purple: {name:"Royal Purple",    bg:"#4c1d95",accent:"#c4b5fd",text:"#ffffff"}
};

let currentTemplate = MG.get("visualTemplate","classic");

function applyVisualTemplate(tmplKey) {
  currentTemplate=tmplKey;
  MG.set("visualTemplate",tmplKey);
  const t=VISUAL_TEMPLATES[tmplKey]||VISUAL_TEMPLATES.classic;
  document.documentElement.style.setProperty("--navy",t.bg);
  document.documentElement.style.setProperty("--navy-mid", lightenColor(t.bg,15));
  document.documentElement.style.setProperty("--gold",t.accent);
  document.documentElement.style.setProperty("--gold-bright",t.accent);
  document.documentElement.style.setProperty("--grad-header",`linear-gradient(135deg,${t.bg},${lightenColor(t.bg,20)})`);
  document.documentElement.style.setProperty("--grad-hero",`linear-gradient(135deg,${t.bg},${lightenColor(t.bg,10)})`);
  document.querySelectorAll(".tmpl-btn").forEach(btn=>btn.classList.toggle("active",btn.dataset.tmpl===tmplKey));
}

function lightenColor(hex,pct){
  const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);
  const nr=Math.min(255,r+pct*2),ng=Math.min(255,g+pct*2),nb=Math.min(255,b+pct*2);
  return `#${Math.round(nr).toString(16).padStart(2,"0")}${Math.round(ng).toString(16).padStart(2,"0")}${Math.round(nb).toString(16).padStart(2,"0")}`;
}

function renderTemplateSelector() {
  const container=document.getElementById("templateSelector");
  if(!container) return;
  container.innerHTML=Object.entries(VISUAL_TEMPLATES).map(([key,t])=>`
    <button class="tmpl-btn ${currentTemplate===key?"active":""}" data-tmpl="${key}"
      onclick="applyVisualTemplate('${key}')"
      style="background:${t.bg};color:${t.text};border:3px solid ${currentTemplate===key?t.accent:"transparent"};">
      <div class="tmpl-swatch" style="background:${t.accent}"></div>
      <span>${t.name}</span>
    </button>`).join("");
}

/* ═══════════════════════════════════════════════════════
   29 – MULTI-PNR TABS
   ═══════════════════════════════════════════════════════ */
let multiPNRTabs=[];
let activeTabId=null;

function initMultiTabs() {
  const saved=MG.get("multiTabs",[]);
  if(saved&&saved.length){
    multiPNRTabs=saved;
    /* Bug fix: previously this only set activeTabId without loading the
       saved PNR text back into #pnrInput, so a saved trip "disappeared"
       from the textarea after every page reload even though it was
       still in storage. switchTab() both selects the tab AND restores
       its text into the input. */
    switchTab(saved[0].id);
  } else {
    createNewTab();
  }
}

function createNewTab() {
  const isAr=currentLang==="ar";
  const tab={id:Date.now(),label:`${isAr?"رحلة":"Trip"} ${multiPNRTabs.length+1}`,pnr:"",output:""};
  multiPNRTabs.push(tab);
  saveTabs();renderTabs();switchTab(tab.id);
}

function saveTabs() {
  MG.set("multiTabs",multiPNRTabs.map(t=>({id:t.id,label:t.label,pnr:t.pnr,output:""})));
}

function renderTabs() {
  const container=document.getElementById("multiTabsBar");
  if(!container) return;
  const isAr=currentLang==="ar";
  container.innerHTML=multiPNRTabs.map(tab=>`
    <div class="mtab ${tab.id===activeTabId?"active":""}" data-id="${tab.id}">
      <span onclick="switchTab(${tab.id})" class="mtab-label">${tab.label}</span>
      <button class="mtab-close" onclick="closeTab(${tab.id})" title="${isAr?"إغلاق":"Close"}">×</button>
    </div>`).join("")+
    `<button class="mtab-add" onclick="createNewTab()" title="${isAr?"إضافة":"Add"}"><i class="fas fa-plus"></i></button>`;
}

function switchTab(id) {
  if(activeTabId){
    const cur=multiPNRTabs.find(t=>t.id===activeTabId);
    if(cur) cur.pnr=document.getElementById("pnrInput")?.value||"";
  }
  activeTabId=id;
  const tab=multiPNRTabs.find(t=>t.id===id);
  if(tab){
    const pi=document.getElementById("pnrInput");
    if(pi) pi.value=tab.pnr||"";
    if(tab.output){document.getElementById("outputContent").innerHTML=tab.output;document.getElementById("outputSection").style.display="block";}
    else document.getElementById("outputSection").style.display="none";
  }
  renderTabs();saveTabs();
}

function closeTab(id) {
  const isAr=currentLang==="ar";
  if(multiPNRTabs.length<=1){showToast(isAr?"لا يمكن إغلاق آخر تبويب":"Cannot close the last tab");return;}
  multiPNRTabs=multiPNRTabs.filter(t=>t.id!==id);
  if(activeTabId===id){activeTabId=multiPNRTabs[0]?.id;switchTab(activeTabId);}
  else{saveTabs();renderTabs();}
}

function updateActiveTabOutput(html) {
  const tab=multiPNRTabs.find(t=>t.id===activeTabId);
  if(tab) tab.output=html;
}

/* ═══════════════════════════════════════════════════════
   37 – CURRENCY WIDGET (XE-style)
   ═══════════════════════════════════════════════════════ */
function loadXECurrencies() {
  const el=document.getElementById("xeCurrencyWidget");
  if(!el) return;
  const isAr=currentLang==="ar";
  const BASE={USD:1,EUR:0.92,GBP:0.79,AUD:1.53,NZD:1.65,KWD:0.308,SAR:3.75,AED:3.67,
              BHD:0.377,QAR:3.64,OMR:0.385,EGP:30.9,JOD:0.71,TRY:32.1,INR:83.5,
              PKR:278,MYR:4.72,SGD:1.34,CAD:1.36,CHF:0.91,JPY:157,CNY:7.25,
              THB:35.6,MAD:10.0,IDR:15900,PHP:56.5};
  const from=document.getElementById("xeFrom")?.value||"KWD";
  const to  =document.getElementById("xeTo")?.value||"USD";
  const amt =parseFloat(document.getElementById("xeAmount")?.value)||1;
  const rate=(BASE[to]||1)/(BASE[from]||1)*amt;
  const dp=getCurrDP(to),sym=getCurrSymbol(to);
  const unitRate=(BASE[to]||1)/(BASE[from]||1);
  el.innerHTML=`
    <div class="xe-result">
      <div class="xe-from">${amt} ${from}</div>
      <div class="xe-eq">=</div>
      <div class="xe-to">${sym} ${rate.toFixed(dp)} <span>${to}</span></div>
    </div>
    <div class="xe-meta">1 ${from} = ${unitRate.toFixed(4)} ${to} · <span style="color:#f97316">${isAr?"أسعار تقريبية":"Approximate rates"}</span></div>
    <div style="text-align:center;margin-top:8px">
      <a href="https://xe.com/currencyconverter/convert/?Amount=${amt}&From=${from}&To=${to}" target="_blank" style="font-size:11px;color:#0d9488">
        ${isAr?"تحقق من السعر الدقيق على XE.com":"Check live rates on XE.com"} ↗
      </a>
    </div>`;
}

/* ═══════════════════════════════════════════════════════
   HOOK INTO doConvert (override renderAndShow)
   ═══════════════════════════════════════════════════════ */
document.addEventListener("DOMContentLoaded", ()=>{

  /* ── Override renderAndShow so doConvert() in converter.js uses our enhanced version ── */
  const _origRender = window.renderAndShow;
  const _enhancedRender = function(segs, opts, currency, passenger, signOff) {
    window._lastSegments = segs;
    try {
      let out="";
      if(opts.format==="table")      out=renderTable(segs,opts);
      else if(opts.format==="lines") out=renderLines(segs,opts);
      else if(opts.format==="email") out=renderEmail(segs,opts,passenger,signOff);
      out+=buildFareSummary(currency);
      if(opts.format!=="email"){
        out+=buildAgentNotes();
      }
      document.getElementById("outputContent").innerHTML=out;
      const sec=document.getElementById("outputSection");
      sec.style.display="block";
      const eb=document.getElementById("copyEmailBtn");
      if(eb) eb.style.display=(opts.format==="email")?"inline-flex":"none";
      saveToHistory(document.getElementById("pnrInput")?.value.trim()||"",out);
      recordConversion(segs);
      updateActiveTabOutput(out);
      const pkgC=document.getElementById("packageCurrency")?.value||currency;
      buildPackagePreview(pkgC,getCurrSymbol(pkgC),getCurrDP(pkgC));
      setTimeout(()=>sec.scrollIntoView({behavior:"smooth",block:"start"}),100);
    } catch(err) {
      console.error("renderAndShow error:", err);
      /* Fallback to original renderer if features fail */
      if(typeof _origRender==="function") _origRender(segs,opts,currency,passenger,signOff);
    }
  };

  /* Register globally so converter.js doConvert() picks it up */
  window._featuresRenderAndShow = _enhancedRender;
  window.renderAndShow = _enhancedRender; /* Also set window.renderAndShow for compatibility */

  // Init
  loadAgentSettings();
  updateHistoryBadge();
  checkSavedAlerts();
  applyVisualTemplate(currentTemplate);
  initMultiTabs();

  // XE widget events
  ["xeFrom","xeTo","xeAmount"].forEach(id=>{
    document.getElementById(id)?.addEventListener("change",loadXECurrencies);
    document.getElementById(id)?.addEventListener("input",loadXECurrencies);
  });

  // Keyboard shortcuts
  document.addEventListener("keydown",e=>{
    if(e.ctrlKey&&e.key==="p"){e.preventDefault();window.print();}
    if(e.key==="Escape"){
      document.querySelectorAll(".mg-modal[style*='flex']").forEach(m=>{m.style.display="none";});
      const pm=document.getElementById("presentationModal");
      if(pm&&pm.style.display==="flex"){pm.style.display="none";}
      document.body.style.overflow="";
    }
    if(e.ctrlKey&&e.shiftKey&&e.key==="F"){enterPresentationMode();}
  });
});
