# Itinovo – PNR Converter

**Live URL:** https://itinovo.netlify.app/

A professional GDS PNR-to-itinerary converter for travel agents, with full Arabic/English support and a rich set of agency tools.

---

## ✅ Completed Features

### Core Engine
- Parses raw GDS text: Galileo, Amadeus, Sabre, Worldspan, Smartpoint, Kuwait Airways (KU), Emirates (EK), Etihad (EY), Qatar Airways (QR), and more
- Output formats: **Table**, **Cards (Lines)**, **Email**
- Display options: airline logo, name, flight #, duration, distance, transit time, cabin class, operated-by, 12-hour clock, baggage
- Fare summary: adult / child / infant + fees + grand total
- Copy HTML / Copy Text / Copy Email
- Print (Ctrl+P)
- Full Arabic (RTL) ↔ English (LTR) bilingual engine

### Agent Features (v2.0)
| # | Feature | Status |
|---|---------|--------|
| 12 | Build Your Package (multi-item, multi-currency) | ✅ |
| 14 | Agent Notes (shown in output) | ✅ |
| 16 | Usage Statistics (total, today, week, airlines) | ✅ |
| 17 | Presentation Mode (full-screen client view) | ✅ |
| 20 | Agent Settings (name, agency, phone, email, logo, license, sign-off, default currency/language, passport nationality, B2B mode) | ✅ |
| 21 | Trip History (last 10 trips, load / view / delete) | ✅ |
| 25 | Commission Tracker (price × %, service charge) | ✅ |
| 26 | PNR Expiry Alert (color-coded warnings, localStorage) | ✅ |
| 28 | Time Zone Difference (50+ cities) | ✅ |
| 29 | Multi-PNR Tabs (unlimited trips, persistent) | ✅ |
| 30 | Agency Letterhead (print-ready, logo, contacts) | ✅ |
| 33 | Visual Templates (6 color themes) | ✅ |
| 34 | WhatsApp Message Generator (custom template) | ✅ |
| 36 | Airport Ratings (WiFi, lounge, transit hotel flags) | ✅ |
| 37 | Currency Converter (XE-style, 25+ currencies) | ✅ |
| 38 | Quick Print | ✅ |
| 39 | AI Smart Suggestions (long flight, early departure, short transit, etc.) | ✅ |
| 41 | **Visa Check (Feature 41)** — 3-tab modal: Quick Lookup, Qatar Airways Live, Trip Summary | ✅ |
| 46 | **B2B Agency Mode (Feature 46)** — hides ads, cookie bar, API section, blog; shows B2B badge | ✅ |

---

## 🔑 Key Entry Points

| Path | Description |
|------|-------------|
| `/` | Main converter page |
| `/#converter` | Jump directly to converter |
| `/sitemap.xml` | Sitemap |
| `/robots.txt` | Robots |
| `/blog/understanding-pnr-codes.html` | Blog article |

---

## 🧭 How It Works

1. **Paste PNR** into the textarea (supports all major GDS formats)
2. **Choose Options** (display fields, format, currency, passenger name)
3. **Click Convert Itinerary** (or press Ctrl+Enter)
4. **Output** appears with table/cards/email + fare summary + AI tips + visa warnings + airport ratings
5. **Share** via Copy HTML/Text/Email, WhatsApp, Letterhead, or Presentation Mode

---

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+Enter` | Convert |
| `Ctrl+P` | Print |
| `Ctrl+Shift+F` | Presentation Mode |
| `Escape` | Close any modal |

---

## 🧰 Floating Toolbar Buttons (bottom-left)

| Button | Action |
|--------|--------|
| 🔵 Navy | Agent Settings |
| 🟢 Teal | Trip History (with badge) |
| 🟡 Gold | Usage Statistics |
| 🟣 Purple | Visual Templates |
| 🔵 Blue | Multi-Trip Tabs |
| 🟣 Visa | Visa Requirements Check |

---

## 🛠️ Tool Chips (below Convert button)

Package · Commission · PNR Expiry · Time Zone · Currency · **Visa Check**

---

## 📁 File Structure

```
index.html             Main page
css/
  style.css            Core styles (layout, header, converter, output)
  features.css         Features module styles (modals, visa, B2B, tools)
js/
  airlines.js          Airline name + ICAO data
  airports.js          Airport city names
  converter.js         Core PNR parser + renderer + bilingual engine
  features.js          All agent features (20-46), visa DB, modal logic
images/
  logo-new.png         Logo
sitemap.xml
robots.txt
netlify.toml
ads.txt
```

---

## 💾 LocalStorage Keys

| Key | Value |
|-----|-------|
| `mg_lang` | `"en"` or `"ar"` |
| `mg_agentSettings` | Agent profile JSON |
| `mg_history` | Array of last 10 trips |
| `mg_stats` | Usage stats object |
| `mg_statsWeek` | Weekly stats object |
| `mg_commTracker` | Commission state |
| `mg_pnrAlerts` | PNR expiry alerts |
| `mg_multiTabs` | Multi-trip tabs |
| `mg_visualTemplate` | Active theme key |

---

## 📊 Data Models

### Agent Settings
```json
{
  "agentName": "string",
  "agencyName": "string",
  "agentPhone": "string",
  "agentEmail": "string",
  "agentLogo": "url",
  "agencyLicense": "string",
  "agentSignOff": "string",
  "defaultCurrency": "KWD",
  "defaultLang": "en",
  "b2bMode": false,
  "whatsappTemplate": "string",
  "passportNationality": "KW"
}
```

### Visa DB entry (VISA_DB_FULL)
```json
"KW→US": { "status": "required", "note": "...", "noteAr": "...", "link": "https://..." }
```
Status values: `free` | `voa` | `eta` | `evisa` | `required`

---

## 📞 Contact

- **Phone:** +965 6092 6660
- **Email:** hello@itinovo.com
- **Linktree:** https://linktr.ee/j3_dm
- **WhatsApp:** https://wa.me/96560926660

---

## 🔜 Recommended Next Steps

1. Add more passport nationalities to VISA_DB_FULL (e.g. SA→, BH→, QA→)
2. Add offline PWA manifest & service worker for agent use
3. Export itinerary to PDF directly in browser
4. Add flight status check via public API
5. Add more airport ratings (currently 20 airports)
6. Add language support for French (for North African markets)
